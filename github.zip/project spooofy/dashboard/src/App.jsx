import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet, Link, useNavigate } from 'react-router-dom';
import PublicNavbar from './components/public/PublicNavbar';
import PublicFooter from './components/public/PublicFooter';

import LandingPage from './pages/public/LandingPage';
import FeaturesPage from './pages/public/FeaturesPage';
import SecurityPage from './pages/public/SecurityPage';
import MusicPage from './pages/public/MusicPage';
import CommandsPage from './pages/public/CommandsPage';
import PremiumPage from './pages/public/PremiumPage';
import DocsPage from './pages/public/DocsPage';
import StatusPage from './pages/public/StatusPage';
import SupportPage from './pages/public/SupportPage';
import CompanyPage from './pages/public/CompanyPage';
import LoginPage from './pages/public/LoginPage';
import LegalPrivacyPage from './pages/public/LegalPrivacyPage';
import LegalTermsPage from './pages/public/LegalTermsPage';

import ServerSelectorPage from './pages/dashboard/ServerSelectorPage';
import GuildDashboardPage from './pages/dashboard/GuildDashboardPage';
import AdminPanelPage from './pages/admin/AdminPanelPage';
import StaffPortalPage from './pages/staff/StaffPortalPage';

import { fetchAuthMe, logout } from './api';

function PublicLayout({ auth, onLogout }) {
  return (
    <div className="public-theme" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#ffffff', color: '#111111' }}>
      <PublicNavbar auth={auth} onLogout={onLogout} />
      <main style={{ flex: 1, backgroundColor: '#ffffff' }}>
        <Outlet />
      </main>
      <PublicFooter />
    </div>
  );
}

export default function App() {
  const [auth, setAuth] = useState(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);

  const loadAuth = async () => {
    try {
      const data = await fetchAuthMe();
      setAuth(data);
    } catch {
      setAuth({ authenticated: false });
    } finally {
      setIsLoadingAuth(false);
    }
  };

  useEffect(() => {
    loadAuth();
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      setAuth({ authenticated: false });
      window.location.href = '/';
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  if (isLoadingAuth) {
    return (
      <div style={{
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#090810',
        color: '#c4b5fd',
        fontFamily: 'Inter, system-ui, sans-serif',
        fontSize: '1rem',
        fontWeight: 600,
        gap: '12px'
      }}>
        <div style={{ width: '28px', height: '28px', border: '3px solid rgba(139, 92, 246, 0.2)', borderTopColor: '#8b5cf6', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
        Loading SPOOFY Ecosystem...
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Public Website Routes */}
        <Route element={<PublicLayout auth={auth} onLogout={handleLogout} />}>
          <Route path="/" element={<LandingPage />} />
          <Route path="/features" element={<FeaturesPage />} />
          <Route path="/security" element={<SecurityPage />} />
          <Route path="/music" element={<MusicPage />} />
          <Route path="/commands" element={<CommandsPage />} />
          <Route path="/premium" element={<PremiumPage />} />
          <Route path="/docs" element={<DocsPage />} />
          <Route path="/status" element={<StatusPage />} />
          <Route path="/support" element={<SupportPage />} />
          <Route path="/company" element={<CompanyPage />} />
          <Route path="/about" element={<CompanyPage />} />
          <Route path="/login" element={<LoginPage onLoginSuccess={loadAuth} />} />
          <Route path="/legal/privacy" element={<LegalPrivacyPage />} />
          <Route path="/legal/terms" element={<LegalTermsPage />} />
          <Route path="/dashboard" element={<ServerSelectorPage auth={auth} />} />
        </Route>

        {/* Guild Dashboard Route */}
        <Route path="/dashboard/:guildId" element={<GuildDashboardPage auth={auth} />} />

        {/* SPOOFY Owner Admin Panel Route */}
        <Route path="/admin" element={<AdminPanelPage auth={auth} />} />

        {/* Private Staff Portal Route */}
        <Route path="/staff" element={<StaffPortalPage auth={auth} />} />

        {/* Catch-all Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
