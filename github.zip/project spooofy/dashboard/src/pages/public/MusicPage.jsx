import React from 'react';
import { Music, Play, Radio, Volume2, SkipForward, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function MusicPage() {
  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  const musicFeatures = [
    { title: 'Interactive Web Player', icon: Play, desc: 'View track progress, control volume, pause, resume, and skip songs directly from the SPOOFY Web Dashboard.' },
    { title: '24/7 Voice Channel Mode', icon: Radio, desc: 'Keep SPOOFY connected in your community stage or voice channels continuously without dropping connection when alone.' },
    { title: 'Dynamic Audio Normalization', icon: Volume2, desc: 'Automatic gain control and clean audio processing powered by high-performance Lavalink streaming nodes.' },
    { title: 'Lossless Streaming', icon: Music, desc: 'Low-latency audio resolution compatible with YouTube, Spotify links, and SoundCloud tracks.' }
  ];

  const commands = [
    { name: '/music play <query|url>', desc: 'Search and stream audio or enqueue tracks in the server queue.' },
    { name: '/music pause', desc: 'Pause current playback without losing track timestamp.' },
    { name: '/music skip', desc: 'Skip to the next song in the playback queue.' },
    { name: '/music stop', desc: 'Halt playback, clear queue, and release voice connection.' },
    { name: '/music volume <1-100>', desc: 'Fine-tune playback volume (default: 80%).' },
    { name: '/music queue', desc: 'Display upcoming songs in the server queue.' }
  ];

  return (
    <div className="container" style={{ padding: '48px 24px 80px', display: 'flex', flexDirection: 'column', gap: '48px' }}>
      {/* Header */}
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          VELORA Audio Infrastructure
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 700, color: '#ffffff', marginTop: '6px', letterSpacing: '-0.02em' }}>
          SPOOFY Music Engine
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: '8px', maxWidth: '640px', lineHeight: 1.6 }}>
          Engineered by VELORA. High-performance, low-latency lossless audio playback designed for Discord voice channels. Manage playback through slash commands or the real-time web dashboard.
        </p>
      </div>

      {/* Feature Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '20px' }}>
        {musicFeatures.map((f, i) => {
          const Icon = f.icon;
          return (
            <div key={i} className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '6px',
                backgroundColor: 'var(--bg-subtle)',
                border: '1px solid var(--border-default)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--primary)'
              }}>
                <Icon size={18} />
              </div>
              <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#ffffff' }}>{f.title}</h3>
              <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{f.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Commands Table / List */}
      <div className="card" style={{ padding: '28px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#ffffff' }}>
            Supported Music Slash Commands
          </h2>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)', marginTop: '4px' }}>
            Available to all server members in voice channels or restricted to DJ roles via the dashboard.
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {commands.map((cmd, idx) => (
            <div
              key={idx}
              style={{
                padding: '12px 16px',
                backgroundColor: 'var(--bg-base)',
                borderRadius: '6px',
                border: '1px solid var(--border-subtle)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '12px'
              }}
            >
              <code className="mono-text" style={{ color: 'var(--primary)', fontWeight: 600, fontSize: '0.8125rem' }}>
                {cmd.name}
              </code>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.8125rem' }}>
                {cmd.desc}
              </span>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
          <a href={discordInviteUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm">
            Add to Discord <ExternalLink size={13} />
          </a>
          <Link to="/commands" className="btn btn-secondary btn-sm">
            View All Commands
          </Link>
        </div>
      </div>
    </div>
  );
}
