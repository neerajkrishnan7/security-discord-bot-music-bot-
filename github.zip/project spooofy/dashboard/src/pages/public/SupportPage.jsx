import React from 'react';
import { MessageSquare, ExternalLink, BookOpen, Activity, Bug } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function SupportPage() {
  const supportServerUrl = "https://discord.gg/spoofy";

  return (
    <div className="container" style={{ padding: '64px 24px 96px', display: 'flex', flexDirection: 'column', gap: '48px', maxWidth: '880px' }}>
      {/* Header */}
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Assistance & Community
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, color: '#000000', marginTop: '6px', letterSpacing: '-0.03em' }}>
          Support Hub.
        </h1>
        <p style={{ color: '#555555', marginTop: '8px', maxWidth: '600px', lineHeight: 1.6 }}>
          Need assistance setting up anti-nuke rules, diagnosing a permission error, or requesting features? We're here to help.
        </p>
      </div>

      {/* Main Support Server Card */}
      <div className="card" style={{
        padding: '48px 36px',
        backgroundColor: '#ffffff',
        border: '1px solid #e5e5e7',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        textAlign: 'center',
        gap: '20px'
      }}>
        <div style={{
          width: '44px',
          height: '44px',
          borderRadius: '4px',
          backgroundColor: '#000000',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#ffffff'
        }}>
          <MessageSquare size={22} />
        </div>

        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#000000' }}>
            Official SPOOFY Discord Community
          </h2>
          <p style={{ color: '#555555', marginTop: '8px', maxWidth: '480px', lineHeight: 1.6 }}>
            Join our verified Discord server to interact directly with support agents, open private support tickets, and view real-time service announcements.
          </p>
        </div>

        <a
          href={supportServerUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-editorial-black"
          style={{ padding: '12px 28px', marginTop: '8px' }}
        >
          Join Discord Support <ExternalLink size={14} />
        </a>
      </div>

      {/* Support Resources Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px' }}>
        <div className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '12px', backgroundColor: '#ffffff', border: '1px solid #e5e5e7' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#000000' }}>
            <BookOpen size={18} />
            <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#000000', margin: 0 }}>Documentation</h3>
          </div>
          <p style={{ fontSize: '0.8125rem', color: '#555555', lineHeight: 1.6, margin: 0 }}>
            Read through setup guides, role hierarchy rules, and slash command syntax.
          </p>
          <div style={{ marginTop: 'auto', paddingTop: '8px' }}>
            <Link to="/docs" className="editorial-link">
              Browse documentation &rarr;
            </Link>
          </div>
        </div>

        <div className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '12px', backgroundColor: '#ffffff', border: '1px solid #e5e5e7' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#000000' }}>
            <Activity size={18} />
            <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#000000', margin: 0 }}>System Status</h3>
          </div>
          <p style={{ fontSize: '0.8125rem', color: '#555555', lineHeight: 1.6, margin: 0 }}>
            Check live uptime and operational metrics for Discord Gateway and audio nodes.
          </p>
          <div style={{ marginTop: 'auto', paddingTop: '8px' }}>
            <Link to="/status" className="editorial-link">
              View system status &rarr;
            </Link>
          </div>
        </div>

        <div className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '12px', backgroundColor: '#ffffff', border: '1px solid #e5e5e7' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#000000' }}>
            <Bug size={18} />
            <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#000000', margin: 0 }}>Bug Reporting</h3>
          </div>
          <p style={{ fontSize: '0.8125rem', color: '#555555', lineHeight: 1.6, margin: 0 }}>
            Encountered an edge case or false positive? Report it directly to our security engineers.
          </p>
          <div style={{ marginTop: 'auto', paddingTop: '8px' }}>
            <a href={supportServerUrl} target="_blank" rel="noopener noreferrer" className="editorial-link">
              Open report ticket &rarr;
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
