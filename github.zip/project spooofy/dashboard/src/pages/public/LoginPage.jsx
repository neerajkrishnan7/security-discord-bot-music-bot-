import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, ShieldCheck, UserCheck, ShieldAlert, Sparkles } from 'lucide-react';
import { loginDevPersona } from '../../api';

export default function LoginPage({ onLoginSuccess }) {
  const navigate = useNavigate();
  const [loadingPersona, setLoadingPersona] = useState(null);

  const handleDevLogin = async (persona, redirectTo = '/dashboard') => {
    setLoadingPersona(persona);
    try {
      await loginDevPersona(persona);
      if (onLoginSuccess) await onLoginSuccess();
      navigate(redirectTo);
    } catch (err) {
      alert(`Login failed: ${err.message}`);
    } finally {
      setLoadingPersona(null);
    }
  };

  return (
    <div className="container" style={{ padding: '60px 24px 80px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div className="card" style={{ maxWidth: '520px', width: '100%', padding: '36px 32px', textAlign: 'center' }}>
        {/* Authentic SPOOFY Logo */}
        <div style={{
          width: '56px',
          height: '56px',
          margin: '0 auto 16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <img src="/assets/spoofy_logo.png" alt="SPOOFY Logo" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
        </div>

        <h1 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff' }}>
          Sign in to SPOOFY
        </h1>
        <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
          Authenticate with your Discord account to manage authorized servers and anti-nuke rules.
        </p>

        {/* Discord OAuth Login Button */}
        <a
          href="/api/auth/discord/login"
          className="btn btn-primary"
          style={{ width: '100%', marginTop: '24px', padding: '12px', fontSize: '0.875rem' }}
        >
          <LogIn size={16} /> Continue with Discord OAuth2
        </a>

        {/* Testing Personas for Local Development */}
        <div style={{ marginTop: '32px', borderTop: '1px solid var(--border-subtle)', paddingTop: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', fontSize: '0.75rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            <Sparkles size={13} /> Local Development Personas
          </div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '4px' }}>
            Instant testing profiles to explore each of the three isolated portals:
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '14px' }}>
            {/* Persona 1: Server Owner */}
            <button
              onClick={() => handleDevLogin('owner', '/dashboard')}
              disabled={Boolean(loadingPersona)}
              className="btn btn-secondary"
              style={{ justifyContent: 'space-between', padding: '10px 14px', fontSize: '0.8125rem' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <ShieldCheck size={16} color="#10b981" />
                <div style={{ textAlign: 'left' }}>
                  <div style={{ fontWeight: 600, color: '#ffffff' }}>Discord Server Owner</div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>Access Guild Dashboard (/dashboard)</div>
                </div>
              </div>
              <span className="badge badge-success">Select</span>
            </button>

            {/* Persona 2: Internal Staff Member */}
            <button
              onClick={() => handleDevLogin('staff', '/staff')}
              disabled={Boolean(loadingPersona)}
              className="btn btn-secondary"
              style={{ justifyContent: 'space-between', padding: '10px 14px', fontSize: '0.8125rem' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <UserCheck size={16} color="#06b6d4" />
                <div style={{ textAlign: 'left' }}>
                  <div style={{ fontWeight: 600, color: '#ffffff' }}>SPOOFY Staff Member</div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>Access Private Staff Portal (/staff)</div>
                </div>
              </div>
              <span className="badge badge-warning">Select</span>
            </button>

            {/* Persona 3: Global System Admin */}
            <button
              onClick={() => handleDevLogin('owner', '/admin')}
              disabled={Boolean(loadingPersona)}
              className="btn btn-secondary"
              style={{ justifyContent: 'space-between', padding: '10px 14px', fontSize: '0.8125rem' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <ShieldAlert size={16} color="#ef4444" />
                <div style={{ textAlign: 'left' }}>
                  <div style={{ fontWeight: 600, color: '#ffffff' }}>Global Project Owner</div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>Access Owner Admin Panel (/admin)</div>
                </div>
              </div>
              <span className="badge badge-critical">Select</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
