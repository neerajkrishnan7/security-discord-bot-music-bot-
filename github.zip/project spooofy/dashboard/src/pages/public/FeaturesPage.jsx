import React from 'react';
import { ShieldCheck, Radio, Database, Music, Sliders, CheckCircle2, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function FeaturesPage() {
  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  const featureGroups = [
    {
      category: 'SPOOFY Shield — Anti-Nuke & Server Defense',
      icon: ShieldCheck,
      description: 'Real-time sliding-window algorithms designed to neutralize malicious actions before server wiping occurs.',
      items: [
        { title: 'Anti-Nuke Protection', desc: 'Evaluates destructive action counts within configurable rolling time windows (e.g., 2 channel deletions in 10s).' },
        { title: 'Anti-Raid Controls', desc: 'Monitors member join velocity spikes and triggers automated channel lockdowns.' },
        { title: 'Role and Permission Protection', desc: 'Blocks unauthorized deletion of community roles and intercepts privilege escalation.' },
        { title: 'Webhook Monitoring', desc: 'Detects and immediately destroys rogue webhooks created to bypass Discord permissions.' },
        { title: 'Automated Moderation', desc: 'Calculates repeat warnings, automatically applies timeouts, kicks, and bans.' }
      ]
    },
    {
      category: 'SPOOFY Sentinel — Surveillance & Incident Attribution',
      icon: Radio,
      description: 'Audit log correlation with exponential retry algorithms to accurately pinpoint executors.',
      items: [
        { title: 'Audit Logs', desc: 'Correlates Discord audit events with jitter compensation to ensure 100% actor attribution.' },
        { title: 'Security Alerts', desc: 'Tiered severity alerts (CRITICAL, HIGH, MEDIUM, LOW) dispatched to private security log channels.' },
        { title: 'Suspicious Activity Monitoring', desc: 'Tracks unauthorized permission changes, mass mentions, and server setting modifications.' },
        { title: 'Configurable Logging Channels', desc: 'Dedicate separate channels for security alerts, moderation actions, and member events.' }
      ]
    },
    {
      category: 'SPOOFY Recovery — Disaster Recovery & Rollback',
      icon: Database,
      description: 'Automated hierarchy captures enabling safe, sanitized restoration after a disaster.',
      items: [
        { title: 'Server Backups', desc: 'Captures full hierarchy snapshots: categories, text/voice channels, topics, and permission overwrites.' },
        { title: 'Channel and Role Restoration', desc: 'Reconstructs accidentally deleted channels and roles with original configurations.' },
        { title: 'Permission Recovery', desc: 'Sanitizes dangerous Administrator permissions during restoration to guarantee server safety.' },
        { title: 'Backup Management', desc: 'Store, inspect diff previews, and restore snapshots on demand or via schedule.' }
      ]
    },
    {
      category: 'SPOOFY Music — High-Fidelity Audio',
      icon: Music,
      description: 'Lossless audio streaming directly through your community voice channels.',
      items: [
        { title: 'Music Playback', desc: 'Streams crystal-clear audio with YouTube, Spotify, and direct URL resolution.' },
        { title: 'Queue Management', desc: 'Inspect upcoming tracks, shuffle, remove, or loop the active server queue.' },
        { title: 'Playback Controls', desc: 'Play, pause, resume, skip, and stop via slash commands or the web dashboard.' },
        { title: 'Volume Controls', desc: 'Fine-tune master playback volume between 1% and 100%.' },
        { title: 'Now-Playing Interface', desc: 'Live track titles, audio progress bars, and requester tags in real time.' }
      ]
    },
    {
      category: 'Server Management — Operational Tools',
      icon: Sliders,
      description: 'Comprehensive day-to-day community tools for moderators and administrators.',
      items: [
        { title: 'Moderation Tools', desc: 'Issue formal warnings, manage slowmodes, purge messages, and review member penalty histories.' },
        { title: 'Member Management', desc: 'Inspect account age, join dates, and permission scanner audit results.' },
        { title: 'Custom Configuration', desc: 'Tailor welcome messages, goodbye embeds, and automated support ticket panels.' },
        { title: 'Useful Server Utilities', desc: 'Information lookup commands, server status, and automated role verification.' }
      ]
    }
  ];

  return (
    <div className="container" style={{ padding: '48px 24px 80px', display: 'flex', flexDirection: 'column', gap: '48px' }}>
      {/* Header */}
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          VELORA Platform Overview
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 700, color: '#ffffff', marginTop: '6px', letterSpacing: '-0.02em' }}>
          SPOOFY Feature Architecture
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: '8px', maxWidth: '640px', lineHeight: 1.6 }}>
          Engineered by VELORA: explore the specialized subsystems powering the SPOOFY ecosystem — <strong>SPOOFY Shield</strong>, <strong>SPOOFY Sentinel</strong>, <strong>SPOOFY Recovery</strong>, and <strong>SPOOFY Music</strong>.
        </p>
      </div>

      {/* Feature Groups */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
        {featureGroups.map((group, i) => {
          const Icon = group.icon;
          return (
            <div key={i} className="card" style={{ padding: '32px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                <div style={{
                  width: '36px',
                  height: '36px',
                  borderRadius: '6px',
                  backgroundColor: 'var(--bg-subtle)',
                  border: '1px solid var(--border-default)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--primary)'
                }}>
                  <Icon size={18} />
                </div>
                <div>
                  <h2 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#ffffff' }}>
                    {group.category}
                  </h2>
                </div>
              </div>

              <p style={{ fontSize: '0.875rem', color: 'var(--text-tertiary)', marginBottom: '24px' }}>
                {group.description}
              </p>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '16px' }}>
                {group.items.map((item, j) => (
                  <div key={j} style={{
                    padding: '16px',
                    backgroundColor: 'var(--bg-base)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '6px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '6px'
                  }}>
                    <h3 style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#ffffff' }}>
                      {item.title}
                    </h3>
                    <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                      {item.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom CTA */}
      <div className="card" style={{
        padding: '36px',
        backgroundColor: 'var(--bg-subtle)',
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '20px'
      }}>
        <div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#ffffff' }}>Ready to deploy SPOOFY in your server?</h3>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Instant setup with standard permissions. Fully managed via our clean web dashboard.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <a href={discordInviteUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
            Add to Discord <ExternalLink size={14} />
          </a>
          <Link to="/docs" className="btn btn-secondary">
            View Setup Docs
          </Link>
        </div>
      </div>
    </div>
  );
}
