import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Radio, 
  Database, 
  Music, 
  ArrowRight,
  ExternalLink,
  CheckCircle2,
  TreePine,
  Signpost,
  Wrench,
  Sparkles
} from 'lucide-react';

export default function LandingPage() {
  const [serverInput, setServerInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  const handleFormSubmit = (e) => {
    e.preventDefault();
    if (!acceptedTerms) {
      alert('Please accept the terms of service and privacy policy.');
      return;
    }
    setFormSubmitted(true);
    setTimeout(() => {
      window.open(discordInviteUrl, '_blank');
    }, 800);
  };

  return (
    <div style={{ backgroundColor: '#ffffff', color: '#111111', display: 'flex', flexDirection: 'column' }}>
      
      {/* =========================================================================
          1. HERO SECTION (Editorial "Welcome to SPOOFY." with Misty Mountain Panoramic)
          ========================================================================= */}
      <section style={{ padding: '64px 0 0', overflow: 'hidden' }}>
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '40px',
            alignItems: 'center'
          }}>
            {/* Left Column: Heading & Subtitle */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', zIndex: 2 }}>
              <div style={{
                fontSize: 'clamp(2rem, 3.8vw, 3rem)',
                fontWeight: 300,
                color: '#111111',
                lineHeight: 1.1,
                letterSpacing: '-0.02em'
              }}>
                Welcome to
              </div>

              <h1 style={{
                fontSize: 'clamp(3.4rem, 6.5vw, 5.8rem)',
                fontWeight: 900,
                color: '#000000',
                lineHeight: 0.95,
                letterSpacing: '-0.04em',
                margin: 0
              }}>
                SPOOFY.
              </h1>

              <p style={{
                fontSize: 'clamp(1rem, 1.3vw, 1.2rem)',
                fontStyle: 'italic',
                color: '#444444',
                lineHeight: 1.6,
                maxWidth: '480px',
                marginTop: '6px'
              }}>
                We engineer resilient Discord security, deterministic anti-nuke defense, and lossless audio for ambitious online communities.
              </p>

              {/* Action Buttons */}
              <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '20px', marginTop: '16px' }}>
                <a
                  href={discordInviteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-editorial-black"
                >
                  Start Your Journey
                </a>

                <Link
                  to="/features"
                  className="editorial-link"
                >
                  Learn More →
                </Link>
              </div>
            </div>

            {/* Right Column: Panoramic Mountain Image blending into white */}
            <div style={{ position: 'relative', width: '100%', minHeight: '340px', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
              <div style={{
                width: '100%',
                position: 'relative',
                overflow: 'hidden'
              }}>
                <img
                  src="/assets/editorial_mountains.jpg"
                  alt="Misty Mountain Alpine Landscape"
                  style={{
                    width: '100%',
                    height: 'auto',
                    objectFit: 'cover',
                    display: 'block'
                  }}
                />
                
                {/* Subtle location / telemetry badge at bottom-right */}
                <div style={{
                  position: 'absolute',
                  bottom: '12px',
                  right: '12px',
                  backgroundColor: '#000000',
                  color: '#ffffff',
                  fontSize: '0.625rem',
                  fontFamily: 'var(--font-mono)',
                  letterSpacing: '0.06em',
                  textTransform: 'uppercase',
                  padding: '4px 10px',
                  borderRadius: '2px'
                }}>
                  SPOOFY Shield Cluster — Latency &lt; 15ms
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          2. SECTION 1: "Secure your community." (3-Column Minimal Grid)
          ========================================================================= */}
      <section style={{ padding: '100px 0 80px' }}>
        <div className="container">
          <div style={{ maxWidth: '640px', marginBottom: '48px' }}>
            <h2 style={{
              fontSize: 'clamp(2.2rem, 4vw, 3.2rem)',
              fontWeight: 800,
              color: '#000000',
              lineHeight: 1.1,
              letterSpacing: '-0.03em',
              margin: 0
            }}>
              Secure your community.
            </h2>
            <p style={{
              fontSize: '1rem',
              color: '#555555',
              marginTop: '16px',
              lineHeight: 1.6
            }}>
              Discord moderation should be quiet, deterministic, and dependable. Bring your talents, your members, your discussions — and let's keep them completely safe.
            </p>
          </div>

          {/* 3 Columns */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '48px',
            marginBottom: '40px'
          }}>
            {/* Column 1 */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ width: '32px', height: '32px', color: '#000000', display: 'flex', alignItems: 'center' }}>
                <TreePine size={26} strokeWidth={1.5} />
              </div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#000000', margin: 0 }}>
                Be protected.
              </h3>
              <p style={{ fontSize: '0.875rem', color: '#555555', lineHeight: 1.6, margin: 0 }}>
                We provide the sub-millisecond sliding rate-window defense you need to neutralize mass channel deletions, rogue webhooks, and privilege escalations.
              </p>
            </div>

            {/* Column 2 */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ width: '32px', height: '32px', color: '#000000', display: 'flex', alignItems: 'center' }}>
                <Signpost size={26} strokeWidth={1.5} />
              </div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#000000', margin: 0 }}>
                Get connected.
              </h3>
              <p style={{ fontSize: '0.875rem', color: '#555555', lineHeight: 1.6, margin: 0 }}>
                Join community leaders who monitor with 100% actor attribution. Correlate audit events, eliminate false alerts, and stay accountable to your members.
              </p>
            </div>

            {/* Column 3 */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ width: '32px', height: '32px', color: '#000000', display: 'flex', alignItems: 'center' }}>
                <Wrench size={26} strokeWidth={1.5} />
              </div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#000000', margin: 0 }}>
                Equip yourself.
              </h3>
              <p style={{ fontSize: '0.875rem', color: '#555555', lineHeight: 1.6, margin: 0 }}>
                Discover the automated disaster recovery snapshots and lossless 24/7 audio tools you need to build a dependable, thriving Discord server.
              </p>
            </div>
          </div>

          <div>
            <Link to="/security" className="editorial-link">
              Take the first step today →
            </Link>
          </div>
        </div>
      </section>

      {/* =========================================================================
          3. SECTION 2: "Get started today." (2-Column Editorial Grid with Form Card)
          ========================================================================= */}
      <section style={{
        padding: '100px 0',
        backgroundColor: '#fafafa',
        borderTop: '1px solid #ebebeb',
        borderBottom: '1px solid #ebebeb'
      }}>
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '64px',
            alignItems: 'start'
          }}>
            {/* Left Column: 4 Principle Text Blocks in 2x2 Grid */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '40px' }}>
              <div>
                <h2 style={{
                  fontSize: 'clamp(2.2rem, 4vw, 3.2rem)',
                  fontWeight: 800,
                  color: '#000000',
                  lineHeight: 1.1,
                  letterSpacing: '-0.03em',
                  margin: 0
                }}>
                  Get started today.
                </h2>
                <p style={{
                  fontSize: '1rem',
                  color: '#555555',
                  marginTop: '12px',
                  lineHeight: 1.6
                }}>
                  Introducing the VELORA security framework for modern Discord communities.
                </p>
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                gap: '36px'
              }}>
                <div>
                  <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#000000', marginBottom: '8px' }}>
                    SPOOFY Shield
                  </h4>
                  <p style={{ fontSize: '0.875rem', color: '#555555', lineHeight: 1.6 }}>
                    We believe that true server defense must be deterministic, mathematically transparent, and sub-millisecond.
                  </p>
                </div>

                <div>
                  <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#000000', marginBottom: '8px' }}>
                    SPOOFY Sentinel
                  </h4>
                  <p style={{ fontSize: '0.875rem', color: '#555555', lineHeight: 1.6 }}>
                    We believe that real-time audit correlation with zero false positives empowers moderators to act with confidence.
                  </p>
                </div>

                <div>
                  <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#000000', marginBottom: '8px' }}>
                    SPOOFY Recovery
                  </h4>
                  <p style={{ fontSize: '0.875rem', color: '#555555', lineHeight: 1.6 }}>
                    We believe that community leaders should have peace of mind knowing their entire hierarchy can be recovered in seconds.
                  </p>
                </div>

                <div>
                  <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#000000', marginBottom: '8px' }}>
                    SPOOFY Music
                  </h4>
                  <p style={{ fontSize: '0.875rem', color: '#555555', lineHeight: 1.6 }}>
                    We believe that audio should be crystal-clear, lossless, and reliable 24/7 without constant bot interruptions.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Column: Crisp White Form Card */}
            <div style={{
              backgroundColor: '#ffffff',
              border: '1px solid #e5e5e7',
              borderRadius: '3px',
              padding: '44px 36px',
              boxShadow: '0 8px 30px rgba(0, 0, 0, 0.04)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center'
            }}>
              {/* Minimal Emblem */}
              <div style={{
                width: '44px',
                height: '44px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px'
              }}>
                <img
                  src="/assets/spoofy_logo.png"
                  alt="SPOOFY Emblem"
                  style={{ 
                    width: '100%', 
                    height: '100%', 
                    objectFit: 'contain',
                    filter: 'drop-shadow(0 1px 2px rgba(0, 0, 0, 0.45))'
                  }}
                />
              </div>

              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#000000', margin: 0 }}>
                Deploy SPOOFY today.
              </h3>

              <p style={{ fontSize: '0.875rem', color: '#555555', marginTop: '6px', marginBottom: '24px', lineHeight: 1.5, maxWidth: '280px' }}>
                We help creative community leaders build a safe, honest digital platform.
              </p>

              {formSubmitted ? (
                <div style={{
                  padding: '24px',
                  backgroundColor: '#f8f8fa',
                  border: '1px solid #e5e5e7',
                  borderRadius: '3px',
                  width: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '8px'
                }}>
                  <CheckCircle2 size={24} color="#10b981" />
                  <div style={{ fontSize: '0.875rem', fontWeight: 700, color: '#000000' }}>
                    Redirecting to Discord Authorization...
                  </div>
                  <div style={{ fontSize: '0.75rem', color: '#666666' }}>
                    Please select your server in the Discord OAuth window.
                  </div>
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  <input
                    type="text"
                    placeholder="Server Name or Discord Guild ID"
                    value={serverInput}
                    onChange={(e) => setServerInput(e.target.value)}
                    required
                  />

                  <input
                    type="email"
                    placeholder="Email for Security Alert Dispatches"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    required
                  />

                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.75rem', color: '#555555', textAlign: 'left', marginTop: '4px' }}>
                    <input
                      type="checkbox"
                      id="terms-check"
                      checked={acceptedTerms}
                      onChange={(e) => setAcceptedTerms(e.target.checked)}
                      style={{ cursor: 'pointer' }}
                    />
                    <label htmlFor="terms-check" style={{ cursor: 'pointer' }}>
                      I accept the <Link to="/legal/terms" style={{ textDecoration: 'underline' }}>terms of service</Link> and <Link to="/legal/privacy" style={{ textDecoration: 'underline' }}>privacy policy</Link>.
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="btn-editorial-black"
                    style={{ width: '100%', padding: '12px', marginTop: '8px' }}
                  >
                    Get Started Today
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          4. SECTION 3: EDITORIAL QUOTE BANNER
          ========================================================================= */}
      <section style={{ padding: '80px 0 60px' }}>
        <div className="container">
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            borderLeft: '2px solid #000000',
            paddingLeft: '24px',
            maxWidth: '720px'
          }}>
            <div style={{
              fontSize: '0.6875rem',
              fontWeight: 700,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: '#000000'
            }}>
              We Believe
            </div>
            <div style={{
              fontSize: 'clamp(1.1rem, 2vw, 1.35rem)',
              fontStyle: 'italic',
              color: '#222222',
              lineHeight: 1.6
            }}>
              “The key to building an authentic, honest community is establishing quiet, uncompromising security.”
            </div>
            <div style={{ fontSize: '0.8125rem', color: '#666666', marginTop: '4px' }}>
              — VELORA Engineering Team
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
