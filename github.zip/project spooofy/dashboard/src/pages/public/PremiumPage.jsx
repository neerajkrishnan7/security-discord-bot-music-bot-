import React from 'react';
import { Check, Minus, ExternalLink } from 'lucide-react';

export default function PremiumPage() {
  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  const plans = [
    {
      id: 'community',
      name: 'Community',
      tagline: 'Complete security and music for any growing community.',
      price: '$0',
      period: 'free forever',
      featured: false,
      ctaLabel: 'Add to Discord',
      ctaUrl: discordInviteUrl,
      features: [
        'Full sliding-window anti-nuke engine',
        'Anti-raid panic lockdown controls',
        'Unauthorized bot & webhook removal',
        'Role privilege escalation protection',
        'Real-time Sentinel security alerts',
        'Up to 5 server hierarchy backups',
        'Standard lossless music playback',
        'Community Discord support'
      ]
    },
    {
      id: 'pro',
      name: 'Pro Guild',
      tagline: 'Higher action velocity, 24/7 audio nodes, and expanded storage.',
      price: '$4.99',
      period: 'per month / server',
      featured: true,
      ctaLabel: 'Upgrade in Dashboard',
      ctaUrl: '/dashboard',
      features: [
        'Everything in Community',
        'Up to 50 server hierarchy snapshots',
        '24/7 dedicated voice channel mode',
        'Customizable sliding-window thresholds',
        'Extended 90-day audit log retention',
        'Automated scheduled daily backups',
        'Priority audit log stream ingestion',
        'Priority support channel access'
      ]
    },
    {
      id: 'enterprise',
      name: 'Network',
      tagline: 'Multi-server synchronization for large gaming & creator networks.',
      price: '$14.99',
      period: 'per month / network',
      featured: false,
      ctaLabel: 'Contact Support',
      ctaUrl: '/support',
      features: [
        'Everything in Pro Guild',
        'Multi-guild synchronized trust lists',
        'Unlimited hierarchy snapshots',
        'Dedicated VIP audio routing node',
        '1-year tamper-evident audit logs',
        'Custom command prefixes & branding',
        'Cross-server ban synchronization',
        'Direct developer & staff SLA'
      ]
    }
  ];

  const comparisonFeatures = [
    { name: 'Anti-Nuke Sliding Windows', community: true, pro: true, enterprise: true },
    { name: 'Anti-Raid Automated Lockdown', community: true, pro: true, enterprise: true },
    { name: 'Unauthorized Bot & Webhook Purge', community: true, pro: true, enterprise: true },
    { name: 'Discord Audit Log Attribution', community: true, pro: true, enterprise: true },
    { name: 'Hierarchy Snapshots Stored', community: '5 Snapshots', pro: '50 Snapshots', enterprise: 'Unlimited' },
    { name: '24/7 Music Playback in Voice', community: false, pro: true, enterprise: true },
    { name: 'Dedicated Audio Node Allocation', community: false, pro: false, enterprise: true },
    { name: 'Multi-Server Synchronized Rules', community: false, pro: false, enterprise: true },
    { name: 'Log Retention Duration', community: '14 Days', pro: '90 Days', enterprise: '365 Days' }
  ];

  return (
    <div className="container" style={{ padding: '48px 24px 80px', display: 'flex', flexDirection: 'column', gap: '48px' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', maxWidth: '640px', margin: '0 auto' }}>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Pricing & Plans
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 700, color: '#ffffff', marginTop: '6px', letterSpacing: '-0.02em' }}>
          Transparent protection for every server
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: '8px', lineHeight: 1.6 }}>
          All essential security and anti-nuke features are free forever. Upgrade your server for dedicated audio nodes and expanded backup history.
        </p>
      </div>

      {/* Plan Cards Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '24px',
        alignItems: 'stretch'
      }}>
        {plans.map((plan) => (
          <div
            key={plan.id}
            className="card"
            style={{
              padding: '32px 28px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '24px',
              border: plan.featured ? '1px solid var(--primary-border)' : '1px solid var(--border-default)',
              backgroundColor: plan.featured ? 'var(--bg-surface-hover)' : 'var(--bg-surface)'
            }}
          >
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#ffffff' }}>
                  {plan.name}
                </h3>
                {plan.featured && (
                  <span className="badge badge-primary">Most Popular</span>
                )}
              </div>

              <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', minHeight: '38px', lineHeight: 1.5 }}>
                {plan.tagline}
              </p>

              <div style={{ display: 'flex', alignItems: 'baseline', gap: '6px', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '16px' }}>
                <span style={{ fontSize: '2.25rem', fontWeight: 700, color: '#ffffff' }}>{plan.price}</span>
                <span style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)' }}>{plan.period}</span>
              </div>

              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.875rem' }}>
                {plan.features.map((feat, i) => (
                  <li key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'var(--text-secondary)' }}>
                    <Check size={14} color="var(--primary)" style={{ flexShrink: 0 }} />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <a
              href={plan.ctaUrl}
              className={`btn ${plan.featured ? 'btn-primary' : 'btn-secondary'}`}
              style={{ width: '100%', justifyContent: 'center' }}
            >
              {plan.ctaLabel}
            </a>
          </div>
        ))}
      </div>

      {/* Feature Comparison Matrix */}
      <div style={{ marginTop: '24px' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff', marginBottom: '16px', letterSpacing: '-0.02em' }}>
          Feature Comparison
        </h2>

        <div className="card" style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th style={{ width: '40%' }}>Feature</th>
                <th style={{ width: '20%' }}>Community</th>
                <th style={{ width: '20%' }}>Pro Guild</th>
                <th style={{ width: '20%' }}>Network</th>
              </tr>
            </thead>
            <tbody>
              {comparisonFeatures.map((row, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 500, color: '#ffffff' }}>{row.name}</td>
                  <td>
                    {typeof row.community === 'boolean' ? (
                      row.community ? <Check size={16} color="#10b981" /> : <Minus size={16} color="var(--text-tertiary)" />
                    ) : (
                      <span style={{ color: 'var(--text-secondary)' }}>{row.community}</span>
                    )}
                  </td>
                  <td>
                    {typeof row.pro === 'boolean' ? (
                      row.pro ? <Check size={16} color="#10b981" /> : <Minus size={16} color="var(--text-tertiary)" />
                    ) : (
                      <span style={{ color: '#ffffff', fontWeight: 500 }}>{row.pro}</span>
                    )}
                  </td>
                  <td>
                    {typeof row.enterprise === 'boolean' ? (
                      row.enterprise ? <Check size={16} color="#10b981" /> : <Minus size={16} color="var(--text-tertiary)" />
                    ) : (
                      <span style={{ color: '#ffffff', fontWeight: 600 }}>{row.enterprise}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
