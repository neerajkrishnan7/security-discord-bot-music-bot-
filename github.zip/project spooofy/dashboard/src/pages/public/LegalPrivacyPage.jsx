import React from 'react';

export default function LegalPrivacyPage() {
  return (
    <div className="container" style={{ padding: '48px 24px 80px', maxWidth: '800px', display: 'flex', flexDirection: 'column', gap: '28px' }}>
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Legal & Privacy
        </div>
        <h1 style={{ fontSize: '2.25rem', fontWeight: 700, color: '#ffffff', marginTop: '6px', letterSpacing: '-0.02em' }}>
          Privacy Policy
        </h1>
        <p style={{ color: 'var(--text-tertiary)', fontSize: '0.8125rem', marginTop: '4px' }}>
          Last updated: October 2026
        </p>
      </div>

      <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '24px', fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
        <div>
          <h2 style={{ fontSize: '1.0625rem', fontWeight: 600, color: '#ffffff', marginBottom: '8px' }}>
            1. Information We Collect
          </h2>
          <p>SPOOFY collects only the minimal data required to provide server protection, anti-nuke surveillance, and moderation:</p>
          <ul style={{ paddingLeft: '20px', marginTop: '8px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <li>Discord User IDs, server IDs, and role IDs for permission verification and allowlist enforcement.</li>
            <li>Audit log event metadata (action types, timestamps, affected resource IDs) strictly for rate-limit threshold evaluation.</li>
            <li>Server channel and role hierarchy snapshots created at the explicit request of server managers.</li>
          </ul>
        </div>

        <div>
          <h2 style={{ fontSize: '1.0625rem', fontWeight: 600, color: '#ffffff', marginBottom: '8px' }}>
            2. How Information is Used
          </h2>
          <p>
            We use this data exclusively to enforce security rate limits, detect join raids, provide snapshot rollbacks, and render management dashboards. We do not inspect, log, or store private user messages, and we never monetize or transfer user data to third parties.
          </p>
        </div>

        <div>
          <h2 style={{ fontSize: '1.0625rem', fontWeight: 600, color: '#ffffff', marginBottom: '8px' }}>
            3. Data Retention & Deletion
          </h2>
          <p>
            Server snapshots and moderation logs are retained until purged by authorized guild administrators or when the bot is removed from the server. Users may request full account and guild data deletion at any time via our support portal.
          </p>
        </div>
      </div>
    </div>
  );
}
