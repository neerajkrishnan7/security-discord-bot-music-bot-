import React from 'react';

export default function LegalTermsPage() {
  return (
    <div className="container" style={{ padding: '48px 24px 80px', maxWidth: '800px', display: 'flex', flexDirection: 'column', gap: '28px' }}>
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Terms & Conditions
        </div>
        <h1 style={{ fontSize: '2.25rem', fontWeight: 700, color: '#ffffff', marginTop: '6px', letterSpacing: '-0.02em' }}>
          Terms of Service
        </h1>
        <p style={{ color: 'var(--text-tertiary)', fontSize: '0.8125rem', marginTop: '4px' }}>
          Last updated: October 2026
        </p>
      </div>

      <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '24px', fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
        <div>
          <h2 style={{ fontSize: '1.0625rem', fontWeight: 600, color: '#ffffff', marginBottom: '8px' }}>
            1. Acceptance of Terms
          </h2>
          <p>
            By adding the SPOOFY Discord bot to your Discord server or using the SPOOFY web dashboard, you agree to comply with these Terms of Service and Discord's Terms of Service and Community Guidelines.
          </p>
        </div>

        <div>
          <h2 style={{ fontSize: '1.0625rem', fontWeight: 600, color: '#ffffff', marginBottom: '8px' }}>
            2. Acceptable Use
          </h2>
          <p>
            You agree not to utilize SPOOFY to disrupt Discord's infrastructure, bypass API rate limits, engage in unauthorized mass data harvesting, or initiate malicious server destructions. Automated rate limits are enforced to protect community integrity.
          </p>
        </div>

        <div>
          <h2 style={{ fontSize: '1.0625rem', fontWeight: 600, color: '#ffffff', marginBottom: '8px' }}>
            3. Availability & Warranties
          </h2>
          <p>
            SPOOFY is provided "as is" with high-availability architecture. While we maintain 99.9% uptime across our gateway nodes and databases, we are not liable for Discord API platform outages, network partitioning, or user configuration errors.
          </p>
        </div>
      </div>
    </div>
  );
}
