import React, { useState, useEffect } from 'react';
import { Search, Terminal, Copy, Check, Shield, Music, Sliders, Users, Wrench } from 'lucide-react';
import { fetchPublicCommands } from '../../api';

export default function CommandsPage() {
  const [commands, setCommands] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [copiedCmd, setCopiedCmd] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchPublicCommands()
      .then(setCommands)
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  const categories = ['ALL', 'Security', 'Moderation', 'Music', 'Utility', 'Configuration'];

  const filtered = commands.filter(c => {
    if (selectedCategory !== 'ALL' && c.category !== selectedCategory) return false;
    if (search) {
      const q = search.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) || c.syntax.toLowerCase().includes(q);
    }
    return true;
  });

  const handleCopy = (text) => {
    navigator.clipboard?.writeText(text);
    setCopiedCmd(text);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const getCategoryIcon = (cat) => {
    switch (cat) {
      case 'Security': return <Shield size={14} color="var(--primary)" />;
      case 'Moderation': return <Users size={14} color="#f59e0b" />;
      case 'Music': return <Music size={14} color="#06b6d4" />;
      case 'Utility': return <Wrench size={14} color="#10b981" />;
      case 'Configuration': return <Sliders size={14} color="#a78bfa" />;
      default: return <Terminal size={14} />;
    }
  };

  return (
    <div className="container" style={{ padding: '48px 24px 80px', display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Page Header */}
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          SPOOFY Command Directory
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, color: '#000000', marginTop: '6px', letterSpacing: '-0.03em' }}>
          Slash Commands.
        </h1>
        <p style={{ color: '#555555', marginTop: '6px', maxWidth: '600px', lineHeight: 1.6 }}>
          Searchable reference for all supported SPOOFY Discord slash commands, usage parameters, and permission requirements.
        </p>
      </div>

      {/* Search Bar & Category Filter Bar */}
      <div className="card" style={{ padding: '16px 20px', display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '16px', backgroundColor: '#ffffff', border: '1px solid #e5e5e7' }}>
        {/* Category Pills */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '6px 14px',
                  borderRadius: '3px',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                  cursor: 'pointer',
                  border: isSelected ? '1px solid #000000' : '1px solid #e5e5e7',
                  backgroundColor: isSelected ? '#000000' : '#ffffff',
                  color: isSelected ? '#ffffff' : '#666666',
                  transition: 'all 0.15s ease'
                }}
              >
                {cat !== 'ALL' && getCategoryIcon(cat)}
                {cat}
              </button>
            );
          })}
        </div>

        {/* Search Input */}
        <div style={{ position: 'relative', width: '280px', maxWidth: '100%' }}>
          <Search size={15} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
          <input
            type="search"
            placeholder="Search commands or syntax..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ paddingLeft: '32px', fontSize: '0.8125rem' }}
          />
        </div>
      </div>

      {/* Commands Grid */}
      {isLoading ? (
        <div style={{ padding: '60px 0', textAlign: 'center', color: 'var(--text-secondary)' }}>
          Loading command catalog...
        </div>
      ) : filtered.length === 0 ? (
        <div className="card" style={{ padding: '48px', textAlign: 'center', color: 'var(--text-tertiary)' }}>
          No commands matched your query "{search}". Try searching for another keyword or selecting "ALL".
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '16px' }}>
          {filtered.map((cmd) => (
            <div
              key={cmd.name}
              className="card"
              style={{
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                gap: '16px'
              }}
            >
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span className="mono-text" style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#ffffff' }}>
                    {cmd.name}
                  </span>
                  <span className="badge" style={{ fontSize: '0.7rem' }}>
                    {cmd.category}
                  </span>
                </div>

                <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                  {cmd.description}
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {/* Syntax Code Snippet */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  backgroundColor: 'var(--bg-base)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: '4px',
                  padding: '6px 10px',
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.75rem',
                  color: 'var(--text-primary)'
                }}>
                  <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {cmd.syntax}
                  </span>
                  <button
                    onClick={() => handleCopy(cmd.syntax)}
                    className="btn btn-ghost"
                    style={{ padding: '2px', height: 'auto', color: 'var(--text-tertiary)' }}
                    title="Copy command"
                  >
                    {copiedCmd === cmd.syntax ? <Check size={13} color="#10b981" /> : <Copy size={13} />}
                  </button>
                </div>

                {/* Required Permissions Footer */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                  <span>Permissions</span>
                  <span style={{ color: cmd.permissions.includes('Server Owner') ? '#fca5a5' : 'var(--text-secondary)', fontWeight: 500 }}>
                    {cmd.permissions}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
