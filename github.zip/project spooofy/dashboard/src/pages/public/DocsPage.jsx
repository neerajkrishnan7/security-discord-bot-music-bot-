import React, { useState } from 'react';
import { 
  BookOpen, 
  Shield, 
  Music, 
  Sliders, 
  HelpCircle, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  ExternalLink,
  ArrowRight,
  Terminal
} from 'lucide-react';
import { Link } from 'react-router-dom';

export default function DocsPage() {
  const [activeSection, setActiveSection] = useState('getting-started');
  const [openFaq, setOpenFaq] = useState(null);

  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  const sections = [
    { id: 'getting-started', label: 'Getting Started', icon: BookOpen },
    { id: 'bot-setup', label: 'Bot Setup & Roles', icon: Sliders },
    { id: 'security-config', label: 'Security Configuration', icon: Shield },
    { id: 'music-commands', label: 'Music Commands', icon: Music },
    { id: 'faq', label: 'Frequently Asked Questions', icon: HelpCircle },
    { id: 'troubleshooting', label: 'Troubleshooting', icon: AlertTriangle }
  ];

  const faqs = [
    {
      q: "Why must SPOOFY's role be placed near the top of the Discord role hierarchy?",
      a: "Discord strictly prevents any bot from banning, kicking, timing out, or stripping roles from users whose highest role is equal to or higher than the bot's own role. Placing SPOOFY at the top ensures it can isolate rogue moderators and enforce anti-nuke rules."
    },
    {
      q: "How does the sliding-window anti-nuke algorithm work?",
      a: "Instead of a static counter that resets every minute, SPOOFY evaluates action timestamps within rolling windows (e.g., 2 channel deletions within 10 seconds). If the velocity threshold is exceeded, the perpetrator is immediately banned or quarantined, and channels are queued for automatic recovery."
    },
    {
      q: "Can ordinary server administrators access the staff portal or owner admin panel?",
      a: "No. SPOOFY enforces three distinct authorization perimeters. Server administrators can only manage their authorized servers via `/dashboard`. The `/staff` and `/admin` portals require internal database credentials."
    },
    {
      q: "What audio sources and formats does SPOOFY Music support?",
      a: "SPOOFY streams via high-performance Lavalink nodes supporting direct URLs, sound streams, and audio searches with loss-free 320kbps playback."
    },
    {
      q: "Does SPOOFY store private user messages?",
      a: "No. SPOOFY only stores guild metadata, configuration rules, and security incident audit logs. Message content is never recorded or stored in the database."
    }
  ];

  return (
    <div className="container" style={{ padding: '48px 24px 80px', display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Header */}
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Documentation & Guides
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, color: '#000000', marginTop: '6px', letterSpacing: '-0.03em' }}>
          Setup Guide & Reference.
        </h1>
        <p style={{ color: '#555555', marginTop: '6px', maxWidth: '600px', lineHeight: 1.6 }}>
          Clear setup walkthroughs, role hierarchy guidelines, security threshold configurations, and music commands.
        </p>
      </div>

      {/* Docs Layout: Sidebar Navigation + Content */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(200px, 240px) 1fr',
        gap: '32px',
        alignItems: 'start'
      }}>
        {/* Navigation Sidebar */}
        <div className="card" style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '2px', position: 'sticky', top: '80px', backgroundColor: '#ffffff', border: '1px solid #e5e5e7' }}>
          {sections.map((s) => {
            const Icon = s.icon;
            const isSelected = activeSection === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '9px 12px',
                  borderRadius: '3px',
                  border: 'none',
                  backgroundColor: isSelected ? '#000000' : 'transparent',
                  color: isSelected ? '#ffffff' : '#555555',
                  fontSize: '0.8125rem',
                  fontWeight: isSelected ? 600 : 500,
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.15s ease'
                }}
              >
                <Icon size={15} color={isSelected ? '#ffffff' : '#888888'} />
                {s.label}
              </button>
            );
          })}
        </div>

        {/* Content Pane */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* Section 1: Getting Started */}
          {activeSection === 'getting-started' && (
            <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff' }}>Getting Started</h2>
                <p style={{ marginTop: '8px', lineHeight: 1.6 }}>
                  SPOOFY is designed for swift deployment in any Discord community. Within three steps, your server is shielded against rogue administrators and join raids.
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginTop: '8px' }}>
                <div style={{ display: 'flex', gap: '16px' }}>
                  <div style={{ width: '28px', height: '28px', borderRadius: '50%', backgroundColor: 'var(--primary)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '0.8125rem', flexShrink: 0 }}>
                    1
                  </div>
                  <div>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#ffffff' }}>Authorize SPOOFY to Your Server</h3>
                    <p style={{ fontSize: '0.875rem', marginTop: '4px', lineHeight: 1.5 }}>
                      Use the official invite link to add SPOOFY. We recommend granting Administrator permissions so the bot can reconstruct channels and moderate rogue actors without permission errors.
                    </p>
                    <a
                      href={discordInviteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn btn-primary btn-sm"
                      style={{ marginTop: '10px' }}
                    >
                      Authorize Bot <ExternalLink size={13} />
                    </a>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '16px' }}>
                  <div style={{ width: '28px', height: '28px', borderRadius: '50%', backgroundColor: 'var(--bg-subtle)', border: '1px solid var(--border-default)', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '0.8125rem', flexShrink: 0 }}>
                    2
                  </div>
                  <div>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#ffffff' }}>Position the SPOOFY Role</h3>
                    <p style={{ fontSize: '0.875rem', marginTop: '4px', lineHeight: 1.5 }}>
                      Open <strong>Server Settings &rarr; Roles</strong> in Discord. Drag the <code>SPOOFY</code> role above all community and moderator roles.
                    </p>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '16px' }}>
                  <div style={{ width: '28px', height: '28px', borderRadius: '50%', backgroundColor: 'var(--bg-subtle)', border: '1px solid var(--border-default)', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '0.8125rem', flexShrink: 0 }}>
                    3
                  </div>
                  <div>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#ffffff' }}>Open the Guild Dashboard</h3>
                    <p style={{ fontSize: '0.875rem', marginTop: '4px', lineHeight: 1.5 }}>
                      Sign in with your Discord account to review protection thresholds, designate logging channels, and inspect audit logs.
                    </p>
                    <Link to="/dashboard" className="btn btn-secondary btn-sm" style={{ marginTop: '10px' }}>
                      Go to Dashboard
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 2: Bot Setup & Roles */}
          {activeSection === 'bot-setup' && (
            <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff' }}>Bot Setup & Role Hierarchy</h2>
                <p style={{ marginTop: '8px', lineHeight: 1.6 }}>
                  Proper Discord role configuration is critical for anti-nuke effectiveness.
                </p>
              </div>

              <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#f59e0b', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <AlertTriangle size={15} /> Role Hierarchy Rule
                </div>
                <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
                  Discord uses a top-down hierarchy. SPOOFY cannot ban or remove roles from a user whose highest role sits above SPOOFY's role. For complete protection, ensure:
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '12px', fontSize: '0.8125rem', fontFamily: 'var(--font-mono)' }}>
                  <div style={{ padding: '6px 10px', backgroundColor: 'var(--bg-surface)', borderRadius: '4px', color: '#a78bfa' }}>1. [Server Owner]</div>
                  <div style={{ padding: '6px 10px', backgroundColor: 'var(--primary-subtle)', borderRadius: '4px', color: '#ffffff', fontWeight: 600, border: '1px solid var(--primary-border)' }}>2. [SPOOFY Bot Role] &larr; Placed here</div>
                  <div style={{ padding: '6px 10px', backgroundColor: 'var(--bg-surface)', borderRadius: '4px', color: 'var(--text-secondary)' }}>3. [Administrator / Head Moderator]</div>
                  <div style={{ padding: '6px 10px', backgroundColor: 'var(--bg-surface)', borderRadius: '4px', color: 'var(--text-secondary)' }}>4. [Moderator / Staff]</div>
                  <div style={{ padding: '6px 10px', backgroundColor: 'var(--bg-surface)', borderRadius: '4px', color: 'var(--text-tertiary)' }}>5. [@everyone]</div>
                </div>
              </div>
            </div>
          )}

          {/* Section 3: Security Configuration */}
          {activeSection === 'security-config' && (
            <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff' }}>Security Configuration</h2>
                <p style={{ marginTop: '8px', lineHeight: 1.6 }}>
                  SPOOFY Shield monitors nine critical action vectors using customizable sliding-window rate limits.
                </p>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
                <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Anti-Channel Delete</div>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                    Prevents mass channel deletions. Default limit: 2 channels within 10 seconds. Auto-restores deleted channels.
                  </p>
                </div>

                <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Anti-Role Abuse</div>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                    Detects unauthorized administrator permission escalation on existing roles. Strips dangerous permissions instantly.
                  </p>
                </div>

                <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Anti-Webhook Hijacking</div>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                    Purges webhooks created by unauthorized accounts and bans the creator if threshold is breached.
                  </p>
                </div>

                <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Emergency Lockdown</div>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                    Automatically freezes send message and speak permissions for @everyone upon detecting raid join velocity spikes.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Section 4: Music Commands */}
          {activeSection === 'music-commands' && (
            <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff' }}>Music Commands & Playback</h2>
                <p style={{ marginTop: '8px', lineHeight: 1.6 }}>
                  SPOOFY streams high-fidelity audio directly into your community voice channels.
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {[
                  { cmd: '/music play <query|url>', desc: 'Join your voice channel and stream the requested song or playlist.' },
                  { cmd: '/music pause', desc: 'Pause the current audio stream without dropping position.' },
                  { cmd: '/music skip', desc: 'Vote or immediately skip to the next track in queue.' },
                  { cmd: '/music stop', desc: 'Halt playback and clear the active queue.' },
                  { cmd: '/music volume <1-100>', desc: 'Adjust playback volume (default: 80%).' },
                  { cmd: '/music queue', desc: 'Inspect upcoming songs in the server queue.' }
                ].map((item, i) => (
                  <div key={i} style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '12px 16px',
                    borderRadius: '6px',
                    backgroundColor: 'var(--bg-base)',
                    border: '1px solid var(--border-subtle)',
                    gap: '12px'
                  }}>
                    <code style={{ color: 'var(--primary)', fontWeight: 600, fontSize: '0.8125rem' }}>{item.cmd}</code>
                    <span style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>{item.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 5: FAQ */}
          {activeSection === 'faq' && (
            <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff' }}>Frequently Asked Questions</h2>
                <p style={{ marginTop: '8px', lineHeight: 1.6 }}>
                  Answers to the most common configuration and security inquiries.
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '8px' }}>
                {faqs.map((faq, i) => {
                  const isOpen = openFaq === i;
                  return (
                    <div
                      key={i}
                      style={{
                        backgroundColor: 'var(--bg-base)',
                        border: '1px solid var(--border-subtle)',
                        borderRadius: '6px',
                        overflow: 'hidden'
                      }}
                    >
                      <button
                        onClick={() => setOpenFaq(isOpen ? null : i)}
                        style={{
                          width: '100%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '14px 18px',
                          border: 'none',
                          backgroundColor: 'transparent',
                          color: '#ffffff',
                          fontWeight: 600,
                          fontSize: '0.9375rem',
                          cursor: 'pointer',
                          textAlign: 'left'
                        }}
                      >
                        <span>{faq.q}</span>
                        {isOpen ? <ChevronUp size={16} color="var(--primary)" /> : <ChevronDown size={16} color="var(--text-tertiary)" />}
                      </button>
                      {isOpen && (
                        <div style={{ padding: '0 18px 16px', fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                          {faq.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Section 6: Troubleshooting */}
          {activeSection === 'troubleshooting' && (
            <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ffffff' }}>Troubleshooting & Diagnostics</h2>
                <p style={{ marginTop: '8px', lineHeight: 1.6 }}>
                  Solutions for common Discord permission mismatches and gateway latency.
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                  <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#fca5a5' }}>Error: "Missing Permissions" when executing an action</h4>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
                    This occurs if the target user has a role positioned higher than SPOOFY's role. Move the SPOOFY role to the top of your server role list in Discord Server Settings.
                  </p>
                </div>

                <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                  <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#fcd34d' }}>Alerts showing delayed actor attribution</h4>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
                    Discord audit logs experience occasional upstream API ingestion latency (typically 200ms - 1500ms). SPOOFY Sentinel uses exponential retry algorithms with jitter to safely resolve the exact executor without race conditions.
                  </p>
                </div>

                <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
                  <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#ffffff' }}>Need live engineer assistance?</h4>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
                    Join our support server to speak directly with our team or run automated guild diagnostics.
                  </p>
                  <Link to="/support" className="btn btn-secondary btn-sm" style={{ marginTop: '10px' }}>
                    Visit Support Hub
                  </Link>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
