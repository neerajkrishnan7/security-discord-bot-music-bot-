import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Cpu, 
  Lock, 
  Terminal, 
  Radio, 
  Database, 
  Music, 
  CheckCircle2, 
  ArrowRight,
  ExternalLink,
  Layers,
  Sparkles,
  Server,
  Zap,
  Users
} from 'lucide-react';

export default function CompanyPage() {
  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '80px', padding: '48px 0 96px' }}>
      
      {/* 1. Header / Hero */}
      <section className="container">
        <div style={{ maxWidth: '840px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            padding: '4px 12px',
            borderRadius: '9999px',
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            width: 'fit-content',
            fontSize: '0.75rem',
            color: 'var(--text-secondary)'
          }}>
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'var(--primary)' }} />
            VELORA TECHNOLOGIES INC.
          </div>

          <h1 style={{
            fontSize: 'clamp(2.4rem, 4vw, 3.4rem)',
            fontWeight: 700,
            color: '#ffffff',
            lineHeight: 1.15,
            letterSpacing: '-0.03em'
          }}>
            Engineering resilient infrastructure and security for modern online communities.
          </h1>

          <p style={{
            fontSize: '1.125rem',
            color: 'var(--text-secondary)',
            lineHeight: 1.6,
            maxWidth: '680px'
          }}>
            VELORA is a cybersecurity and infrastructure software company. We are the architects behind <strong>SPOOFY</strong>, the unified Discord security and audio platform protecting over 10,000 servers worldwide.
          </p>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', marginTop: '12px' }}>
            <a
              href={discordInviteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary"
            >
              Add SPOOFY to Discord <ExternalLink size={14} />
            </a>
            <Link to="/docs" className="btn btn-secondary">
              Read Technical Specs
            </Link>
          </div>
        </div>
      </section>

      {/* 2. Core Pillars & Brand Architecture */}
      <section className="container">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--primary)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
              Product Ecosystem
            </div>
            <h2 style={{ fontSize: '1.75rem', fontWeight: 700, color: '#ffffff', marginTop: '6px' }}>
              The SPOOFY Suite by VELORA
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', maxWidth: '600px' }}>
              Four specialized, integrated systems built upon high-performance asynchronous microservices.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
            {/* SPOOFY Shield */}
            <div className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{
                width: '38px',
                height: '38px',
                borderRadius: '6px',
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                border: '1px solid rgba(99, 102, 241, 0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--primary)'
              }}>
                <ShieldCheck size={20} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.125rem', fontWeight: 700, color: '#ffffff' }}>SPOOFY Shield</h3>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>Security & Anti-Nuke Engine</div>
                <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '10px', lineHeight: 1.5 }}>
                  Sub-millisecond sliding rate-window evaluation that detects mass channel deletions, unauthorized webhooks, role stripping, and administrator permission escalations.
                </p>
              </div>
              <div style={{ marginTop: 'auto', paddingTop: '12px', borderTop: '1px solid var(--border-neutral)' }}>
                <Link to="/security" style={{ fontSize: '0.8125rem', color: 'var(--primary)', display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                  Explore Shield Architecture <ArrowRight size={13} />
                </Link>
              </div>
            </div>

            {/* SPOOFY Sentinel */}
            <div className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{
                width: '38px',
                height: '38px',
                borderRadius: '6px',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                border: '1px solid rgba(245, 158, 11, 0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#f59e0b'
              }}>
                <Radio size={20} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.125rem', fontWeight: 700, color: '#ffffff' }}>SPOOFY Sentinel</h3>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>Surveillance & Audit Correlation</div>
                <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '10px', lineHeight: 1.5 }}>
                  Continuous audit log ingestion correlating Discord snowflakes with actions, severity classifications, and immediate WebSocket notifications to web consoles.
                </p>
              </div>
              <div style={{ marginTop: 'auto', paddingTop: '12px', borderTop: '1px solid var(--border-neutral)' }}>
                <Link to="/features" style={{ fontSize: '0.8125rem', color: 'var(--primary)', display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                  Learn about Sentinel <ArrowRight size={13} />
                </Link>
              </div>
            </div>

            {/* SPOOFY Recovery */}
            <div className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{
                width: '38px',
                height: '38px',
                borderRadius: '6px',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                border: '1px solid rgba(16, 185, 129, 0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#10b981'
              }}>
                <Database size={20} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.125rem', fontWeight: 700, color: '#ffffff' }}>SPOOFY Recovery</h3>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>Disaster Recovery & Snapshots</div>
                <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '10px', lineHeight: 1.5 }}>
                  Automated state backups capturing channel hierarchy, roles, color palettes, permission overwrites, and vanity configurations with clean 1-click rollback.
                </p>
              </div>
              <div style={{ marginTop: 'auto', paddingTop: '12px', borderTop: '1px solid var(--border-neutral)' }}>
                <Link to="/docs" style={{ fontSize: '0.8125rem', color: 'var(--primary)', display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                  Snapshot Technical Details <ArrowRight size={13} />
                </Link>
              </div>
            </div>

            {/* SPOOFY Music */}
            <div className="card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{
                width: '38px',
                height: '38px',
                borderRadius: '6px',
                backgroundColor: 'rgba(236, 72, 153, 0.1)',
                border: '1px solid rgba(236, 72, 153, 0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#ec4899'
              }}>
                <Music size={20} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.125rem', fontWeight: 700, color: '#ffffff' }}>SPOOFY Music</h3>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>Lossless 24/7 Audio Engine</div>
                <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '10px', lineHeight: 1.5 }}>
                  High-fidelity audio delivery with 24/7 persistent voice connection, buffer-free playback, custom equalizers, and real-time dashboard controllers.
                </p>
              </div>
              <div style={{ marginTop: 'auto', paddingTop: '12px', borderTop: '1px solid var(--border-neutral)' }}>
                <Link to="/music" style={{ fontSize: '0.8125rem', color: 'var(--primary)', display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                  View Music Features <ArrowRight size={13} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Engineering Rigor & Technology Stack */}
      <section className="container">
        <div style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '8px',
          padding: '40px',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '40px'
        }}>
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Engineering Standards
            </div>
            <h2 style={{ fontSize: '1.75rem', fontWeight: 700, color: '#ffffff', marginTop: '6px' }}>
              Built for production scale and zero trust
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '10px', lineHeight: 1.6 }}>
              VELORA builds software that community leaders rely on during high-pressure incidents. Every component in SPOOFY is designed around defensive isolation, predictable memory footprints, and low-latency execution.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '24px' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                <CheckCircle2 size={16} color="#10b981" style={{ marginTop: '3px', flexShrink: 0 }} />
                <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  <strong>Memory-Mapped Rate Limiting:</strong> In-memory sliding windows record action counts per actor snowflake without querying remote databases, eliminating latency.
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                <CheckCircle2 size={16} color="#10b981" style={{ marginTop: '3px', flexShrink: 0 }} />
                <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  <strong>SQLite WAL Storage:</strong> High-throughput local database storage with Write-Ahead Logging for zero-contention writes and sub-millisecond lookups.
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                <CheckCircle2 size={16} color="#10b981" style={{ marginTop: '3px', flexShrink: 0 }} />
                <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  <strong>Air-Gapped Restoration:</strong> Restored roles and permissions undergo sanitization passes so that rogue Administrator tokens are never re-injected.
                </span>
              </div>
            </div>
          </div>

          <div style={{
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '6px',
            padding: '24px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            gap: '24px'
          }}>
            <div>
              <div style={{ fontSize: '0.8125rem', fontWeight: 700, color: '#ffffff' }}>
                VELORA Platform Health Telemetry
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>
                Live production indicators
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#ffffff', fontFamily: 'var(--font-mono)' }}>99.99%</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>Cluster Uptime</div>
              </div>
              <div>
                <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#10b981', fontFamily: 'var(--font-mono)' }}>&lt;15ms</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>Gateway Ping Latency</div>
              </div>
              <div>
                <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#ffffff', fontFamily: 'var(--font-mono)' }}>10,000+</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>Protected Communities</div>
              </div>
              <div>
                <div style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--primary)', fontFamily: 'var(--font-mono)' }}>0.2ms</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>Storage Read/Write</div>
              </div>
            </div>

            <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', borderTop: '1px solid var(--border-neutral)', paddingTop: '12px' }}>
              Independently verified and monitored across distributed global edge points.
            </div>
          </div>
        </div>
      </section>

      {/* 4. Company Values & Privacy Commitments */}
      <section className="container">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--primary)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
              Our Philosophy
            </div>
            <h2 style={{ fontSize: '1.75rem', fontWeight: 700, color: '#ffffff', marginTop: '6px' }}>
              What guides VELORA
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '20px' }}>
            <div className="card" style={{ padding: '24px' }}>
              <div style={{ fontSize: '1rem', fontWeight: 700, color: '#ffffff' }}>1. Zero Data Harvesting</div>
              <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '8px', lineHeight: 1.5 }}>
                We believe security tools should respect user privacy. VELORA does not harvest member message histories or sell analytics. Data is processed locally and discarded upon sliding window expiry.
              </p>
            </div>

            <div className="card" style={{ padding: '24px' }}>
              <div style={{ fontSize: '1rem', fontWeight: 700, color: '#ffffff' }}>2. Deterministic Defense</div>
              <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '8px', lineHeight: 1.5 }}>
                Instead of unpredictable black-box heuristics, SPOOFY Shield and Sentinel rely on transparent, mathematically verifiable rate limits and strict permission correlation.
              </p>
            </div>

            <div className="card" style={{ padding: '24px' }}>
              <div style={{ fontSize: '1rem', fontWeight: 700, color: '#ffffff' }}>3. Enterprise Reliability</div>
              <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '8px', lineHeight: 1.5 }}>
                We engineer our systems to remain fully operational during massive Discord DDoS events, coordinated member surges, and infrastructure brownouts.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Call to Action Banner */}
      <section className="container">
        <div style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '8px',
          padding: '48px',
          textAlign: 'center',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '16px'
        }}>
          <h2 style={{ fontSize: '2rem', fontWeight: 700, color: '#ffffff', letterSpacing: '-0.02em' }}>
            Ready to secure your Discord server with VELORA?
          </h2>
          <p style={{ fontSize: '1rem', color: 'var(--text-secondary)', maxWidth: '520px', lineHeight: 1.6 }}>
            Deploy SPOOFY in less than two minutes. Instant anti-nuke defense, 24/7 lossless music, and live audit intelligence.
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', marginTop: '8px' }}>
            <a
              href={discordInviteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary"
              style={{ padding: '10px 24px', fontSize: '0.9375rem' }}
            >
              Add SPOOFY to Discord <ExternalLink size={15} />
            </a>
            <Link to="/dashboard" className="btn btn-secondary" style={{ padding: '10px 24px', fontSize: '0.9375rem' }}>
              Manage in Web Console
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
