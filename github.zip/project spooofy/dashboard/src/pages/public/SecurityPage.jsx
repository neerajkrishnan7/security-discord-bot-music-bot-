import React from 'react';
import { ShieldCheck, Radio, Database, Lock, Sliders, CheckCircle2, AlertTriangle, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function SecurityPage() {
  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  return (
    <div className="container" style={{ padding: '48px 24px 80px', display: 'flex', flexDirection: 'column', gap: '48px' }}>
      {/* Header */}
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          VELORA Security Architecture
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 700, color: '#ffffff', marginTop: '6px', letterSpacing: '-0.02em' }}>
          SPOOFY Shield & Anti-Nuke
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: '8px', maxWidth: '640px', lineHeight: 1.6 }}>
          Engineered by VELORA. Discord servers frequently suffer from compromised moderator accounts and unauthorized deletions. SPOOFY Shield uses mathematical sliding windows to intercept attacks before catastrophic wiping occurs.
        </p>
      </div>

      {/* Module 1: Sliding Window Rate Limiting */}
      <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Sliders size={20} color="var(--primary)" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#ffffff' }}>
            Sliding-Window Rate Limiting Engine
          </h2>
        </div>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          Unlike static timers that reset on fixed minute boundaries, SPOOFY Shield records timestamps in rolling memory windows. Destructive events are checked continuously against strict per-actor velocity ceilings:
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '16px' }}>
          <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Channel Deletions</div>
            <div className="mono-text" style={{ fontSize: '0.8125rem', color: 'var(--primary)', marginTop: '4px' }}>Threshold: 2 deletions / 10s</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '6px' }}>Response: Instant Ban + Channel Auto-Restore</div>
          </div>

          <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Role Deletions</div>
            <div className="mono-text" style={{ fontSize: '0.8125rem', color: 'var(--primary)', marginTop: '4px' }}>Threshold: 2 deletions / 10s</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '6px' }}>Response: Instant Ban + Role Snapshot Rebuild</div>
          </div>

          <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Mass Bans & Kicks</div>
            <div className="mono-text" style={{ fontSize: '0.8125rem', color: 'var(--primary)', marginTop: '4px' }}>Threshold: 3 actions / 20s</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '6px' }}>Response: Immediate Role Stripping & Quarantine</div>
          </div>

          <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Permission Escalation</div>
            <div className="mono-text" style={{ fontSize: '0.8125rem', color: 'var(--primary)', marginTop: '4px' }}>Threshold: 1 action / 10s</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '6px' }}>Response: Revert Admin Perms + Quarantine</div>
          </div>
        </div>
      </div>

      {/* Module 2: Sentinel Attribution */}
      <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Radio size={20} color="var(--primary)" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#ffffff' }}>
            Audit Log Correlation & Jitter Compensation
          </h2>
        </div>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          Discord's internal audit log pipeline can suffer from ingestion delays of up to 1.5 seconds. Standard moderation bots often miss the perpetrator due to race conditions. SPOOFY Sentinel uses exponential retry algorithms with randomized jitter to match every deletion or permission change with the authentic executor.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
          <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
            <h4 style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Exponential Backoff Retry</h4>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
              Retries up to 4 times across a 2000ms window with jitter to overcome Discord API synchronization latency.
            </p>
          </div>

          <div style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-subtle)', borderRadius: '6px', padding: '16px' }}>
            <h4 style={{ fontSize: '0.875rem', fontWeight: 600, color: '#ffffff' }}>Tiered Severity Dispatch</h4>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
              Routes CRITICAL alerts immediately to staff channels while logging minor informational warnings without alert fatigue.
            </p>
          </div>
        </div>
      </div>

      {/* Module 3: Disaster Recovery & Rollback */}
      <div className="card" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Database size={20} color="var(--primary)" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#ffffff' }}>
            Disaster Recovery & Permission Sanitization
          </h2>
        </div>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          SPOOFY Recovery captures structured snapshots of categories, text and voice channels, topics, and permission overwrites. If a server is attacked, the restoration engine reconstructs missing channels in their original order while sanitizing compromised Administrator permissions.
        </p>

        <div style={{ display: 'flex', gap: '12px', marginTop: '4px' }}>
          <Link to="/docs" className="btn btn-secondary btn-sm">
            Read Recovery Documentation
          </Link>
          <a href={discordInviteUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm">
            Add SPOOFY Shield <ExternalLink size={13} />
          </a>
        </div>
      </div>
    </div>
  );
}
