import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Server, ShieldCheck, ArrowRight, ExternalLink } from 'lucide-react';
import { fetchGuilds } from '../../api';

export default function ServerSelectorPage({ auth }) {
  const [guilds, setGuilds] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  useEffect(() => {
    fetchGuilds()
      .then(setGuilds)
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div className="container" style={{ padding: '48px 24px 80px', display: 'flex', flexDirection: 'column', gap: '32px', maxWidth: '1000px' }}>
      <div>
        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          VELORA Platform • SPOOFY Console
        </div>
        <h1 style={{ fontSize: '2.25rem', fontWeight: 700, color: '#ffffff', marginTop: '6px', letterSpacing: '-0.02em' }}>
          Select Server to Manage
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: '4px' }}>
          Displaying Discord communities where your account holds management permissions. Protected by VELORA infrastructure and SPOOFY Shield.
        </p>
      </div>

      {isLoading ? (
        <div style={{ padding: '60px', textAlign: 'center', color: 'var(--text-secondary)' }}>
          Revalidating server memberships and permissions...
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
          {guilds.map((g) => (
            <div 
              key={g.id}
              className="card"
              style={{
                padding: '24px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                gap: '20px'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                <div style={{
                  width: '44px',
                  height: '44px',
                  borderRadius: '8px',
                  backgroundColor: 'var(--bg-subtle)',
                  border: '1px solid var(--border-default)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 700,
                  fontSize: '1rem',
                  color: '#ffffff',
                  flexShrink: 0
                }}>
                  {g.icon ? (
                    <img src={g.icon} alt={g.name} style={{ width: '100%', height: '100%', borderRadius: '8px', objectFit: 'cover' }} />
                  ) : (
                    g.name ? g.name.substring(0, 2).toUpperCase() : 'GS'
                  )}
                </div>

                <div style={{ overflow: 'hidden' }}>
                  <div style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#ffffff', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                    {g.name}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>
                    {g.memberCount ? `${g.memberCount.toLocaleString()} members` : 'Connected Server'}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--border-subtle)', paddingTop: '16px' }}>
                <span className="badge badge-success" style={{ fontSize: '0.7rem' }}>
                  <ShieldCheck size={12} /> Installed
                </span>

                <button
                  onClick={() => navigate(`/dashboard/${g.id}`)}
                  className="btn btn-primary btn-sm"
                >
                  Manage Server <ArrowRight size={13} />
                </button>
              </div>
            </div>
          ))}

          {/* Add Bot to Another Server Card */}
          <div
            className="card"
            style={{
              padding: '24px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '20px',
              borderStyle: 'dashed'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div style={{
                width: '44px',
                height: '44px',
                borderRadius: '8px',
                border: '1px dashed var(--border-default)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--text-tertiary)',
                flexShrink: 0
              }}>
                <Server size={20} />
              </div>
              <div>
                <div style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#ffffff' }}>Add to Another Server</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>Invite SPOOFY to a new guild</div>
              </div>
            </div>

            <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '16px' }}>
              <a
                href={discordInviteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-secondary btn-sm"
                style={{ width: '100%', justifyContent: 'center' }}
              >
                Invite SPOOFY <ExternalLink size={13} />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
