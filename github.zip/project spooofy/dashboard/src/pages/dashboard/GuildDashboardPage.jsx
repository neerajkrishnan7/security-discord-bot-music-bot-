import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../../components/Header';
import Sidebar from '../../components/Sidebar';
import OverviewTab from '../../components/OverviewTab';
import SecurityTab from '../../components/SecurityTab';
import AntiNukeTab from '../../components/AntiNukeTab';
import AutoModTab from '../../components/AutoModTab';
import ModerationTab from '../../components/ModerationTab';
import SentinelTab from '../../components/SentinelTab';
import RecoveryTab from '../../components/RecoveryTab';
import TicketsTab from '../../components/TicketsTab';
import MusicTab from '../../components/MusicTab';
import SettingsTab from '../../components/SettingsTab';

import {
  fetchHealth,
  fetchGuilds,
  fetchConfig,
  updateConfig,
  updateThreshold,
  fetchTrusted,
  addTrusted,
  removeTrusted,
  fetchAlerts,
  updateAlertStatus,
  fetchAuditLogs,
  fetchModeration,
  issueWarning,
  fetchBackups,
  createBackup,
  restoreBackup,
  deleteBackup,
  fetchScanner,
  triggerLockdown,
  liftLockdown,
  subscribeToWebSocket
} from '../../api';

export default function GuildDashboardPage({ auth }) {
  const { guildId } = useParams();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState('overview');
  const [guilds, setGuilds] = useState([]);
  const [currentGuild, setCurrentGuild] = useState(null);
  const [health, setHealth] = useState(null);
  const [config, setConfig] = useState(null);
  const [trusted, setTrusted] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [alertStats, setAlertStats] = useState({ total: 0, critical: 0, high: 0, active: 0 });
  const [auditLogs, setAuditLogs] = useState([]);
  const [moderationCases, setModerationCases] = useState([]);
  const [backups, setBackups] = useState([]);
  const [scannerData, setScannerData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initial load
  useEffect(() => {
    async function init() {
      try {
        const [h, gList] = await Promise.all([
          fetchHealth().catch(() => null),
          fetchGuilds().catch(() => [])
        ]);

        setHealth(h);
        setGuilds(gList);

        const target = gList.find(g => g.id === guildId) || gList[0] || { id: guildId, name: 'Server Management' };
        setCurrentGuild(target);
      } finally {
        setIsLoading(false);
      }
    }
    init();
  }, [guildId]);

  // Load guild data
  useEffect(() => {
    if (!guildId) return;

    async function loadData() {
      const [
        cfg,
        trustList,
        alertData,
        auditList,
        modCases,
        backupList,
        scan
      ] = await Promise.all([
        fetchConfig(guildId).catch(() => null),
        fetchTrusted(guildId).catch(() => []),
        fetchAlerts(guildId).catch(() => ({ alerts: [], stats: { total: 0, critical: 0, high: 0, active: 0 } })),
        fetchAuditLogs(guildId).catch(() => []),
        fetchModeration(guildId).catch(() => []),
        fetchBackups(guildId).catch(() => []),
        fetchScanner(guildId).catch(() => null)
      ]);

      setConfig(cfg);
      setTrusted(trustList);
      setAlerts(alertData.alerts || []);
      setAlertStats(alertData.stats || { total: 0, critical: 0, high: 0, active: 0 });
      setAuditLogs(auditList);
      setModerationCases(modCases);
      setBackups(backupList);
      setScannerData(scan);
    }

    loadData();
  }, [guildId]);

  // WebSocket Live Updates
  useEffect(() => {
    const unsub = subscribeToWebSocket((msg) => {
      if (msg.type === 'security_alert' && msg.payload.guild_id === guildId) {
        const a = msg.payload;
        setAlerts(prev => [a, ...prev]);
        setAlertStats(prev => ({
          ...prev,
          total: prev.total + 1,
          active: prev.active + 1,
          critical: a.severity === 'CRITICAL' ? prev.critical + 1 : prev.critical,
          high: a.severity === 'HIGH' ? prev.high + 1 : prev.high
        }));
      }
    });
    return unsub;
  }, [guildId]);

  const handleToggleShield = async () => {
    const newStatus = config?.shield_enabled ? 0 : 1;
    const updated = await updateConfig(guildId, { shield_enabled: newStatus });
    setConfig(updated);
  };

  const handleToggleLockdown = async () => {
    if (config?.lockdown_active) {
      await liftLockdown(guildId, 'Lifted from SPOOFY Dashboard');
      setConfig(prev => ({ ...prev, lockdown_active: 0 }));
    } else {
      await triggerLockdown(guildId, 15, 'Emergency lockdown from SPOOFY Dashboard');
      setConfig(prev => ({ ...prev, lockdown_active: 1 }));
    }
  };

  const handleUpdateConfig = async (updates) => {
    const updated = await updateConfig(guildId, updates);
    setConfig(updated);
    return updated;
  };

  const handleUpdateThreshold = async (actionType, payload) => {
    await updateThreshold(guildId, actionType, payload);
    const updated = await fetchConfig(guildId);
    setConfig(updated);
  };

  const handleAddTrusted = async (payload) => {
    await addTrusted(guildId, payload);
    const list = await fetchTrusted(guildId);
    setTrusted(list);
  };

  const handleRemoveTrusted = async (targetId) => {
    await removeTrusted(guildId, targetId);
    setTrusted(prev => prev.filter(t => t.target_id !== targetId));
  };

  const handleUpdateAlertStatus = async (alertId, status) => {
    await updateAlertStatus(guildId, alertId, status);
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, status } : a));
    const alertData = await fetchAlerts(guildId);
    setAlertStats(alertData.stats);
  };

  const handleCreateBackup = async (name) => {
    await createBackup(guildId, name);
    const list = await fetchBackups(guildId);
    setBackups(list);
  };

  const handleRestoreBackup = async (backupId, options) => {
    return await restoreBackup(guildId, backupId, options);
  };

  const handleDeleteBackup = async (backupId) => {
    await deleteBackup(guildId, backupId);
    setBackups(prev => prev.filter(b => b.id !== backupId));
  };

  const handleRunScan = async () => {
    const scan = await fetchScanner(guildId);
    setScannerData(scan);
  };

  const handleIssueWarning = async (payload) => {
    await issueWarning(guildId, payload);
    const cases = await fetchModeration(guildId);
    setModerationCases(cases);
  };

  if (isLoading) {
    return (
      <div style={{
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--bg-base)',
        color: 'var(--text-secondary)',
        fontSize: '0.875rem'
      }}>
        Synchronizing server perimeter state...
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: 'var(--bg-base)' }}>
      {/* 1. Compact Top Bar */}
      <Header
        health={health}
        currentGuild={currentGuild}
        activeTab={activeTab}
        alertStats={alertStats}
        config={config}
        onToggleLockdown={handleToggleLockdown}
        auth={auth}
      />

      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        {/* 2. Professional Left Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          currentGuild={currentGuild}
          guilds={guilds}
          onSelectGuild={(g) => navigate(`/dashboard/${g.id}`)}
          auth={auth}
          alertStats={alertStats}
        />

        {/* 3. Main Workspace Area */}
        <main style={{
          flex: 1,
          padding: '24px 32px 48px',
          maxWidth: '1400px',
          margin: '0 auto',
          width: '100%',
          overflowY: 'auto'
        }}>
          {activeTab === 'overview' && (
            <OverviewTab
              config={config}
              health={health}
              alerts={alerts}
              alertStats={alertStats}
              backups={backups}
              trusted={trusted}
              moderationCases={moderationCases}
              auditLogs={auditLogs}
              onToggleShield={handleToggleShield}
              onToggleLockdown={handleToggleLockdown}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'security' && (
            <SecurityTab
              config={config}
              onUpdateConfig={handleUpdateConfig}
              scannerData={scannerData}
              onRunScan={handleRunScan}
            />
          )}

          {activeTab === 'antinuke' && (
            <AntiNukeTab
              config={config}
              onUpdateConfig={handleUpdateConfig}
              onUpdateThreshold={handleUpdateThreshold}
              trusted={trusted}
              onAddTrusted={handleAddTrusted}
              onRemoveTrusted={handleRemoveTrusted}
            />
          )}

          {activeTab === 'automod' && (
            <AutoModTab
              config={config}
              onUpdateConfig={handleUpdateConfig}
            />
          )}

          {activeTab === 'members' && (
            <ModerationTab
              moderationCases={moderationCases}
              onIssueWarning={handleIssueWarning}
            />
          )}

          {activeTab === 'audit' && (
            <SentinelTab
              alerts={alerts}
              alertStats={alertStats}
              auditLogs={auditLogs}
              onUpdateAlertStatus={handleUpdateAlertStatus}
            />
          )}

          {activeTab === 'backups' && (
            <RecoveryTab
              backups={backups}
              onCreateBackup={handleCreateBackup}
              onRestoreBackup={handleRestoreBackup}
              onDeleteBackup={handleDeleteBackup}
            />
          )}

          {activeTab === 'tickets' && (
            <TicketsTab guildId={guildId} />
          )}

          {activeTab === 'music' && (
            <MusicTab guildId={guildId} />
          )}

          {activeTab === 'settings' && (
            <SettingsTab
              guildId={guildId}
              config={config}
              onUpdateConfig={handleUpdateConfig}
            />
          )}
        </main>
      </div>
    </div>
  );
}
