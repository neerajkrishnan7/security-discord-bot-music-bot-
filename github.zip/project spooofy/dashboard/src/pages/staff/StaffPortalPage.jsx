import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  UserCheck, 
  Ticket, 
  AlertTriangle, 
  Bell, 
  Users, 
  CheckCircle2, 
  Lock, 
  Plus, 
  FileText,
  Shield,
  MessageSquare,
  Search,
  ChevronRight
} from 'lucide-react';
import { 
  fetchStaffOverview, 
  fetchStaffTickets, 
  updateStaffTicket, 
  fetchStaffIncidents, 
  fetchStaffAnnouncements, 
  createStaffAnnouncement, 
  fetchStaffMembers, 
  addStaffMemberApi, 
  updateStaffMemberRoleApi, 
  updateStaffMemberStatusApi 
} from '../../api';

export default function StaffPortalPage({ auth }) {
  const [activeTab, setActiveTab] = useState('tickets');
  const [overview, setOverview] = useState(null);
  const [tickets, setTickets] = useState([]);
  const [ticketStatusFilter, setTicketStatusFilter] = useState('OPEN');
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [ticketNotes, setTicketNotes] = useState('');
  const [announcements, setAnnouncements] = useState([]);
  const [members, setMembers] = useState([]);
  const [feedback, setFeedback] = useState(null);

  useEffect(() => {
    loadOverview();
  }, []);

  const loadOverview = async () => {
    try {
      const data = await fetchStaffOverview();
      setOverview(data);
    } catch (e) {}
  };

  const loadTickets = async () => {
    try {
      const list = await fetchStaffTickets(ticketStatusFilter);
      setTickets(list);
    } catch (e) {}
  };

  const loadAnnouncements = async () => {
    try {
      const list = await fetchStaffAnnouncements();
      setAnnouncements(list);
    } catch (e) {}
  };

  const loadMembers = async () => {
    try {
      const list = await fetchStaffMembers();
      setMembers(list);
    } catch (e) {}
  };

  useEffect(() => {
    if (activeTab === 'tickets') loadTickets();
    if (activeTab === 'announcements') loadAnnouncements();
    if (activeTab === 'management') loadMembers();
  }, [activeTab, ticketStatusFilter]);

  const handleClaimTicket = async (ticket) => {
    await updateStaffTicket(ticket.id, {
      assigned_staff_id: auth?.user?.discord_id || 'staff_agent',
      status: 'PENDING'
    });
    await loadTickets();
    setFeedback(`Ticket #${ticket.id} assigned to you.`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleUpdateTicketStatus = async (ticketId, status) => {
    await updateStaffTicket(ticketId, { status });
    await loadTickets();
    setFeedback(`Ticket #${ticketId} status updated to ${status}.`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleSaveInternalNotes = async (ticketId) => {
    await updateStaffTicket(ticketId, { internal_notes: ticketNotes });
    await loadTickets();
    setFeedback(`Internal notes updated for ticket #${ticketId}.`);
    setTimeout(() => setFeedback(null), 3000);
  };

  if (!auth?.isStaff) {
    return (
      <div style={{ maxWidth: '480px', margin: '80px auto', padding: '32px', textAlign: 'center', backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '6px' }}>
        <Shield size={40} color="var(--primary)" style={{ margin: '0 auto 12px' }} />
        <h2 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--text-primary)' }}>Staff Authorization Required</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
          The SPOOFY Staff Operations Portal is reserved for verified support and security personnel.
        </p>
        <Link to="/dashboard" className="btn btn-secondary btn-sm" style={{ marginTop: '16px' }}>
          Back to Guild Dashboard
        </Link>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1360px', margin: '0 auto', padding: '24px 24px 64px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <UserCheck size={18} color="var(--primary)" />
            <h1 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              SPOOFY Staff Operations Portal
            </h1>
            <span className="badge badge-primary" style={{ fontSize: '0.625rem' }}>SUPPORT QUEUE</span>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Assigned ticket triage, incident escalations, internal team notes, and support dispatch.
          </p>
        </div>

        {/* Tab Controls */}
        <div style={{ display: 'flex', gap: '6px' }}>
          {[
            { id: 'tickets', label: 'Ticket Queue' },
            { id: 'announcements', label: 'Briefings' },
            { id: 'management', label: 'Staff Roster' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="btn btn-secondary btn-sm"
              style={{
                backgroundColor: activeTab === tab.id ? 'var(--bg-base)' : undefined,
                borderColor: activeTab === tab.id ? 'var(--primary)' : undefined,
                color: activeTab === tab.id ? 'var(--text-primary)' : undefined
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {feedback && (
        <div style={{
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          border: '1px solid rgba(16, 185, 129, 0.3)',
          borderRadius: '4px',
          padding: '10px 16px',
          fontSize: '0.8125rem',
          color: '#10b981',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <CheckCircle2 size={15} />
          <span>{feedback}</span>
        </div>
      )}

      {/* Tab: Tickets Queue */}
      {activeTab === 'tickets' && (
        <div style={{ display: 'grid', gridTemplateColumns: selectedTicket ? '1.2fr 0.8fr' : '1fr', gap: '16px' }}>
          {/* Table */}
          <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', overflow: 'hidden' }}>
            <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--border-neutral)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: 700 }}>
                Tickets in Queue ({tickets.length})
              </span>
              <div style={{ display: 'flex', gap: '6px' }}>
                {['OPEN', 'PENDING', 'CLOSED', 'ALL'].map(st => (
                  <button
                    key={st}
                    onClick={() => setTicketStatusFilter(st)}
                    className="btn btn-secondary btn-sm"
                    style={{
                      fontSize: '0.6875rem',
                      padding: '2px 8px',
                      backgroundColor: ticketStatusFilter === st ? 'var(--bg-base)' : undefined,
                      borderColor: ticketStatusFilter === st ? 'var(--primary)' : undefined
                    }}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {tickets.length === 0 ? (
              <div style={{ padding: '36px 18px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
                No support tickets currently in this filter.
              </div>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th style={{ width: '80px' }}>Status</th>
                    <th>Ticket Subject</th>
                    <th>Requester</th>
                    <th>Guild</th>
                    <th style={{ textAlign: 'right' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {tickets.map(t => (
                    <tr 
                      key={t.id}
                      onClick={() => {
                        setSelectedTicket(t);
                        setTicketNotes(t.internal_notes || '');
                      }}
                      style={{ cursor: 'pointer', backgroundColor: selectedTicket?.id === t.id ? 'rgba(99, 102, 241, 0.08)' : undefined }}
                    >
                      <td>
                        <span className={`badge ${t.status === 'OPEN' ? 'badge-critical' : t.status === 'PENDING' ? 'badge-warning' : 'badge-low'}`} style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                          {t.status}
                        </span>
                      </td>
                      <td>
                        <div style={{ fontWeight: 600, fontSize: '0.8125rem' }}>{t.subject || t.category || `Ticket #${t.id}`}</div>
                        <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>ID: {t.id}</div>
                      </td>
                      <td style={{ fontSize: '0.8125rem' }}>{t.creator_tag || t.creator_id}</td>
                      <td style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{t.guild_name || t.guild_id}</td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleClaimTicket(t);
                          }}
                          className="btn btn-secondary btn-sm"
                          style={{ fontSize: '0.75rem', padding: '2px 8px' }}
                        >
                          Claim
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Ticket Inspector Side Panel */}
          {selectedTicket && (
            <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '18px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '0.875rem', fontWeight: 700 }}>
                  Ticket Details: #{selectedTicket.id}
                </span>
                <span className={`badge ${selectedTicket.status === 'OPEN' ? 'badge-critical' : 'badge-low'}`}>
                  {selectedTicket.status}
                </span>
              </div>

              <div style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                <strong>Requester:</strong> {selectedTicket.creator_tag || selectedTicket.creator_id}
              </div>

              <div style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                <strong>Category:</strong> {selectedTicket.category || 'General'}
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                  Internal Staff Notes & Escalation Log
                </label>
                <textarea
                  rows={4}
                  value={ticketNotes}
                  onChange={(e) => setTicketNotes(e.target.value)}
                  placeholder="Record observations, server context, or steps taken..."
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px' }}>
                <button
                  onClick={() => handleSaveInternalNotes(selectedTicket.id)}
                  className="btn btn-primary btn-sm"
                >
                  Save Internal Notes
                </button>

                <div style={{ display: 'flex', gap: '6px' }}>
                  {selectedTicket.status !== 'CLOSED' && (
                    <button
                      onClick={() => handleUpdateTicketStatus(selectedTicket.id, 'CLOSED')}
                      className="btn btn-secondary btn-sm"
                      style={{ color: '#f87171' }}
                    >
                      Close Ticket
                    </button>
                  )}
                  {selectedTicket.status === 'CLOSED' && (
                    <button
                      onClick={() => handleUpdateTicketStatus(selectedTicket.id, 'OPEN')}
                      className="btn btn-secondary btn-sm"
                    >
                      Re-open
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab: Staff Roster */}
      {activeTab === 'management' && (
        <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', overflow: 'hidden' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--border-neutral)', fontWeight: 700, fontSize: '0.8125rem' }}>
            Active Support Agents & Staff ({members.length})
          </div>

          <table>
            <thead>
              <tr>
                <th>Agent Identity</th>
                <th>Role</th>
                <th>Discord ID</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {members.map(m => (
                <tr key={m.id}>
                  <td style={{ fontWeight: 600 }}>{m.username}</td>
                  <td><span className="badge badge-primary">{m.role}</span></td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{m.discord_id}</td>
                  <td><span className="badge badge-success">{m.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab: Briefings */}
      {activeTab === 'announcements' && (
        <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '18px' }}>
          <div style={{ fontSize: '0.875rem', fontWeight: 700, marginBottom: '12px' }}>
            Internal Team Operational Briefings
          </div>
          {announcements.length === 0 ? (
            <div style={{ color: 'var(--text-tertiary)', fontSize: '0.8125rem', padding: '16px 0' }}>
              No active operational notices published.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {announcements.map(a => (
                <div key={a.id} style={{ padding: '12px 14px', backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-neutral)', borderRadius: '4px' }}>
                  <div style={{ fontWeight: 600, fontSize: '0.8125rem' }}>{a.title}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>{a.content}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
