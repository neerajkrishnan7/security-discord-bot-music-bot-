import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldAlert, 
  Server, 
  Sliders, 
  Activity, 
  Cpu, 
  AlertTriangle, 
  Search, 
  CheckCircle2, 
  RefreshCw, 
  Lock, 
  Radio, 
  FileText,
  UserCheck,
  Terminal,
  Database,
  ArrowLeft
} from 'lucide-react';
import { 
  fetchAdminOverview, 
  fetchAdminGuilds, 
  overrideAdminGuild, 
  fetchAdminConfigs, 
  updateAdminConfigs, 
  fetchAdminIncidents, 
  createAdminIncident, 
  updateAdminIncident, 
  clearAdminCache,
  fetchAdminStaffLogs 
} from '../../api';

export default function AdminPanelPage({ auth }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [overview, setOverview] = useState(null);
  const [guilds, setGuilds] = useState([]);
  const [guildSearch, setGuildSearch] = useState('');
  const [configs, setConfigs] = useState({});
  const [incidents, setIncidents] = useState([]);
  const [staffLogs, setStaffLogs] = useState([]);
  const [newIncidentTitle, setNewIncidentTitle] = useState('');
  const [newIncidentDesc, setNewIncidentDesc] = useState('');
  const [newIncidentSev, setNewIncidentSev] = useState('MEDIUM');
  const [showCreateIncident, setShowCreateIncident] = useState(false);
  const [actionFeedback, setActionFeedback] = useState(null);

  useEffect(() => {
    loadOverview();
  }, []);

  const loadOverview = async () => {
    try {
      const data = await fetchAdminOverview();
      setOverview(data);
    } catch (e) {}
  };

  const loadGuilds = async () => {
    try {
      const list = await fetchAdminGuilds(guildSearch);
      setGuilds(list);
    } catch (e) {}
  };

  const loadConfigs = async () => {
    try {
      const cfg = await fetchAdminConfigs();
      setConfigs(cfg);
    } catch (e) {}
  };

  const loadIncidents = async () => {
    try {
      const inc = await fetchAdminIncidents();
      setIncidents(inc);
    } catch (e) {}
  };

  const loadStaffLogs = async () => {
    try {
      const logs = await fetchAdminStaffLogs();
      setStaffLogs(logs);
    } catch (e) {}
  };

  useEffect(() => {
    if (activeTab === 'guilds') loadGuilds();
    if (activeTab === 'configs') loadConfigs();
    if (activeTab === 'incidents') loadIncidents();
    if (activeTab === 'operations') loadStaffLogs();
  }, [activeTab]);

  const handleGuildOverride = async (guildId, action, value) => {
    await overrideAdminGuild(guildId, action, value);
    await loadGuilds();
    setActionFeedback(`Operational override applied to guild ${guildId}`);
    setTimeout(() => setActionFeedback(null), 3000);
  };

  const handleSaveConfigs = async () => {
    await updateAdminConfigs(configs);
    setActionFeedback('Global configurations and feature flags updated.');
    setTimeout(() => setActionFeedback(null), 3000);
  };

  const handleCreateIncident = async (e) => {
    e.preventDefault();
    if (!newIncidentTitle.trim()) return;
    await createAdminIncident({
      title: newIncidentTitle.trim(),
      description: newIncidentDesc.trim(),
      severity: newIncidentSev,
      affected_services: 'Discord Gateway, Shield Engines'
    });
    setNewIncidentTitle('');
    setNewIncidentDesc('');
    setShowCreateIncident(false);
    await loadIncidents();
  };

  const handleClearCache = async () => {
    const res = await clearAdminCache();
    setActionFeedback(res.message);
    setTimeout(() => setActionFeedback(null), 3000);
  };

  if (!auth?.isSystemAdmin) {
    return (
      <div style={{ maxWidth: '480px', margin: '80px auto', padding: '32px', textAlign: 'center', backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '6px' }}>
        <ShieldAlert size={40} color="#ef4444" style={{ margin: '0 auto 12px' }} />
        <h2 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--text-primary)' }}>Access Restricted</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5 }}>
          The SPOOFY Operations Console is restricted to authenticated system administrators.
        </p>
        <Link to="/dashboard" className="btn btn-secondary btn-sm" style={{ marginTop: '16px' }}>
          Back to Guild Dashboard
        </Link>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1360px', margin: '0 auto', padding: '24px 24px 64px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Operations Header */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Terminal size={18} color="var(--primary)" />
            <h1 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              SPOOFY Operations Console
            </h1>
            <span className="badge badge-critical" style={{ fontSize: '0.625rem' }}>INTERNAL OPS</span>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Multi-tenant cluster telemetry, cross-guild emergency controls, service health, and incident tracking.
          </p>
        </div>

        {/* Tab Navigation */}
        <div style={{ display: 'flex', gap: '6px' }}>
          {[
            { id: 'overview', label: 'Cluster Overview' },
            { id: 'guilds', label: 'Guilds Directory' },
            { id: 'configs', label: 'Feature Flags' },
            { id: 'incidents', label: 'Incidents' },
            { id: 'operations', label: 'Staff Audit Logs' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="btn btn-secondary btn-sm"
              style={{
                backgroundColor: activeTab === tab.id ? 'var(--bg-base)' : undefined,
                borderColor: activeTab === tab.id ? 'var(--primary)' : undefined,
                color: activeTab === tab.id ? 'var(--text-primary)' : undefined
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {actionFeedback && (
        <div style={{
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          border: '1px solid rgba(16, 185, 129, 0.3)',
          borderRadius: '4px',
          padding: '10px 16px',
          fontSize: '0.8125rem',
          color: '#10b981',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <CheckCircle2 size={15} />
          <span>{actionFeedback}</span>
        </div>
      )}

      {/* Tab: Overview */}
      {activeTab === 'overview' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Key Cluster Metrics */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '12px' }}>
            <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '14px 16px' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 500 }}>Total Guilds</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '4px', fontFamily: 'var(--font-mono)' }}>
                {overview?.metrics?.totalRegisteredGuilds ?? 1}
              </div>
              <div style={{ fontSize: '0.6875rem', color: '#10b981', marginTop: '2px' }}>All SQLite schemas active</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '14px 16px' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 500 }}>Active Gateways</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '4px', fontFamily: 'var(--font-mono)' }}>
                {overview?.metrics?.activeGatewayGuilds ?? 1}
              </div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>Real-time event loop connected</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '14px 16px' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 500 }}>Platform Alerts</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '4px', fontFamily: 'var(--font-mono)' }}>
                {overview?.metrics?.unresolvedAlerts ?? 0}
              </div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>Security events pending triage</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '14px 16px' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 500 }}>System Uptime</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '4px', fontFamily: 'var(--font-mono)' }}>
                {Math.floor((overview?.system?.uptimeSeconds ?? 180) / 60)}m
              </div>
              <div style={{ fontSize: '0.6875rem', color: '#10b981', marginTop: '2px' }}>Zero crash restarts</div>
            </div>
          </div>

          {/* Service Health & Operational Controls */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 0.7fr', gap: '16px' }}>
            <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', overflow: 'hidden' }}>
              <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-neutral)', fontWeight: 700, fontSize: '0.8125rem' }}>
                Core Microservice Health Status
              </div>
              <table>
                <thead>
                  <tr>
                    <th>Subsystem Service</th>
                    <th>Status</th>
                    <th>Latency / Metric</th>
                    <th style={{ textAlign: 'right' }}>Health Check</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ fontWeight: 600 }}>Discord WebSocket Gateway</td>
                    <td><span className="badge badge-success">READY</span></td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>{overview?.gateway?.pingMs ?? 15} ms</td>
                    <td style={{ textAlign: 'right', color: '#10b981', fontSize: '0.75rem' }}>Nominal</td>
                  </tr>
                  <tr>
                    <td style={{ fontWeight: 600 }}>SQLite Storage Engine (WAL)</td>
                    <td><span className="badge badge-success">SYNCED</span></td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>{overview?.database?.latencyMs ?? 0.2} ms</td>
                    <td style={{ textAlign: 'right', color: '#10b981', fontSize: '0.75rem' }}>Read/Write Active</td>
                  </tr>
                  <tr>
                    <td style={{ fontWeight: 600 }}>Sliding Window In-Memory Store</td>
                    <td><span className="badge badge-success">HEALTHY</span></td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>0.04 ms TTL</td>
                    <td style={{ textAlign: 'right', color: '#10b981', fontSize: '0.75rem' }}>0 Evictions</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Quick Administrative Operations */}
            <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ fontWeight: 700, fontSize: '0.8125rem' }}>
                Administrative Maintenance
              </div>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                Perform runtime cache purges and schema sync across all nodes.
              </p>
              <button
                onClick={handleClearCache}
                className="btn btn-secondary btn-sm"
                style={{ width: '100%', justifyContent: 'flex-start' }}
              >
                <RefreshCw size={13} /> Purge Shared Memory Cache
              </button>
              <button
                onClick={loadOverview}
                className="btn btn-secondary btn-sm"
                style={{ width: '100%', justifyContent: 'flex-start' }}
              >
                <Activity size={13} /> Re-probe Gateway Ping
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Guilds Directory */}
      {activeTab === 'guilds' && (
        <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', overflow: 'hidden' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--border-neutral)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: 700 }}>Registered Guilds ({guilds.length})</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-neutral)', borderRadius: '4px', padding: '4px 8px', width: '220px' }}>
              <Search size={13} color="var(--text-tertiary)" />
              <input
                type="text"
                placeholder="Search guild name or ID..."
                value={guildSearch}
                onChange={(e) => setGuildSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadGuilds()}
                style={{ background: 'transparent', border: 'none', padding: 0, fontSize: '0.75rem', outline: 'none', width: '100%' }}
              />
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Guild Name</th>
                <th>Snowflake ID</th>
                <th>Shield Status</th>
                <th>Lockdown</th>
                <th style={{ textAlign: 'right' }}>Admin Overrides</th>
              </tr>
            </thead>
            <tbody>
              {guilds.map(g => (
                <tr key={g.id}>
                  <td>
                    <div style={{ fontWeight: 600, fontSize: '0.8125rem' }}>{g.name}</div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>{g.memberCount ? `${g.memberCount.toLocaleString()} members` : 'Connected'}</div>
                  </td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{g.id}</td>
                  <td>
                    <span className={`badge ${g.shield_enabled ? 'badge-success' : 'badge-low'}`}>
                      {g.shield_enabled ? 'ARMED' : 'STANDBY'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${g.lockdown_active ? 'badge-critical' : 'badge-low'}`}>
                      {g.lockdown_active ? 'LOCKDOWN' : 'NORMAL'}
                    </span>
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '6px' }}>
                      <button
                        onClick={() => handleGuildOverride(g.id, 'toggle_shield', !g.shield_enabled)}
                        className="btn btn-secondary btn-sm"
                        style={{ fontSize: '0.75rem', padding: '3px 8px' }}
                      >
                        {g.shield_enabled ? 'Disarm' : 'Arm'}
                      </button>
                      <button
                        onClick={() => handleGuildOverride(g.id, 'toggle_lockdown', !g.lockdown_active)}
                        className="btn btn-secondary btn-sm"
                        style={{ fontSize: '0.75rem', padding: '3px 8px', color: g.lockdown_active ? '#10b981' : '#f87171' }}
                      >
                        {g.lockdown_active ? 'Lift' : 'Lock'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab: Configs */}
      {activeTab === 'configs' && (
        <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: '0.875rem', fontWeight: 700 }}>Global Platform Feature Flags</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Dynamically toggle platform-wide subsystems</div>
            </div>
            <button onClick={handleSaveConfigs} className="btn btn-primary btn-sm">
              Save Global Configuration
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {Object.keys(configs).map(k => (
              <div key={k} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', backgroundColor: 'var(--bg-base)', border: '1px solid var(--border-neutral)', borderRadius: '4px' }}>
                <span style={{ fontSize: '0.8125rem', fontFamily: 'var(--font-mono)' }}>{k}</span>
                <input
                  type="text"
                  value={configs[k]}
                  onChange={(e) => setConfigs({ ...configs, [k]: e.target.value })}
                  style={{ width: '240px', padding: '5px 8px', fontSize: '0.8125rem' }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Incidents */}
      {activeTab === 'incidents' && (
        <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', overflow: 'hidden' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--border-neutral)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: 700 }}>Platform Incident Log ({incidents.length})</span>
            <button onClick={() => setShowCreateIncident(true)} className="btn btn-primary btn-sm">
              Publish Incident
            </button>
          </div>

          {incidents.length === 0 ? (
            <div style={{ padding: '32px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
              All nodes and gateway instances operational. No open incidents.
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th style={{ width: '90px' }}>Severity</th>
                  <th>Incident Title</th>
                  <th>Services Affected</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {incidents.map(inc => (
                  <tr key={inc.id}>
                    <td>
                      <span className={`badge ${inc.severity === 'CRITICAL' ? 'badge-critical' : 'badge-warning'}`}>
                        {inc.severity}
                      </span>
                    </td>
                    <td style={{ fontWeight: 600 }}>{inc.title}</td>
                    <td style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{inc.affected_services}</td>
                    <td><span className="badge badge-success">{inc.status}</span></td>
                    <td style={{ textAlign: 'right', fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                      {new Date(inc.created_at * 1000).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* Tab: Operations / Staff Audit Logs */}
      {activeTab === 'operations' && (
        <div style={{ backgroundColor: 'var(--bg-panel)', border: '1px solid var(--border-neutral)', borderRadius: '5px', overflow: 'hidden' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--border-neutral)', fontWeight: 700, fontSize: '0.8125rem' }}>
            Internal Staff Operations Audit Stream ({staffLogs.length})
          </div>

          {staffLogs.length === 0 ? (
            <div style={{ padding: '32px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
              No administrative override operations logged in this session.
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Staff Member</th>
                  <th>Action</th>
                  <th>Target Entity</th>
                  <th>Details</th>
                  <th style={{ textAlign: 'right' }}>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {staffLogs.map(l => (
                  <tr key={l.id}>
                    <td style={{ fontWeight: 600 }}>{l.staff_username || l.staff_id}</td>
                    <td><span className="badge">{l.action_type}</span></td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>{l.target_id || 'System'}</td>
                    <td style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>{l.details}</td>
                    <td style={{ textAlign: 'right', fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                      {new Date(l.created_at * 1000).toLocaleTimeString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}
