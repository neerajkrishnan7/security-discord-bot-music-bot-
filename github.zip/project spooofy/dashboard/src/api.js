const API_BASE = '/api';

// Authentication & Profile
export async function fetchAuthMe() {
  const res = await fetch(`${API_BASE}/auth/me`);
  return res.json();
}

export async function loginDevPersona(persona) {
  const res = await fetch(`${API_BASE}/auth/dev-login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ persona })
  });
  return res.json();
}

export async function logout() {
  const res = await fetch(`${API_BASE}/auth/logout`, { method: 'POST' });
  return res.json();
}

// Public Endpoints
export async function fetchPublicStatus() {
  const res = await fetch(`${API_BASE}/public/status`);
  return res.json();
}

export async function fetchPublicCommands() {
  const res = await fetch(`${API_BASE}/public/commands`);
  return res.json();
}

export async function fetchPublicStats() {
  const res = await fetch(`${API_BASE}/public/stats`);
  return res.json();
}

// Bot & Gateway Health
export async function fetchHealth() {
  const res = await fetch(`${API_BASE}/health`);
  return res.json();
}

// Guild Management
export async function fetchGuilds() {
  const res = await fetch(`${API_BASE}/guilds`);
  return res.json();
}

export async function fetchConfig(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/config`);
  return res.json();
}

export async function updateConfig(guildId, updates) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/config`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  return res.json();
}

export async function updateThreshold(guildId, actionType, payload) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/threshold/${actionType}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchTrusted(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/trusted`);
  return res.json();
}

export async function addTrusted(guildId, payload) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/trusted`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function removeTrusted(guildId, targetId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/trusted/${targetId}`, {
    method: 'DELETE'
  });
  return res.json();
}

export async function fetchAlerts(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/alerts`);
  return res.json();
}

export async function updateAlertStatus(guildId, alertId, status) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/alerts/${alertId}/status`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status })
  });
  return res.json();
}

export async function fetchAuditLogs(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/audit`);
  return res.json();
}

export async function fetchModeration(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/moderation`);
  return res.json();
}

export async function issueWarning(guildId, payload) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/moderation/warn`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function executeModAction(guildId, payload) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/moderation/action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function unbanMember(guildId, userId, reason) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/moderation/unban`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user_id: userId, reason })
  });
  return res.json();
}

export async function fetchBackups(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/backups`);
  return res.json();
}

export async function createBackup(guildId, name) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/backups`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name })
  });
  return res.json();
}

export async function restoreBackup(guildId, backupId, options) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/backups/${backupId}/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ options })
  });
  return res.json();
}

export async function deleteBackup(guildId, backupId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/backups/${backupId}`, {
    method: 'DELETE'
  });
  return res.json();
}

export async function fetchScanner(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/scanner`);
  return res.json();
}

export async function triggerLockdown(guildId, duration, reason) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/lockdown`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ duration, reason })
  });
  return res.json();
}

export async function liftLockdown(guildId, reason) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/unlockdown`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason })
  });
  return res.json();
}

export async function runSimulation(guildId, scenario) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/simulate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scenario })
  });
  return res.json();
}

// Music
export async function fetchMusicSession(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/music`);
  return res.json();
}

export async function actionMusicSession(guildId, action, payload = null) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/music/action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, payload })
  });
  return res.json();
}

// Welcome & Logging
export async function fetchWelcomeConfig(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/welcome`);
  return res.json();
}

export async function updateWelcomeConfig(guildId, updates) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/welcome`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  return res.json();
}

export async function fetchLoggingConfig(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/logging`);
  return res.json();
}

export async function updateLoggingConfig(guildId, updates) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/logging`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  return res.json();
}

export async function fetchGuildTickets(guildId) {
  const res = await fetch(`${API_BASE}/guild/${guildId}/tickets`);
  return res.json();
}

export async function closeGuildTicket(guildId, ticketId, transcript = '') {
  const res = await fetch(`${API_BASE}/guild/${guildId}/tickets/${ticketId}/close`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ transcript })
  });
  return res.json();
}

// SPOOFY Owner Admin API
export async function fetchAdminOverview() {
  const res = await fetch(`${API_BASE}/admin/overview`);
  return res.json();
}

export async function fetchAdminGuilds(query = '') {
  const res = await fetch(`${API_BASE}/admin/guilds?q=${encodeURIComponent(query)}`);
  return res.json();
}

export async function overrideAdminGuild(guildId, action, value) {
  const res = await fetch(`${API_BASE}/admin/guilds/${guildId}/override`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, value })
  });
  return res.json();
}

export async function fetchAdminConfigs() {
  const res = await fetch(`${API_BASE}/admin/configs`);
  return res.json();
}

export async function updateAdminConfigs(updates) {
  const res = await fetch(`${API_BASE}/admin/configs`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  return res.json();
}

export async function fetchAdminIncidents(status = '') {
  const res = await fetch(`${API_BASE}/admin/incidents?status=${status}`);
  return res.json();
}

export async function createAdminIncident(payload) {
  const res = await fetch(`${API_BASE}/admin/incidents`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function updateAdminIncident(id, payload) {
  const res = await fetch(`${API_BASE}/admin/incidents/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchAdminStaffLogs() {
  const res = await fetch(`${API_BASE}/admin/staff-logs`);
  return res.json();
}

export async function clearAdminCache() {
  const res = await fetch(`${API_BASE}/admin/operations/cache-clear`, { method: 'POST' });
  return res.json();
}

// Staff Portal API
export async function fetchStaffOverview() {
  const res = await fetch(`${API_BASE}/staff/overview`);
  return res.json();
}

export async function fetchStaffTickets(status = '') {
  const res = await fetch(`${API_BASE}/staff/tickets?status=${status}`);
  return res.json();
}

export async function updateStaffTicket(id, payload) {
  const res = await fetch(`${API_BASE}/staff/tickets/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchStaffIncidents(status = '') {
  const res = await fetch(`${API_BASE}/staff/incidents?status=${status}`);
  return res.json();
}

export async function updateStaffIncidentNotes(id, investigation_notes, status = null) {
  const res = await fetch(`${API_BASE}/staff/incidents/${id}/notes`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ investigation_notes, status })
  });
  return res.json();
}

export async function fetchStaffAnnouncements() {
  const res = await fetch(`${API_BASE}/staff/announcements`);
  return res.json();
}

export async function createStaffAnnouncement(payload) {
  const res = await fetch(`${API_BASE}/staff/announcements`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchStaffMembers() {
  const res = await fetch(`${API_BASE}/staff/members`);
  return res.json();
}

export async function addStaffMemberApi(payload) {
  const res = await fetch(`${API_BASE}/staff/members`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function updateStaffMemberRoleApi(id, role) {
  const res = await fetch(`${API_BASE}/staff/members/${id}/role`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ role })
  });
  return res.json();
}

export async function updateStaffMemberStatusApi(id, status) {
  const res = await fetch(`${API_BASE}/staff/members/${id}/status`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status })
  });
  return res.json();
}

// WebSocket Live Stream
export function subscribeToWebSocket(onMessage) {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/ws`;

  let ws = null;
  let isReconnecting = false;

  function connect() {
    try {
      ws = new WebSocket(wsUrl);

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          onMessage(data);
        } catch (e) {
          // Ignore
        }
      };

      ws.onclose = () => {
        if (!isReconnecting) {
          isReconnecting = true;
          setTimeout(() => {
            isReconnecting = false;
            connect();
          }, 3000);
        }
      };
    } catch (e) {
      setTimeout(connect, 5000);
    }
  }

  connect();
  return () => {
    if (ws) ws.close();
  };
}
