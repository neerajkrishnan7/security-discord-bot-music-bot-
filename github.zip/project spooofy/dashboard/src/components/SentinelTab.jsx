import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Filter, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  ShieldCheck, 
  ShieldAlert, 
  User, 
  ExternalLink,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export default function SentinelTab({ 
  alerts = [], 
  alertStats = { total: 0, critical: 0, high: 0, active: 0 }, 
  auditLogs = [], 
  onUpdateAlertStatus 
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSeverity, setFilterSeverity] = useState('ALL');
  const [filterOutcome, setFilterOutcome] = useState('ALL');
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [page, setPage] = useState(1);
  const pageSize = 12;

  // Combine alerts and audit logs into a unified, correlated stream
  const unifiedEvents = [
    ...alerts.map(a => ({
      id: `alert-${a.id}`,
      rawId: a.id,
      isAlert: true,
      actor_tag: a.actor_tag || 'Unknown',
      actor_id: a.actor_id || '—',
      action_type: a.title || 'SECURITY_TRIGGER',
      target: a.target_id ? `ID: ${a.target_id}` : 'Server Guild',
      reason: a.description || 'Threshold rule exceeded',
      timestamp: a.created_at ? a.created_at * 1000 : Date.now(),
      outcome: a.action_taken || 'BLOCKED',
      severity: a.severity || 'HIGH',
      status: a.status || 'ACTIVE',
      metadata: a
    })),
    ...auditLogs.map(log => ({
      id: `audit-${log.id}`,
      rawId: log.id,
      isAlert: false,
      actor_tag: log.actor_tag || `User (${log.actor_id || 'System'})`,
      actor_id: log.actor_id || '—',
      action_type: log.action_type || 'GUILD_AUDIT',
      target: log.target_id ? `Target (${log.target_id})` : 'Server',
      reason: log.reason || 'Manual administrative action',
      timestamp: log.timestamp ? (typeof log.timestamp === 'number' ? (log.timestamp > 1e11 ? log.timestamp : log.timestamp * 1000) : Date.parse(log.timestamp)) : Date.now(),
      outcome: log.outcome || (log.severity === 'CRITICAL' ? 'BLOCKED' : 'ALLOWED'),
      severity: log.severity || 'INFO',
      status: 'LOGGED',
      metadata: log
    }))
  ].sort((a, b) => b.timestamp - a.timestamp);

  // Filter
  const filteredEvents = unifiedEvents.filter(ev => {
    if (filterSeverity !== 'ALL' && ev.severity !== filterSeverity) return false;
    if (filterOutcome !== 'ALL' && ev.outcome.toUpperCase() !== filterOutcome.toUpperCase()) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchActor = ev.actor_tag.toLowerCase().includes(q) || ev.actor_id.includes(q);
      const matchAction = ev.action_type.toLowerCase().includes(q);
      const matchTarget = ev.target.toLowerCase().includes(q);
      const matchReason = ev.reason.toLowerCase().includes(q);
      return matchActor || matchAction || matchTarget || matchReason;
    }
    return true;
  });

  const totalPages = Math.max(1, Math.ceil(filteredEvents.length / pageSize));
  const currentPageEvents = filteredEvents.slice((page - 1) * pageSize, page * pageSize);

  const handleResolveAlert = async (alertId) => {
    if (onUpdateAlertStatus) {
      await onUpdateAlertStatus(alertId, 'RESOLVED');
      if (selectedEvent && selectedEvent.rawId === alertId) {
        setSelectedEvent(prev => prev ? { ...prev, status: 'RESOLVED' } : null);
      }
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {/* 1. Header with Stats & Filter Bar */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <FileText size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Security Audit Logs & Correlation
            </h2>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Attributed log stream with sliding velocity evaluation and enforcement tracking.
          </p>
        </div>

        {/* Search Input & Severity Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '4px',
            padding: '5px 10px',
            width: '240px'
          }}>
            <Search size={13} color="var(--text-tertiary)" />
            <input
              type="text"
              placeholder="Search user, target, action..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setPage(1);
              }}
              style={{
                background: 'transparent',
                border: 'none',
                padding: 0,
                fontSize: '0.8125rem',
                outline: 'none',
                color: 'var(--text-primary)',
                width: '100%'
              }}
            />
          </div>

          <select
            value={filterSeverity}
            onChange={(e) => {
              setFilterSeverity(e.target.value);
              setPage(1);
            }}
            style={{ width: 'auto', padding: '5px 10px', fontSize: '0.8125rem' }}
          >
            <option value="ALL">All Severities</option>
            <option value="CRITICAL">Critical ({alertStats?.critical || 0})</option>
            <option value="HIGH">High ({alertStats?.high || 0})</option>
            <option value="MEDIUM">Medium</option>
            <option value="INFO">Informational</option>
          </select>

          <select
            value={filterOutcome}
            onChange={(e) => {
              setFilterOutcome(e.target.value);
              setPage(1);
            }}
            style={{ width: 'auto', padding: '5px 10px', fontSize: '0.8125rem' }}
          >
            <option value="ALL">All Outcomes</option>
            <option value="BLOCKED">Blocked</option>
            <option value="ALLOWED">Allowed</option>
            <option value="STRIP_ROLES">Strip Roles</option>
          </select>
        </div>
      </div>

      {/* 2. Main Audit Logs Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        {currentPageEvents.length === 0 ? (
          <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
            No audit records found matching current query and filters.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th style={{ width: '190px' }}>User / Actor</th>
                <th style={{ width: '160px' }}>Action</th>
                <th style={{ width: '160px' }}>Target</th>
                <th>Reason / Description</th>
                <th style={{ width: '120px' }}>Outcome</th>
                <th style={{ width: '140px', textAlign: 'right' }}>Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {currentPageEvents.map((ev) => {
                const isSelected = selectedEvent?.id === ev.id;
                const d = new Date(ev.timestamp);
                const timeStr = isNaN(d.getTime()) ? 'Just now' : `${d.toLocaleDateString([], { month: 'short', day: 'numeric' })} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;

                const outcomeIsBlocked = ev.outcome.toUpperCase().includes('BLOCK') || ev.outcome.toUpperCase().includes('STRIP') || ev.outcome.toUpperCase().includes('BAN');

                return (
                  <tr 
                    key={ev.id}
                    onClick={() => setSelectedEvent(ev)}
                    style={{
                      cursor: 'pointer',
                      backgroundColor: isSelected ? 'rgba(99, 102, 241, 0.08)' : undefined
                    }}
                  >
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div style={{
                          width: '22px',
                          height: '22px',
                          borderRadius: '50%',
                          backgroundColor: 'var(--bg-base)',
                          border: '1px solid var(--border-neutral)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '0.625rem',
                          fontWeight: 700,
                          flexShrink: 0
                        }}>
                          {ev.actor_tag.substring(0, 1).toUpperCase()}
                        </div>
                        <div style={{ minWidth: 0 }}>
                          <div style={{
                            fontWeight: 600,
                            fontSize: '0.8125rem',
                            color: 'var(--text-primary)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}>
                            {ev.actor_tag}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.75rem',
                        fontWeight: 600,
                        color: 'var(--text-primary)'
                      }}>
                        {ev.action_type}
                      </span>
                    </td>
                    <td style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                      {ev.target}
                    </td>
                    <td style={{ fontSize: '0.8125rem', color: 'var(--text-tertiary)' }}>
                      {ev.reason}
                    </td>
                    <td>
                      <span className={`badge ${
                        outcomeIsBlocked ? 'badge-critical' : 'badge-success'
                      }`} style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                        {ev.outcome}
                      </span>
                    </td>
                    <td style={{ textAlign: 'right', fontSize: '0.75rem', color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>
                      {timeStr}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}

        {/* Pagination Footer */}
        <div style={{
          padding: '10px 18px',
          borderTop: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          fontSize: '0.75rem',
          color: 'var(--text-secondary)'
        }}>
          <div>
            Showing {filteredEvents.length === 0 ? 0 : (page - 1) * pageSize + 1} to {Math.min(page * pageSize, filteredEvents.length)} of {filteredEvents.length} events
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="btn btn-secondary btn-sm"
              style={{ padding: '3px 8px' }}
            >
              <ChevronLeft size={13} /> Previous
            </button>
            <span style={{ fontFamily: 'var(--font-mono)' }}>{page} / {totalPages}</span>
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="btn btn-secondary btn-sm"
              style={{ padding: '3px 8px' }}
            >
              Next <ChevronRight size={13} />
            </button>
          </div>
        </div>
      </div>

      {/* 3. Slide-Over Detail View Side Panel for Selected Event */}
      {selectedEvent && (
        <div style={{
          position: 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          width: '420px',
          backgroundColor: 'var(--bg-panel)',
          borderLeft: '1px solid var(--border-neutral)',
          boxShadow: '-8px 0 32px rgba(0, 0, 0, 0.6)',
          zIndex: 100,
          padding: '24px',
          display: 'flex',
          flexDirection: 'column',
          gap: '18px',
          overflowY: 'auto'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span className={`badge ${
                selectedEvent.severity === 'CRITICAL' ? 'badge-critical' : 'badge-primary'
              }`}>
                {selectedEvent.severity}
              </span>
              <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Event Inspection
              </span>
            </div>

            <button
              onClick={() => setSelectedEvent(null)}
              style={{ background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer', padding: '4px' }}
            >
              <X size={16} />
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '0.8125rem' }}>
            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>Action Type</div>
              <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginTop: '2px', fontFamily: 'var(--font-mono)' }}>
                {selectedEvent.action_type}
              </div>
            </div>

            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>Actor Identity</div>
              <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginTop: '2px' }}>
                {selectedEvent.actor_tag}
              </div>
              <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-tertiary)' }}>
                Snowflake: {selectedEvent.actor_id}
              </div>
            </div>

            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>Target Resource</div>
              <div style={{ color: 'var(--text-primary)', marginTop: '2px' }}>
                {selectedEvent.target}
              </div>
            </div>

            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>Reason / Cause</div>
              <div style={{ color: 'var(--text-secondary)', marginTop: '2px' }}>
                {selectedEvent.reason}
              </div>
            </div>

            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>Enforcement Outcome</div>
              <div style={{ marginTop: '2px' }}>
                <span className="badge badge-critical" style={{ fontSize: '0.75rem' }}>
                  {selectedEvent.outcome}
                </span>
              </div>
            </div>

            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>Exact Timestamp</div>
              <div style={{ color: 'var(--text-primary)', marginTop: '2px', fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>
                {new Date(selectedEvent.timestamp).toISOString()}
              </div>
            </div>

            {/* Raw JSON inspection */}
            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase', marginBottom: '4px' }}>
                Correlated Audit Payload
              </div>
              <pre style={{
                backgroundColor: 'var(--bg-base)',
                border: '1px solid var(--border-neutral)',
                borderRadius: '4px',
                padding: '10px',
                fontSize: '0.6875rem',
                fontFamily: 'var(--font-mono)',
                color: 'var(--text-secondary)',
                overflowX: 'auto',
                whiteSpace: 'pre-wrap'
              }}>
                {JSON.stringify(selectedEvent.metadata, null, 2)}
              </pre>
            </div>
          </div>

          {selectedEvent.isAlert && selectedEvent.status !== 'RESOLVED' && (
            <div style={{ marginTop: 'auto', paddingTop: '16px', borderTop: '1px solid var(--border-neutral)' }}>
              <button
                onClick={() => handleResolveAlert(selectedEvent.rawId)}
                className="btn btn-primary"
                style={{ width: '100%', fontSize: '0.8125rem' }}
              >
                <CheckCircle2 size={14} /> Mark Incident as Resolved
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
