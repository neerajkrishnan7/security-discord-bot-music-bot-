import React, { useState, useEffect } from 'react';
import { FileText, Save, CheckCircle2, Shield, User, MessageSquare, Volume2, ShieldAlert } from 'lucide-react';
import { fetchLoggingConfig, updateLoggingConfig } from '../api';

export default function LoggingTab({ guildId }) {
  const [cfg, setCfg] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    fetchLoggingConfig(guildId).then(setCfg).catch(() => {});
  }, [guildId]);

  const handleSave = async (e) => {
    e.preventDefault();
    await updateLoggingConfig(guildId, cfg);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  if (!cfg) return null;

  const channels = [
    { key: 'security_log_channel_id', label: 'Security & Sentinel Incident Logs', icon: ShieldAlert, desc: 'Real-time alerts for anti-nuke, anti-raid, and rogue bot additions.' },
    { key: 'mod_log_channel_id', label: 'Moderation Action Logs', icon: Shield, desc: 'Warns, timeouts, kicks, bans, and escalation punishments.' },
    { key: 'member_log_channel_id', label: 'Member Join & Departure Logs', icon: User, desc: 'Records when users join, leave, or are kicked.' },
    { key: 'message_log_channel_id', label: 'Message Edit & Deletion Logs', icon: MessageSquare, desc: 'Logs deleted and edited messages where permitted.' },
    { key: 'role_log_channel_id', label: 'Role & Permission Modification Logs', icon: FileText, desc: 'Tracks changes to role names, colors, and permissions.' },
    { key: 'voice_log_channel_id', label: 'Voice State & Channel Logs', icon: Volume2, desc: 'Tracks users joining, leaving, and switching voice channels.' }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <form onSubmit={handleSave} className="glass-panel" style={{ padding: '28px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <h2 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <FileText size={20} color="var(--primary-light)" />
              Dedicated Logging Channels Configuration
            </h2>
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Route specific categories of server activity to dedicated audit channels.
            </p>
          </div>

          <button type="submit" className="btn btn-primary" style={{ fontSize: '0.82rem' }}>
            <Save size={16} /> Save Logging Channels
          </button>
        </div>

        {saveSuccess && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--success)', fontSize: '0.82rem', fontWeight: 600, marginBottom: '16px' }}>
            <CheckCircle2 size={16} /> Logging channels saved to database
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '16px' }}>
          {channels.map(item => {
            const Icon = item.icon;
            return (
              <div 
                key={item.key}
                style={{
                  background: 'rgba(0, 0, 0, 0.25)',
                  padding: '18px',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid rgba(255, 255, 255, 0.04)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Icon size={18} color="var(--primary-light)" />
                  <span style={{ fontSize: '0.88rem', fontWeight: 700, color: '#ffffff' }}>
                    {item.label}
                  </span>
                </div>

                <div style={{ fontSize: '0.74rem', color: 'var(--text-dim)', lineHeight: 1.3 }}>
                  {item.desc}
                </div>

                <input
                  type="text"
                  placeholder="Discord Channel ID"
                  value={cfg[item.key] || ''}
                  onChange={(e) => setCfg({ ...cfg, [item.key]: e.target.value })}
                  style={{ marginTop: '4px' }}
                />
              </div>
            );
          })}
        </div>
      </form>
    </div>
  );
}
