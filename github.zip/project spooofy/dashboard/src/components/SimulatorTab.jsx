import React, { useState } from 'react';
import { 
  Zap, 
  Terminal, 
  ShieldAlert, 
  Trash2, 
  Bot, 
  KeyRound, 
  Users, 
  FileWarning, 
  Play, 
  CheckCircle2,
  Clock
} from 'lucide-react';

export default function SimulatorTab({ onRunSimulation, onNavigateTab }) {
  const [activeScenario, setActiveScenario] = useState(null);
  const [simulationLogs, setSimulationLogs] = useState([]);
  const [isRunning, setIsRunning] = useState(false);

  const scenarios = [
    {
      id: 'mass_channel_delete',
      title: 'Mass Channel Deletion Attack',
      icon: Trash2,
      color: '#ef4444',
      desc: 'Simulates a compromised admin rapidly deleting 3 channels in 2 seconds to test anti-nuke threshold enforcement and instant ban response.'
    },
    {
      id: 'unauthorized_bot_add',
      title: 'Unauthorized Rogue Bot Addition',
      icon: Bot,
      color: '#f97316',
      desc: 'Simulates an unauthorized staff member adding an unverified bot. SPOOFY Sentinel detects the audit event, kicks the bot, and strips staff permissions.'
    },
    {
      id: 'permission_escalation',
      title: 'Admin Permission Escalation',
      icon: KeyRound,
      color: '#eab308',
      desc: 'Simulates a role being modified to grant dangerous Administrator privilege. SPOOFY Shield intercepts and instantly reverts permissions to safe state.'
    },
    {
      id: 'mass_raid_lockdown',
      title: 'Join Raid Flood & Auto-Lockdown',
      icon: Users,
      color: '#8b5cf6',
      desc: 'Simulates a sudden raid surge of 15 automated accounts joining in 6 seconds, triggering emergency server lockdown with automated unlock.'
    },
    {
      id: 'phishing_link_wave',
      title: 'Fake Nitro Phishing Link Spread',
      icon: FileWarning,
      color: '#06b6d4',
      desc: 'Simulates distribution of fake Discord Nitro links. SPOOFY Anti-Chat suppresses the malicious URL and quarantines the offender.'
    }
  ];

  const handleExecuteScenario = async (scenarioId) => {
    setIsRunning(true);
    setActiveScenario(scenarioId);

    const timestamp = new Date().toLocaleTimeString();
    addLog(`[${timestamp}] ⚡ INITIATING SIMULATION: ${scenarioId}...`);

    try {
      const outcome = await onRunSimulation(scenarioId);
      addLog(`[${new Date().toLocaleTimeString()}] ✅ ${outcome.message}`);
      if (outcome.results) {
        addLog(`[${new Date().toLocaleTimeString()}] 📊 Threshold Result: ${JSON.stringify(outcome.results[outcome.results.length - 1])}`);
      }
      addLog(`[${new Date().toLocaleTimeString()}] 🛡️ Security Alert dispatched to SPOOFY Sentinel & Live Stream.`);
    } catch (err) {
      addLog(`[${new Date().toLocaleTimeString()}] ❌ Simulation Error: ${err.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  const addLog = (msg) => {
    setSimulationLogs(prev => [msg, ...prev]);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* 1. Header */}
      <div className="glass-panel" style={{ padding: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <h2 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Zap size={20} color="var(--primary-light)" />
              SPOOFY Shield — Live Attack & Defense Simulator
            </h2>
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Test SPOOFY's real-time interception, sliding window thresholds, and audit log attribution directly from the dashboard.
            </p>
          </div>

          <button onClick={() => onNavigateTab('sentinel')} className="btn btn-secondary" style={{ fontSize: '0.82rem' }}>
            View Live Sentinel Alerts Stream
          </button>
        </div>
      </div>

      {/* 2. Scenarios Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '16px' }}>
        {scenarios.map(s => {
          const Icon = s.icon;
          const isCurrent = activeScenario === s.id && isRunning;

          return (
            <div 
              key={s.id}
              className="glass-panel glow-card"
              style={{
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                borderLeft: `4px solid ${s.color}`
              }}
            >
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px' }}>
                  <div style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: '8px',
                    background: `${s.color}20`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    border: `1px solid ${s.color}60`
                  }}>
                    <Icon size={18} color={s.color} />
                  </div>
                  <h3 style={{ fontSize: '0.94rem', fontWeight: 700, color: '#ffffff' }}>
                    {s.title}
                  </h3>
                </div>

                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
                  {s.desc}
                </p>
              </div>

              <button
                onClick={() => handleExecuteScenario(s.id)}
                disabled={isRunning}
                className="btn btn-primary"
                style={{
                  marginTop: '16px',
                  width: '100%',
                  fontSize: '0.8rem',
                  background: isCurrent ? 'var(--warning)' : undefined
                }}
              >
                <Play size={14} />
                {isCurrent ? 'Simulating Attack Vector...' : 'Launch Simulation'}
              </button>
            </div>
          );
        })}
      </div>

      {/* 3. Live Simulator Terminal */}
      <div className="glass-panel" style={{ padding: '22px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Terminal size={18} color="var(--cyan)" />
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#ffffff' }}>
              Real-Time Defense Execution Terminal
            </h3>
          </div>
          {simulationLogs.length > 0 && (
            <button onClick={() => setSimulationLogs([])} className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '0.72rem' }}>
              Clear Terminal
            </button>
          )}
        </div>

        <div style={{
          background: '#07050d',
          border: '1px solid rgba(139, 92, 246, 0.25)',
          borderRadius: 'var(--radius-sm)',
          padding: '16px',
          minHeight: '160px',
          maxHeight: '260px',
          overflowY: 'auto',
          fontFamily: 'var(--font-mono)',
          fontSize: '0.78rem',
          lineHeight: 1.6,
          display: 'flex',
          flexDirection: 'column',
          gap: '6px'
        }}>
          {simulationLogs.length === 0 ? (
            <span style={{ color: 'var(--text-dim)' }}>
              &gt; Simulator initialized and standing by. Select an attack scenario above to test SPOOFY Shield.
            </span>
          ) : (
            simulationLogs.map((log, i) => (
              <span key={i} style={{ color: log.includes('❌') ? '#f87171' : log.includes('✅') ? '#34d399' : log.includes('⚡') ? '#fbbf24' : '#c084fc' }}>
                {log}
              </span>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
