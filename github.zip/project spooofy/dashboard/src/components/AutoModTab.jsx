import React, { useState } from 'react';
import { 
  Sliders, 
  Save, 
  CheckCircle2, 
  ShieldCheck, 
  AlertTriangle, 
  Filter, 
  Clock,
  MessageSquare
} from 'lucide-react';

export default function AutoModTab({ config, onUpdateConfig }) {
  const [minAge, setMinAge] = useState(config?.account_age_min_days ?? 3);
  const [ageAction, setAgeAction] = useState(config?.account_age_action ?? 'quarantine');
  const [verifyRoleId, setVerifyRoleId] = useState(config?.verification_role_id ?? '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const automodRules = [
    { key: 'anti_spam_enabled', title: 'Chat Flood & Rapid Rate-Limiting', desc: 'Deletes rapid repeated messages and temporarily silences members flooding channels.' },
    { key: 'anti_invite_enabled', title: 'Discord Invite Link Suppression', desc: 'Automatically deletes external server invite links to prevent unauthorized advertising.' },
    { key: 'anti_everyone_enabled', title: 'Mass Mention & @everyone Filter', desc: 'Blocks unauthorized @everyone, @here, and mass user pings by non-privileged accounts.' },
    { key: 'anti_phishing_enabled', title: 'Scam Domains & Malicious Links', desc: 'Scans URLs against real-time phishing and fake Discord gift telemetry databases.' }
  ];

  const handleSaveAll = async () => {
    await onUpdateConfig({
      account_age_min_days: parseInt(minAge, 10),
      account_age_action: ageAction,
      verification_role_id: verifyRoleId.trim()
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleToggle = async (key, checked) => {
    await onUpdateConfig({ [key]: checked ? 1 : 0 });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Sliders size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Auto Moderation Policies
            </h2>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Automated message inspection, invite filters, and new account containment.
          </p>
        </div>

        {saveSuccess && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#10b981', fontSize: '0.8125rem', fontWeight: 600 }}>
            <CheckCircle2 size={15} /> Saved to Database
          </div>
        )}
      </div>

      {/* 2. Content Filters Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Real-Time Message Filters
          </span>
          <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
            Inspected prior to Discord message dispatch
          </span>
        </div>

        <table>
          <thead>
            <tr>
              <th style={{ width: '260px' }}>Filter Rule</th>
              <th>Behavior Description</th>
              <th style={{ width: '90px', textAlign: 'right' }}>Active</th>
            </tr>
          </thead>
          <tbody>
            {automodRules.map((rule) => {
              const isChecked = Boolean(config?.[rule.key]);
              return (
                <tr key={rule.key}>
                  <td>
                    <span style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                      {rule.title}
                    </span>
                  </td>
                  <td style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                    {rule.desc}
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <label className="switch">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => handleToggle(rule.key, e.target.checked)}
                      />
                      <span className="slider" />
                    </label>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* 3. Account-Age Gate & Verification Setup Form */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '20px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
          <div>
            <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <ShieldCheck size={16} color="var(--primary)" />
              Account-Age Gate & Verification Setup
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
              Restricts throwaway and fresh accounts created for raids or scamming.
            </div>
          </div>

          <button
            onClick={handleSaveAll}
            className="btn btn-primary btn-sm"
          >
            <Save size={13} /> Save Age Gate
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
          <div style={{
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '4px',
            padding: '14px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--text-primary)' }}>Minimum Account Age</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', color: 'var(--text-primary)', fontWeight: 700 }}>
                {minAge} days
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="30"
              value={minAge}
              onChange={(e) => setMinAge(e.target.value)}
              style={{ width: '100%', accentColor: 'var(--primary)' }}
            />
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '6px' }}>
              Accounts created less than {minAge} days ago trigger enforcement.
            </div>
          </div>

          <div style={{
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '4px',
            padding: '14px'
          }}>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '6px' }}>
              Enforcement Policy
            </label>
            <select
              value={ageAction}
              onChange={(e) => setAgeAction(e.target.value)}
              style={{ padding: '6px 10px', fontSize: '0.8125rem' }}
            >
              <option value="quarantine">Quarantine Timeout (28 days)</option>
              <option value="kick">Kick Account</option>
              <option value="verify">Require Button Verification</option>
              <option value="log">Log Only</option>
            </select>
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '6px' }}>
              Defines the automated punishment applied when an underage account joins.
            </div>
          </div>

          <div style={{
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '4px',
            padding: '14px'
          }}>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '6px' }}>
              Verification Role Snowflake ID
            </label>
            <input
              type="text"
              placeholder="e.g. 102938475610293847"
              value={verifyRoleId}
              onChange={(e) => setVerifyRoleId(e.target.value)}
              style={{ padding: '6px 10px', fontSize: '0.8125rem' }}
            />
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '6px' }}>
              Role assigned once member passes verification.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
