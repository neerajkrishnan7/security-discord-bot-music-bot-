import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Save, 
  CheckCircle2, 
  Trash2, 
  Plus, 
  HelpCircle,
  AlertTriangle,
  UserCheck,
  Shield,
  X
} from 'lucide-react';

const DEFAULT_ANTI_NUKE_RULES = [
  { action_type: 'CHANNEL_DELETE', label: 'Channel Deletion', desc: 'Mitigates mass deletion or nuking of text and voice channels.' },
  { action_type: 'ROLE_DELETE', label: 'Role Deletion', desc: 'Prevents rogue admins from stripping and deleting server roles.' },
  { action_type: 'MEMBER_BAN', label: 'Mass Member Bans', desc: 'Intercepts rapid mass ban sweeps against community members.' },
  { action_type: 'WEBHOOK_CREATE', label: 'Webhook Creation', desc: 'Restricts unauthorized webhook generation used for spam payloads.' },
  { action_type: 'ROLE_PERMISSION_UPDATE', label: 'Permission Escalation', desc: 'Blocks unauthorized granting of Administrator or Manage Server permissions.' },
  { action_type: 'MEMBER_KICK', label: 'Mass Member Kicks', desc: 'Halts rapid member expulsion across sliding rate windows.' },
  { action_type: 'SERVER_UPDATE', label: 'Server Tampering', desc: 'Reverts malicious changes to server name, icon, vanity, and verification.' }
];

export default function AntiNukeTab({ 
  config, 
  onUpdateConfig, 
  onUpdateThreshold, 
  trusted = [], 
  onAddTrusted, 
  onRemoveTrusted 
}) {
  const [thresholds, setThresholds] = useState(() => {
    const existing = config?.thresholds || [];
    return DEFAULT_ANTI_NUKE_RULES.map(def => {
      const found = existing.find(t => t.action_type === def.action_type);
      return {
        action_type: def.action_type,
        limit_count: found?.limit_count ?? 3,
        window_seconds: found?.window_seconds ?? 10,
        punishment: found?.punishment || 'STRIP_ROLES',
        enabled: found?.enabled ?? true
      };
    });
  });

  const [savingKey, setSavingKey] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(null);

  // Trusted admin modal state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTargetId, setNewTargetId] = useState('');
  const [newTargetType, setNewTargetType] = useState('user');
  const [newTargetTag, setNewTargetTag] = useState('');
  const [newNotes, setNewNotes] = useState('');

  // Confirmation dialog state for dangerous actions
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState(null);

  const handleFieldChange = (actionType, field, value) => {
    setThresholds(prev => prev.map(t => {
      if (t.action_type === actionType) {
        return { ...t, [field]: value };
      }
      return t;
    }));
  };

  const handleSaveRow = async (rule) => {
    setSavingKey(rule.action_type);
    try {
      await onUpdateThreshold(rule.action_type, {
        limit_count: parseInt(rule.limit_count, 10),
        window_seconds: parseInt(rule.window_seconds, 10),
        punishment: rule.punishment
      });
      setSaveSuccess(rule.action_type);
      setTimeout(() => setSaveSuccess(null), 2500);
    } catch (err) {
      console.error(err);
    } finally {
      setSavingKey(null);
    }
  };

  const handleAddTrustedSubmit = async (e) => {
    e.preventDefault();
    if (!newTargetId.trim()) return;
    await onAddTrusted({
      target_id: newTargetId.trim(),
      target_type: newTargetType,
      target_tag: newTargetTag.trim() || newTargetId.trim(),
      notes: newNotes.trim()
    });
    setNewTargetId('');
    setNewTargetTag('');
    setNewNotes('');
    setShowAddModal(false);
  };

  const confirmRemoveTrusted = async () => {
    if (deleteConfirmTarget) {
      await onRemoveTrusted(deleteConfirmTarget.target_id);
      setDeleteConfirmTarget(null);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header & Engine Master Toggle */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <ShieldAlert size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Anti-Nuke Defense Rules
            </h2>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Configure separate threshold velocities and automated penalty response policies per destructive action.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '0.8125rem', fontWeight: 600 }}>
            <span>Anti-Nuke Master Guard</span>
            <label className="switch">
              <input
                type="checkbox"
                checked={Boolean(config?.anti_nuke_enabled)}
                onChange={(e) => onUpdateConfig({ anti_nuke_enabled: e.target.checked ? 1 : 0 })}
              />
              <span className="slider" />
            </label>
          </label>
        </div>
      </div>

      {/* 2. Anti-Nuke Rule Configuration Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Configurable Velocity Policies
          </span>
          <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
            Actions exceeding threshold in time window trigger immediate response
          </span>
        </div>

        <table>
          <thead>
            <tr>
              <th style={{ width: '220px' }}>Protected Action</th>
              <th style={{ width: '130px' }}>Threshold Limit</th>
              <th style={{ width: '130px' }}>Sliding Window</th>
              <th style={{ width: '160px' }}>Response Policy</th>
              <th style={{ width: '100px', textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {DEFAULT_ANTI_NUKE_RULES.map((def) => {
              const rule = thresholds.find(t => t.action_type === def.action_type) || {
                limit_count: 3,
                window_seconds: 10,
                punishment: 'STRIP_ROLES'
              };
              const isSaving = savingKey === def.action_type;
              const isSaved = saveSuccess === def.action_type;

              return (
                <tr key={def.action_type}>
                  <td>
                    <div style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                      {def.label}
                    </div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>
                      {def.desc}
                    </div>
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <input
                        type="number"
                        min="1"
                        max="20"
                        value={rule.limit_count}
                        onChange={(e) => handleFieldChange(def.action_type, 'limit_count', e.target.value)}
                        style={{ width: '60px', padding: '5px 8px', fontSize: '0.8125rem', textAlign: 'center' }}
                      />
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>actions</span>
                    </div>
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <input
                        type="number"
                        min="2"
                        max="300"
                        value={rule.window_seconds}
                        onChange={(e) => handleFieldChange(def.action_type, 'window_seconds', e.target.value)}
                        style={{ width: '60px', padding: '5px 8px', fontSize: '0.8125rem', textAlign: 'center' }}
                      />
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>sec</span>
                    </div>
                  </td>
                  <td>
                    <select
                      value={rule.punishment}
                      onChange={(e) => handleFieldChange(def.action_type, 'punishment', e.target.value)}
                      style={{ padding: '5px 8px', fontSize: '0.8125rem' }}
                    >
                      <option value="STRIP_ROLES">Strip Admin Roles</option>
                      <option value="QUARANTINE">Quarantine Member</option>
                      <option value="KICK">Kick Offender</option>
                      <option value="BAN">Permanently Ban</option>
                    </select>
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <button
                      onClick={() => handleSaveRow(rule)}
                      disabled={isSaving}
                      className="btn btn-secondary btn-sm"
                      style={{ fontSize: '0.75rem', padding: '4px 10px' }}
                    >
                      {isSaved ? (
                        <>
                          <CheckCircle2 size={13} color="#10b981" />
                          <span style={{ color: '#10b981' }}>Saved</span>
                        </>
                      ) : (
                        <>
                          <Save size={13} />
                          <span>{isSaving ? '...' : 'Save'}</span>
                        </>
                      )}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* 3. Trusted Administrator Allowlist */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '14px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <div>
            <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <UserCheck size={16} color="var(--primary)" />
              Trusted Administrators & Bypass Allowlist
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
              Identities listed here bypass anti-nuke velocity thresholds and auto-stripping during legitimate maintenance.
            </div>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="btn btn-primary btn-sm"
          >
            <Plus size={13} /> Add Trusted Identity
          </button>
        </div>

        {trusted.length === 0 ? (
          <div style={{ padding: '32px 18px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
            No trusted identities configured. Only the Discord Guild Owner is exempt from anti-nuke triggers.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Identity</th>
                <th style={{ width: '90px' }}>Type</th>
                <th>Discord Snowflake ID</th>
                <th>Internal Notes</th>
                <th style={{ width: '80px', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {trusted.map((t) => (
                <tr key={t.target_id}>
                  <td>
                    <span style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                      {t.target_tag || t.target_id}
                    </span>
                  </td>
                  <td>
                    <span className="badge" style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                      {t.target_type.toUpperCase()}
                    </span>
                  </td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    {t.target_id}
                  </td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    {t.notes || '—'}
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <button
                      onClick={() => setDeleteConfirmTarget(t)}
                      className="btn btn-ghost btn-sm"
                      style={{ color: '#f87171', padding: '4px 6px' }}
                      title="Remove from allowlist"
                    >
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Confirmation Dialog Modal for Removing Trusted Member */}
      {deleteConfirmTarget && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 999
        }}>
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '6px',
            padding: '24px',
            maxWidth: '420px',
            width: '90%'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#ef4444', marginBottom: '12px' }}>
              <AlertTriangle size={20} />
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Confirm Allowlist Revocation
              </h3>
            </div>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              Are you sure you want to remove <strong>{deleteConfirmTarget.target_tag || deleteConfirmTarget.target_id}</strong> from the trusted allowlist? They will immediately be subject to Anti-Nuke velocity tracking.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '20px' }}>
              <button
                onClick={() => setDeleteConfirmTarget(null)}
                className="btn btn-secondary btn-sm"
              >
                Cancel
              </button>
              <button
                onClick={confirmRemoveTrusted}
                className="btn btn-danger btn-sm"
              >
                Confirm Removal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Trusted Identity */}
      {showAddModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 999
        }}>
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '6px',
            padding: '24px',
            maxWidth: '480px',
            width: '90%'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Add Trusted Administrator
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                style={{ background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer' }}
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleAddTrustedSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                  Target Type
                </label>
                <select
                  value={newTargetType}
                  onChange={(e) => setNewTargetType(e.target.value)}
                >
                  <option value="user">Discord User</option>
                  <option value="role">Discord Role</option>
                </select>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                  Discord Snowflake ID *
                </label>
                <input
                  type="text"
                  placeholder="e.g. 182749102948192019"
                  value={newTargetId}
                  onChange={(e) => setNewTargetId(e.target.value)}
                  required
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                  Tag / Label
                </label>
                <input
                  type="text"
                  placeholder="e.g. Lead Developer or @Head-Admin"
                  value={newTargetTag}
                  onChange={(e) => setNewTargetTag(e.target.value)}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                  Internal Verification Notes
                </label>
                <input
                  type="text"
                  placeholder="Reason for exemption"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '12px' }}>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="btn btn-secondary btn-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary btn-sm"
                >
                  Save Identity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
