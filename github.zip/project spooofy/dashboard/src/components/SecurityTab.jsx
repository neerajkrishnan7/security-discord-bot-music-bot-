import React, { useState } from 'react';
import { 
  ShieldCheck, 
  SearchCode, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  Lock, 
  Sliders,
  ShieldAlert
} from 'lucide-react';

export default function SecurityTab({ 
  config, 
  onUpdateConfig, 
  scannerData, 
  onRunScan 
}) {
  const [isScanning, setIsScanning] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState(null);

  const handleScan = async () => {
    setIsScanning(true);
    try {
      await onRunScan();
    } finally {
      setIsScanning(false);
    }
  };

  const handleToggle = async (key, checked) => {
    await onUpdateConfig({ [key]: checked ? 1 : 0 });
    setSaveFeedback(key);
    setTimeout(() => setSaveFeedback(null), 2000);
  };

  const score = scannerData?.securityScore ?? 85;
  const rating = scannerData?.statusRating ?? 'GOOD';
  const findings = scannerData?.findings || [];

  const securityModules = [
    { key: 'anti_raid_enabled', title: 'Anti-Raid Velocity Defense', desc: 'Monitors member join velocity. Triggers temporary server lockdown if a mass join attack is detected.' },
    { key: 'anti_bot_enabled', title: 'Unauthorized Bot Interceptor', desc: 'Instantly expels any bot added to the server by administrators not on the trusted allowlist.' },
    { key: 'anti_impersonation_enabled', title: 'Anti-Impersonation & Homoglyphs', desc: 'Flags or renames accounts attempting to clone server owner or staff usernames using unicode tricks.' },
    { key: 'anti_phishing_enabled', title: 'Anti-Phishing & Scam Domains', desc: 'Suppresses known Discord phishing URLs, fake Nitro gifts, and executable attachment payloads.' },
    { key: 'anti_everyone_enabled', title: 'Mass Mention / @everyone Guard', desc: 'Silences non-whitelisted members attempting unauthorized @everyone or @here mentions.' }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Security Posture & Vulnerability Scanner Card */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '20px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          {/* Audit Score Badge */}
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '6px',
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0
          }}>
            <span style={{ fontSize: '1.375rem', fontWeight: 800, color: score >= 80 ? '#10b981' : score >= 60 ? '#f59e0b' : '#ef4444' }}>
              {score}
            </span>
            <span style={{ fontSize: '0.625rem', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>
              / 100
            </span>
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Security Posture & Least-Privilege Audit
              </h2>
              <span className={`badge ${score >= 80 ? 'badge-success' : 'badge-warning'}`} style={{ fontSize: '0.6875rem' }}>
                {rating}
              </span>
            </div>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px', maxWidth: '640px' }}>
              Automated audit evaluating server role permissions, administrator flags, dangerous integration exposures, and verification requirements.
            </p>
          </div>
        </div>

        <button
          onClick={handleScan}
          disabled={isScanning}
          className="btn btn-secondary btn-sm"
        >
          <RefreshCw size={14} className={isScanning ? 'spin' : ''} />
          {isScanning ? 'Evaluating Roles...' : 'Re-Run Audit'}
        </button>
      </div>

      {/* 2. Audit Findings Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Audit Findings & Recommendations ({findings.length})
          </span>
          <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
            Last analyzed: {scannerData?.scannedAt ? new Date(scannerData.scannedAt * 1000).toLocaleTimeString() : 'Current session'}
          </span>
        </div>

        {findings.length === 0 ? (
          <div style={{ padding: '28px 18px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
            No dangerous privilege escalations or exposed administrator flags detected.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th style={{ width: '90px' }}>Severity</th>
                <th style={{ width: '180px' }}>Component</th>
                <th>Finding Description</th>
                <th>Recommended Remediation</th>
              </tr>
            </thead>
            <tbody>
              {findings.map((f, i) => (
                <tr key={i}>
                  <td>
                    <span className={`badge ${
                      f.severity === 'CRITICAL' ? 'badge-critical' :
                      f.severity === 'HIGH' ? 'badge-critical' :
                      f.severity === 'MEDIUM' ? 'badge-warning' : 'badge-primary'
                    }`} style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                      {f.severity}
                    </span>
                  </td>
                  <td style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                    {f.type || 'Role Hierarchy'}
                  </td>
                  <td style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                    {f.message}
                  </td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                    {f.recommendation || 'Review role permissions and remove excessive administrator flags.'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* 3. Perimeter Protection Modules Configuration Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <div>
            <div style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Perimeter Protection Modules
            </div>
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '2px' }}>
              Real-time automated inspection and suppression rules
            </div>
          </div>
          {saveFeedback && (
            <span style={{ fontSize: '0.75rem', color: '#10b981', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <CheckCircle2 size={13} /> Setting Saved
            </span>
          )}
        </div>

        <table>
          <thead>
            <tr>
              <th style={{ width: '240px' }}>Module</th>
              <th>Description</th>
              <th style={{ width: '80px', textAlign: 'right' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {securityModules.map((item) => {
              const isChecked = Boolean(config?.[item.key]);
              return (
                <tr key={item.key}>
                  <td>
                    <span style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                      {item.title}
                    </span>
                  </td>
                  <td style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                    {item.desc}
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <label className="switch">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => handleToggle(item.key, e.target.checked)}
                      />
                      <span className="slider" />
                    </label>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
