import React, { useState } from 'react';
import { 
  SearchCode, 
  RefreshCw, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  Lightbulb,
  ExternalLink
} from 'lucide-react';

export default function ScannerTab({ scannerData, onRunScan }) {
  const [isScanning, setIsScanning] = useState(false);

  const handleScan = async () => {
    setIsScanning(true);
    try {
      await onRunScan();
    } finally {
      setIsScanning(false);
    }
  };

  const score = scannerData?.securityScore ?? 85;
  const rating = scannerData?.statusRating ?? 'GOOD';
  const findings = scannerData?.findings || [];

  let scoreColor = 'var(--success)';
  if (score < 60) scoreColor = 'var(--danger)';
  else if (score < 80) scoreColor = 'var(--warning)';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* 1. Score & Audit Trigger */}
      <div className="glass-panel" style={{ padding: '28px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            {/* Score Ring */}
            <div style={{
              width: '100px',
              height: '100px',
              borderRadius: '50%',
              border: `6px solid ${scoreColor}`,
              boxShadow: `0 0 20px ${scoreColor}40`,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'rgba(0, 0, 0, 0.4)'
            }}>
              <span className="mono-text" style={{ fontSize: '1.8rem', fontWeight: 800, color: '#ffffff', lineHeight: 1 }}>
                {score}
              </span>
              <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginTop: '2px' }}>
                / 100
              </span>
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#ffffff' }}>
                  Permission Scanner & Least-Privilege Engine
                </h2>
                <span className="badge" style={{
                  background: `${scoreColor}20`,
                  color: scoreColor,
                  border: `1px solid ${scoreColor}60`
                }}>
                  {rating}
                </span>
              </div>
              <p style={{ fontSize: '0.84rem', color: 'var(--text-muted)', marginTop: '6px', maxWidth: '540px' }}>
                Audits server roles, dangerous Administrator flags, @everyone exposures, bot integrations, and role hierarchy vulnerabilities.
              </p>
            </div>
          </div>

          <button
            onClick={handleScan}
            disabled={isScanning}
            className="btn btn-primary"
            style={{ fontSize: '0.88rem' }}
          >
            <RefreshCw size={16} className={isScanning ? 'spin' : ''} />
            {isScanning ? 'Scanning Audit Logs & Roles...' : 'Re-Run Security Audit'}
          </button>
        </div>
      </div>

      {/* 2. Findings List */}
      <div className="glass-panel" style={{ padding: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }}>
          <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <SearchCode size={18} color="var(--primary-light)" />
            Audit Findings ({findings.length})
          </h3>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
            Scanned: {scannerData?.scannedAt ? new Date(scannerData.scannedAt * 1000).toLocaleTimeString() : 'Recent'}
          </span>
        </div>

        {findings.length === 0 ? (
          <div style={{
            padding: '40px',
            textAlign: 'center',
            background: 'rgba(16, 185, 129, 0.05)',
            border: '1px solid rgba(16, 185, 129, 0.2)',
            borderRadius: 'var(--radius-sm)'
          }}>
            <CheckCircle2 size={36} color="var(--success)" style={{ margin: '0 auto 12px' }} />
            <div style={{ fontSize: '1rem', fontWeight: 700, color: '#ffffff' }}>Zero Security Vulnerabilities Detected</div>
            <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              @everyone permissions are tight, role hierarchy is safe, and administrative roles are consolidated.
            </div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {findings.map((f, i) => {
              const isCrit = f.severity === 'CRITICAL';
              const isHi = f.severity === 'HIGH';

              return (
                <div 
                  key={i}
                  style={{
                    padding: '18px 20px',
                    background: 'rgba(0, 0, 0, 0.25)',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid rgba(255, 255, 255, 0.05)',
                    borderLeft: `4px solid ${isCrit ? 'var(--danger)' : isHi ? 'var(--warning)' : 'var(--primary)'}`
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '16px' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span className={`badge ${isCrit ? 'badge-critical' : isHi ? 'badge-high' : 'badge-medium'}`}>
                          {f.severity}
                        </span>
                        <span className="mono-text" style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                          Target: {f.target}
                        </span>
                      </div>

                      <h4 style={{ fontSize: '0.94rem', fontWeight: 700, color: '#ffffff', marginTop: '6px' }}>
                        {f.title}
                      </h4>

                      <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px', lineHeight: 1.4 }}>
                        {f.description}
                      </p>

                      <div style={{
                        marginTop: '12px',
                        padding: '10px 14px',
                        background: 'rgba(139, 92, 246, 0.08)',
                        border: '1px solid rgba(139, 92, 246, 0.2)',
                        borderRadius: 'var(--radius-sm)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        fontSize: '0.78rem',
                        color: 'var(--primary-light)'
                      }}>
                        <Lightbulb size={16} style={{ flexShrink: 0 }} />
                        <span><strong>Remediation:</strong> {f.recommendation}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
