import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Activity, 
  Shield, 
  ShieldAlert, 
  Sliders, 
  Users, 
  FileText, 
  Database, 
  Ticket, 
  Music, 
  Settings,
  ChevronDown,
  LogOut,
  HelpCircle,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

export default function Sidebar({ 
  activeTab, 
  setActiveTab, 
  currentGuild, 
  guilds = [], 
  onSelectGuild, 
  auth, 
  alertStats 
}) {
  const navigate = useNavigate();

  const navItems = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'antinuke', label: 'Anti-Nuke', icon: ShieldAlert, badge: 'Protected' },
    { id: 'automod', label: 'Auto Moderation', icon: Sliders },
    { id: 'members', label: 'Members', icon: Users },
    { id: 'audit', label: 'Audit Logs', icon: FileText, count: alertStats?.active > 0 ? alertStats.active : null },
    { id: 'backups', label: 'Backups', icon: Database },
    { id: 'tickets', label: 'Tickets', icon: Ticket },
    { id: 'music', label: 'Music', icon: Music },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const user = auth?.user || { username: 'Discord Admin', discriminator: '0001' };

  return (
    <aside style={{
      width: '250px',
      backgroundColor: 'var(--bg-sidebar)',
      borderRight: '1px solid var(--border-neutral)',
      display: 'flex',
      flexDirection: 'column',
      minHeight: 'calc(100vh - 56px)',
      flexShrink: 0,
      userSelect: 'none'
    }}>
      {/* 1. App Wordmark & Logo */}
      <div style={{
        padding: '16px 18px 12px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: '1px solid var(--border-subtle)'
      }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
          <div style={{
            width: '28px',
            height: '28px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0
          }}>
            <img 
              src="/assets/spoofy_logo.png" 
              alt="SPOOFY" 
              style={{ width: '100%', height: '100%', objectFit: 'contain' }} 
            />
          </div>
          <div>
            <div style={{
              fontSize: '0.875rem',
              fontWeight: 800,
              color: 'var(--text-primary)',
              letterSpacing: '-0.02em',
              lineHeight: 1.1
            }}>
              VELORA
            </div>
            <div style={{
              fontSize: '0.625rem',
              color: 'var(--text-tertiary)',
              fontFamily: 'var(--font-mono)'
            }}>
              SPOOFY Console
            </div>
          </div>
        </Link>

        <span style={{
          fontSize: '0.6875rem',
          color: 'var(--text-tertiary)',
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          padding: '2px 6px',
          borderRadius: '4px',
          fontWeight: 500
        }}>
          v2.4
        </span>
      </div>

      {/* 2. Server Selector Header */}
      <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{
          position: 'relative',
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '7px 10px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px'
        }}>
          {/* Server Icon / Initials */}
          <div style={{
            width: '24px',
            height: '24px',
            borderRadius: '4px',
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '0.6875rem',
            fontWeight: 700,
            color: 'var(--text-primary)',
            flexShrink: 0,
            overflow: 'hidden'
          }}>
            {currentGuild?.icon ? (
              <img src={currentGuild.icon} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            ) : (
              (currentGuild?.name || 'GS').substring(0, 2).toUpperCase()
            )}
          </div>

          <div style={{ flex: 1, minWidth: 0 }}>
            <select
              value={currentGuild?.id || ''}
              onChange={(e) => {
                const found = guilds.find(g => g.id === e.target.value);
                if (found && onSelectGuild) onSelectGuild(found);
              }}
              style={{
                width: '100%',
                background: 'transparent',
                border: 'none',
                color: 'var(--text-primary)',
                fontSize: '0.8125rem',
                fontWeight: 600,
                outline: 'none',
                cursor: 'pointer',
                textOverflow: 'ellipsis',
                overflow: 'hidden',
                whiteSpace: 'nowrap',
                padding: 0
              }}
            >
              {guilds.map(g => (
                <option key={g.id} value={g.id} style={{ backgroundColor: '#141518', color: '#ffffff' }}>
                  {g.name}
                </option>
              ))}
            </select>
          </div>

          <ChevronDown size={13} color="var(--text-tertiary)" />
        </div>
      </div>

      {/* 3. Navigation List */}
      <nav style={{
        flex: 1,
        padding: '10px 10px',
        display: 'flex',
        flexDirection: 'column',
        gap: '2px',
        overflowY: 'auto'
      }}>
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '7px 10px',
                borderRadius: '4px',
                border: 'none',
                borderLeft: isActive ? '2px solid var(--primary)' : '2px solid transparent',
                backgroundColor: isActive ? 'var(--bg-panel)' : 'transparent',
                color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)',
                fontSize: '0.8125rem',
                fontWeight: isActive ? 600 : 500,
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'background-color 0.1s ease, color 0.1s ease',
                width: '100%'
              }}
              onMouseEnter={(e) => {
                if (!isActive) {
                  e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.03)';
                  e.currentTarget.style.color = 'var(--text-primary)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isActive) {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.color = 'var(--text-secondary)';
                }
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
                <Icon 
                  size={15} 
                  color={isActive ? 'var(--text-primary)' : 'var(--text-tertiary)'} 
                  strokeWidth={isActive ? 2.2 : 1.8} 
                />
                <span>{item.label}</span>
              </div>

              {item.count && (
                <span style={{
                  fontSize: '0.6875rem',
                  fontWeight: 600,
                  backgroundColor: 'rgba(239, 68, 68, 0.15)',
                  color: '#f87171',
                  border: '1px solid rgba(239, 68, 68, 0.3)',
                  padding: '1px 5px',
                  borderRadius: '3px'
                }}>
                  {item.count}
                </span>
              )}

              {item.badge && !item.count && (
                <span style={{
                  fontSize: '0.625rem',
                  fontWeight: 500,
                  color: 'var(--text-tertiary)',
                  padding: '1px 4px'
                }}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* 4. Bottom Controls & User Profile */}
      <div style={{
        padding: '12px 14px',
        borderTop: '1px solid var(--border-subtle)',
        display: 'flex',
        flexDirection: 'column',
        gap: '10px'
      }}>
        {/* Support & Docs links */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.75rem' }}>
          <Link 
            to="/docs" 
            style={{ 
              color: 'var(--text-tertiary)', 
              textDecoration: 'none', 
              display: 'flex', 
              alignItems: 'center', 
              gap: '4px' 
            }}
          >
            <HelpCircle size={12} /> Documentation
          </Link>
          <Link 
            to="/support" 
            style={{ 
              color: 'var(--text-tertiary)', 
              textDecoration: 'none', 
              display: 'flex', 
              alignItems: 'center', 
              gap: '4px' 
            }}
          >
            Support <ExternalLink size={11} />
          </Link>
        </div>

        {/* User Card */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '8px 10px',
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0 }}>
            <div style={{
              width: '24px',
              height: '24px',
              borderRadius: '50%',
              backgroundColor: 'var(--bg-base)',
              border: '1px solid var(--border-neutral)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '0.6875rem',
              fontWeight: 600,
              color: 'var(--text-primary)',
              flexShrink: 0
            }}>
              {user.avatar ? (
                <img src={user.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%' }} />
              ) : (
                (user.username || 'A').substring(0, 1).toUpperCase()
              )}
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{
                fontSize: '0.75rem',
                fontWeight: 600,
                color: 'var(--text-primary)',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}>
                {user.username}
              </div>
              <div style={{ fontSize: '0.625rem', color: 'var(--text-tertiary)' }}>
                {auth?.isOwner ? 'System Owner' : auth?.isStaff ? 'Staff' : 'Guild Admin'}
              </div>
            </div>
          </div>

          <Link
            to="/dashboard"
            title="Switch Server"
            style={{ color: 'var(--text-tertiary)', padding: '2px' }}
          >
            <LogOut size={13} />
          </Link>
        </div>
      </div>
    </aside>
  );
}
