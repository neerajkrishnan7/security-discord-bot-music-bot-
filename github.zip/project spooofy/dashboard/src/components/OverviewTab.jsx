import React from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  Activity, 
  Radio, 
  Database, 
  Users, 
  Cpu, 
  ArrowRight, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  Clock,
  FileText,
  UserCheck
} from 'lucide-react';

export default function OverviewTab({ 
  config, 
  health, 
  alerts = [], 
  alertStats = { total: 0, critical: 0, high: 0, active: 0 }, 
  backups = [], 
  trusted = [], 
  moderationCases = [], 
  auditLogs = [],
  onToggleShield, 
  onToggleLockdown, 
  onNavigateTab 
}) {
  const isCritical = alertStats?.critical > 0 || Boolean(config?.lockdown_active);
  const isHigh = alertStats?.high > 0;
  const isArmed = Boolean(config?.shield_enabled);
  const isLockdown = Boolean(config?.lockdown_active);

  const securityModules = [
    { name: 'Anti-Nuke Core', enabled: Boolean(config?.anti_nuke_enabled) },
    { name: 'Anti-Raid Auto-Lock', enabled: Boolean(config?.anti_raid_enabled) },
    { name: 'Anti-Bot Interceptor', enabled: Boolean(config?.anti_bot_enabled) },
    { name: 'Role Escalation Guard', enabled: Boolean(config?.anti_role_abuse_enabled) },
    { name: 'Webhook Destruction', enabled: Boolean(config?.anti_webhook_enabled) },
    { name: 'Server Settings Guard', enabled: Boolean(config?.anti_server_settings_enabled) },
    { name: 'Mass Mention / @everyone', enabled: Boolean(config?.anti_everyone_enabled) },
    { name: 'Chat Flood Filter', enabled: Boolean(config?.anti_spam_enabled) }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {/* 1. Compact Security Status Summary Banner */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderLeft: isLockdown 
          ? '3px solid #ef4444' 
          : isCritical 
            ? '3px solid #ef4444' 
            : isHigh 
              ? '3px solid #f59e0b' 
              : '3px solid #10b981',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '4px',
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            {isCritical ? (
              <ShieldAlert size={20} color="#ef4444" />
            ) : (
              <ShieldCheck size={20} color={isArmed ? '#10b981' : 'var(--text-tertiary)'} />
            )}
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '0.9375rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                {isLockdown 
                  ? 'Active Server Lockdown' 
                  : isCritical 
                    ? 'Security Threat Intercepted' 
                    : isArmed 
                      ? 'Perimeter Shield Active' 
                      : 'Perimeter Shield Standby'}
              </span>
              <span style={{
                fontSize: '0.6875rem',
                fontFamily: 'var(--font-mono)',
                backgroundColor: 'var(--bg-base)',
                border: '1px solid var(--border-neutral)',
                color: 'var(--text-secondary)',
                padding: '1px 6px',
                borderRadius: '3px'
              }}>
                Sliding Window Active
              </span>
            </div>
            <div style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
              {isLockdown 
                ? 'Message routing and member joins restricted. Click Release to restore regular operations.' 
                : 'Real-time Discord audit log correlation, threshold velocity monitoring, and auto-rollback active.'}
            </div>
          </div>
        </div>

        {/* Quick Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <button
            onClick={onToggleShield}
            className={`btn btn-sm ${isArmed ? 'btn-primary' : 'btn-secondary'}`}
          >
            <ShieldCheck size={14} />
            {isArmed ? 'Shield Armed' : 'Arm Shield'}
          </button>

          <button
            onClick={onToggleLockdown}
            className={`btn btn-sm ${isLockdown ? 'btn-danger' : 'btn-secondary'}`}
          >
            {isLockdown ? <Unlock size={14} /> : <Lock size={14} />}
            {isLockdown ? 'Release Lockdown' : 'Emergency Lockdown'}
          </button>
        </div>
      </div>

      {/* 2. Key Metrics Row */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '12px'
      }}>
        <div style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '14px 16px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-tertiary)', fontSize: '0.75rem', fontWeight: 500 }}>
            <span>Security Incidents</span>
            <Radio size={14} />
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '6px' }}>
            {alertStats?.active || 0}
          </div>
          <div style={{ display: 'flex', gap: '8px', fontSize: '0.6875rem', marginTop: '4px', color: 'var(--text-secondary)' }}>
            <span style={{ color: '#ef4444' }}>{alertStats?.critical || 0} Critical</span>
            <span>•</span>
            <span style={{ color: '#f59e0b' }}>{alertStats?.high || 0} High</span>
          </div>
        </div>

        <div style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '14px 16px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-tertiary)', fontSize: '0.75rem', fontWeight: 500 }}>
            <span>Moderation Cases</span>
            <Users size={14} />
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '6px' }}>
            {moderationCases?.length || 0}
          </div>
          <div style={{ fontSize: '0.6875rem', marginTop: '4px', color: 'var(--text-secondary)' }}>
            Warnings & automatic actions
          </div>
        </div>

        <div style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '14px 16px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-tertiary)', fontSize: '0.75rem', fontWeight: 500 }}>
            <span>Recovery Snapshots</span>
            <Database size={14} />
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '6px' }}>
            {backups?.length || 0}
          </div>
          <div style={{ fontSize: '0.6875rem', marginTop: '4px', color: 'var(--text-secondary)' }}>
            Stored point-in-time states
          </div>
        </div>

        <div style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '14px 16px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-tertiary)', fontSize: '0.75rem', fontWeight: 500 }}>
            <span>Trusted Allowlist</span>
            <UserCheck size={14} />
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '6px' }}>
            {trusted?.length || 0}
          </div>
          <div style={{ fontSize: '0.6875rem', marginTop: '4px', color: 'var(--text-secondary)' }}>
            Exempt staff & bots
          </div>
        </div>
      </div>

      {/* 3. Main Operational Grid: Tables & Health */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1.8fr 1.2fr',
        gap: '16px',
        alignItems: 'start'
      }}>
        {/* Left Column: Tables for Recent Security Incidents & Moderation */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Recent Security Incidents Table */}
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '5px',
            overflow: 'hidden'
          }}>
            <div style={{
              padding: '12px 16px',
              borderBottom: '1px solid var(--border-neutral)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <div>
                <div style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Recent Security Incidents
                </div>
                <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
                  Correlated actions exceeding anti-nuke velocity thresholds
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('audit')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem' }}
              >
                View All <ArrowRight size={12} />
              </button>
            </div>

            {alerts.length === 0 ? (
              <div style={{ padding: '28px 16px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
                No active security incidents recorded.
              </div>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th style={{ width: '85px' }}>Severity</th>
                    <th>Incident</th>
                    <th>Actor</th>
                    <th>Action Taken</th>
                    <th style={{ width: '75px', textAlign: 'right' }}>Time</th>
                  </tr>
                </thead>
                <tbody>
                  {alerts.slice(0, 5).map(a => (
                    <tr key={a.id}>
                      <td>
                        <span className={`badge ${
                          a.severity === 'CRITICAL' ? 'badge-critical' :
                          a.severity === 'HIGH' ? 'badge-warning' : 'badge-primary'
                        }`} style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                          {a.severity}
                        </span>
                      </td>
                      <td>
                        <div style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                          {a.title}
                        </div>
                        <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '1px' }}>
                          {a.description}
                        </div>
                      </td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                        {a.actor_tag || a.actor_id || 'System'}
                      </td>
                      <td style={{ fontSize: '0.75rem' }}>
                        <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>
                          {a.action_taken || 'Monitored'}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right', fontSize: '0.6875rem', color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>
                        {new Date(a.created_at * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Moderation Activity Table */}
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '5px',
            overflow: 'hidden'
          }}>
            <div style={{
              padding: '12px 16px',
              borderBottom: '1px solid var(--border-neutral)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <div>
                <div style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Moderation Activity
                </div>
                <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
                  Recent infractions, automated warnings, and enforcement
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('members')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem' }}
              >
                Manage Members <ArrowRight size={12} />
              </button>
            </div>

            {moderationCases.length === 0 ? (
              <div style={{ padding: '28px 16px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
                No recent moderation infractions logged.
              </div>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th style={{ width: '80px' }}>Type</th>
                    <th>Target Member</th>
                    <th>Reason</th>
                    <th style={{ width: '75px', textAlign: 'right' }}>Time</th>
                  </tr>
                </thead>
                <tbody>
                  {moderationCases.slice(0, 4).map(c => (
                    <tr key={c.id}>
                      <td>
                        <span className="badge badge-warning" style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                          {c.action_type || 'WARN'}
                        </span>
                      </td>
                      <td>
                        <span style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                          {c.user_tag || c.user_id}
                        </span>
                      </td>
                      <td style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                        {c.reason || 'Auto-moderation threshold violation'}
                      </td>
                      <td style={{ textAlign: 'right', fontSize: '0.6875rem', color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>
                        {new Date(c.created_at * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Right Column: Bot Health, Engine Status & Module Matrix */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Bot & System Health Box */}
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '5px',
            padding: '16px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Cpu size={15} color="var(--text-tertiary)" />
                <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Bot & Engine Telemetry
                </span>
              </div>
              <span className="badge badge-success" style={{ fontSize: '0.6875rem' }}>
                {health?.status || 'OPERATIONAL'}
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '0.75rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '6px', borderBottom: '1px solid var(--border-subtle)' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Discord Gateway Ping</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--text-primary)' }}>
                  {health?.gateway?.isReady ? `${health.gateway.pingMs} ms` : 'Local / 12 ms'}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '6px', borderBottom: '1px solid var(--border-subtle)' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Database Latency</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--text-primary)' }}>
                  {health?.database?.latencyMs ?? 0.2} ms (WAL mode)
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '6px', borderBottom: '1px solid var(--border-subtle)' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Heap Allocation</span>
                <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>
                  {health?.system?.memoryHeapMb ?? 42} MB / {health?.system?.memoryRssMb ?? 85} MB
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-secondary)' }}>System Uptime</span>
                <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>
                  {Math.floor((health?.system?.uptimeSeconds ?? 120) / 60)}m {(health?.system?.uptimeSeconds ?? 120) % 60}s
                </span>
              </div>
            </div>
          </div>

          {/* Defense Modules Status Grid */}
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '5px',
            padding: '16px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Security Rules Status
              </span>
              <button
                onClick={() => onNavigateTab('antinuke')}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--primary)',
                  fontSize: '0.75rem',
                  fontWeight: 500,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '3px',
                  padding: 0
                }}
              >
                Configure <ArrowRight size={12} />
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
              {securityModules.map((m, idx) => (
                <div 
                  key={idx}
                  style={{
                    padding: '6px 8px',
                    borderRadius: '4px',
                    backgroundColor: 'var(--bg-base)',
                    border: '1px solid var(--border-neutral)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                >
                  <span style={{ fontSize: '0.6875rem', color: 'var(--text-secondary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {m.name}
                  </span>
                  <span style={{
                    fontSize: '0.625rem',
                    fontWeight: 700,
                    color: m.enabled ? '#10b981' : 'var(--text-tertiary)',
                    fontFamily: 'var(--font-mono)'
                  }}>
                    {m.enabled ? 'ON' : 'OFF'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Audit Event Log Stream */}
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '5px',
            padding: '16px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <FileText size={14} color="var(--text-tertiary)" />
                <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Audit Event Stream
                </span>
              </div>
              <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
                Live Feed
              </span>
            </div>

            {auditLogs.length === 0 ? (
              <div style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', padding: '12px 0', textAlign: 'center' }}>
                No events streamed in this session.
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {auditLogs.slice(0, 4).map(log => (
                  <div 
                    key={log.id}
                    style={{
                      padding: '8px 10px',
                      borderRadius: '4px',
                      backgroundColor: 'var(--bg-base)',
                      border: '1px solid var(--border-subtle)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      fontSize: '0.75rem'
                    }}
                  >
                    <div>
                      <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>
                        {log.action_type}
                      </span>
                      <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
                        by {log.actor_tag || log.actor_id}
                      </div>
                    </div>
                    <span style={{
                      fontSize: '0.6875rem',
                      fontFamily: 'var(--font-mono)',
                      color: log.outcome === 'BLOCKED' ? '#f87171' : '#10b981'
                    }}>
                      {log.outcome}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
