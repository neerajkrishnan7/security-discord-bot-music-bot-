import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sliders, 
  UserCheck, 
  Trash2, 
  Plus, 
  Save, 
  CheckCircle2, 
  AlertOctagon, 
  ShieldAlert,
  HelpCircle
} from 'lucide-react';

export default function ShieldTab({ 
  config, 
  onUpdateConfig, 
  onUpdateThreshold, 
  trusted, 
  onAddTrusted, 
  onRemoveTrusted 
}) {
  const [thresholds, setThresholds] = useState(config?.thresholds || []);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showAddTrusted, setShowAddTrusted] = useState(false);
  const [newTrustedId, setNewTrustedId] = useState('');
  const [newTrustedType, setNewTrustedType] = useState('user');
  const [newTrustedTag, setNewTrustedTag] = useState('');
  const [newTrustedNotes, setNewTrustedNotes] = useState('');

  // Local handler for threshold change
  const handleThresholdChange = (actionType, field, val) => {
    setThresholds(prev => prev.map(t => {
      if (t.action_type === actionType) {
        return { ...t, [field]: val };
      }
      return t;
    }));
  };

  const handleSaveThreshold = async (t) => {
    await onUpdateThreshold(t.action_type, {
      limit_count: t.limit_count,
      window_seconds: t.window_seconds,
      punishment: t.punishment
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleAddTrustedSubmit = async (e) => {
    e.preventDefault();
    if (!newTrustedId) return;
    await onAddTrusted({
      target_id: newTrustedId.trim(),
      target_type: newTrustedType,
      target_tag: newTrustedTag.trim() || newTrustedId.trim(),
      notes: newTrustedNotes.trim()
    });
    setNewTrustedId('');
    setNewTrustedTag('');
    setNewTrustedNotes('');
    setShowAddTrusted(false);
  };

  const toggleList = [
    { key: 'anti_nuke_enabled', title: 'Anti-Nuke Core', desc: 'Detects and mitigates mass channel, role, and server resource deletions.' },
    { key: 'anti_raid_enabled', title: 'Anti-Raid Defense', desc: 'Monitors member join velocity; triggers automated panic lockdown upon surge.' },
    { key: 'anti_bot_enabled', title: 'Anti-Bot Guard', desc: 'Immediately kicks or bans unauthorized bot additions by non-trusted staff.' },
    { key: 'anti_role_abuse_enabled', title: 'Anti-Role Escalation', desc: 'Blocks unauthorized granting of Administrator or Manage Server permissions.' },
    { key: 'anti_webhook_enabled', title: 'Anti-Webhook Abuse', desc: 'Detects and destroys rogue webhooks created to spam or raid channels.' },
    { key: 'anti_server_settings_enabled', title: 'Anti-Server Tampering', desc: 'Reverts unauthorized alterations to server name, icon, and verification levels.' },
    { key: 'anti_everyone_enabled', title: 'Anti-Everyone / Mass Mention', desc: 'Deletes unauthorized @everyone / @here mentions and silences offender.' },
    { key: 'anti_invite_enabled', title: 'Anti-Invite Link Filter', desc: 'Deletes external Discord guild invite links to prevent unauthorized advertising.' },
    { key: 'anti_phishing_enabled', title: 'Anti-Phishing & Payloads', desc: 'Blocks known scam domains, fake Nitro links, and malicious executable attachments.' },
    { key: 'anti_spam_enabled', title: 'Chat Flood Rate-Limiter', desc: 'Enforces rapid sliding window rate-limiting on message repetitions and spam.' },
    { key: 'anti_impersonation_enabled', title: 'Anti-Impersonation Guard', desc: 'Flags members using unicode clones or homoglyphs of server owner / staff names.' }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      {/* 1. Module Toggles Grid */}
      <div className="glass-panel" style={{ padding: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <h2 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#ffffff' }}>
              Defensive Modules Configuration
            </h2>
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Toggle automated surveillance and intervention subsystems in real-time.
            </p>
          </div>
          {saveSuccess && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--success)', fontSize: '0.82rem', fontWeight: 600 }}>
              <CheckCircle2 size={16} /> Saved to Database
            </div>
          )}
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '16px'
        }}>
          {toggleList.map(item => {
            const isChecked = Boolean(config?.[item.key]);
            return (
              <div 
                key={item.key} 
                style={{
                  padding: '16px',
                  background: 'rgba(0, 0, 0, 0.25)',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid rgba(255, 255, 255, 0.04)',
                  display: 'flex',
                  alignItems: 'flex-start',
                  justifyContent: 'space-between',
                  gap: '14px'
                }}
              >
                <div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#ffffff' }}>
                    {item.title}
                  </div>
                  <div style={{ fontSize: '0.76rem', color: 'var(--text-muted)', marginTop: '4px', lineHeight: 1.4 }}>
                    {item.desc}
                  </div>
                </div>

                <label className="switch" style={{ flexShrink: 0 }}>
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={(e) => onUpdateConfig({ [item.key]: e.target.checked ? 1 : 0 })}
                  />
                  <span className="slider"></span>
                </label>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Action Thresholds Matrix */}
      <div className="glass-panel" style={{ padding: '24px' }}>
        <div style={{ marginBottom: '20px' }}>
          <h2 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Sliders size={20} color="var(--primary-light)" />
            Sliding Window Action Thresholds
          </h2>
          <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Define the exact count limit and time window before SPOOFY Shield executes automatic punitive action.
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {thresholds.map(t => (
            <div 
              key={t.action_type}
              style={{
                padding: '16px 20px',
                background: 'rgba(0, 0, 0, 0.3)',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid rgba(255, 255, 255, 0.05)',
                display: 'grid',
                gridTemplateColumns: '1.2fr 1fr 1fr 1fr auto',
                alignItems: 'center',
                gap: '20px'
              }}
            >
              {/* Action Title */}
              <div>
                <div className="mono-text" style={{ fontSize: '0.88rem', fontWeight: 700, color: '#ffffff' }}>
                  {t.action_type.toUpperCase().replace('_', ' ')}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-dim)', marginTop: '2px' }}>
                  Rate limit per actor
                </div>
              </div>

              {/* Limit Count Slider */}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '6px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Action Limit</span>
                  <span className="mono-text" style={{ color: 'var(--primary-light)', fontWeight: 700 }}>
                    {t.limit_count} actions
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={t.limit_count}
                  onChange={(e) => handleThresholdChange(t.action_type, 'limit_count', parseInt(e.target.value, 10))}
                />
              </div>

              {/* Time Window Slider */}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '6px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Sliding Window</span>
                  <span className="mono-text" style={{ color: 'var(--cyan)', fontWeight: 700 }}>
                    {t.window_seconds} sec
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="60"
                  step="5"
                  value={t.window_seconds}
                  onChange={(e) => handleThresholdChange(t.action_type, 'window_seconds', parseInt(e.target.value, 10))}
                />
              </div>

              {/* Punishment Selector */}
              <div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
                  Punishment Policy
                </div>
                <select
                  value={t.punishment}
                  onChange={(e) => handleThresholdChange(t.action_type, 'punishment', e.target.value)}
                  style={{ padding: '6px 10px', fontSize: '0.8rem' }}
                >
                  <option value="ban">🔨 Instant Ban</option>
                  <option value="kick">👢 Kick Member</option>
                  <option value="strip_roles">👑 Strip All Roles</option>
                  <option value="quarantine">☣️ Quarantine Timeout</option>
                </select>
              </div>

              {/* Save Button */}
              <div>
                <button
                  onClick={() => handleSaveThreshold(t)}
                  className="btn btn-secondary"
                  style={{ padding: '8px 12px', fontSize: '0.78rem' }}
                  title="Save threshold to database"
                >
                  <Save size={14} /> Save
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Trusted Administrators Allowlist */}
      <div className="glass-panel" style={{ padding: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <h2 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <UserCheck size={20} color="var(--primary)" />
              Trusted Administrators & Roles Allowlist
            </h2>
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Exempt trusted staff from anti-nuke rate-limits and destructive action thresholds. Owner-controlled.
            </p>
          </div>

          <button
            onClick={() => setShowAddTrusted(true)}
            className="btn btn-primary"
            style={{ fontSize: '0.82rem' }}
          >
            <Plus size={16} /> Add Trusted Entity
          </button>
        </div>

        {/* Modal: Add Trusted */}
        {showAddTrusted && (
          <form 
            onSubmit={handleAddTrustedSubmit}
            style={{
              padding: '20px',
              background: '#161326',
              border: '1px solid var(--primary)',
              borderRadius: 'var(--radius-sm)',
              marginBottom: '20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px'
            }}
          >
            <div style={{ fontWeight: 700, color: '#ffffff', fontSize: '0.9rem' }}>
              Authorize Trusted User or Role
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Target Discord ID</label>
                <input
                  type="text"
                  placeholder="e.g. 123456789012345678"
                  value={newTrustedId}
                  onChange={(e) => setNewTrustedId(e.target.value)}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Entity Type</label>
                <select value={newTrustedType} onChange={(e) => setNewTrustedType(e.target.value)}>
                  <option value="user">User</option>
                  <option value="role">Role</option>
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Tag / Name (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Co-Owner or @Admin"
                  value={newTrustedTag}
                  onChange={(e) => setNewTrustedTag(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Reason / Notes</label>
              <input
                type="text"
                placeholder="e.g. Head developer authorized for channel management"
                value={newTrustedNotes}
                onChange={(e) => setNewTrustedNotes(e.target.value)}
              />
            </div>

            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '6px' }}>
              <button type="button" onClick={() => setShowAddTrusted(false)} className="btn btn-secondary" style={{ fontSize: '0.8rem' }}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" style={{ fontSize: '0.8rem' }}>
                Authorize & Save
              </button>
            </div>
          </form>
        )}

        {/* Trusted List Table */}
        {(!trusted || trusted.length === 0) ? (
          <div style={{ padding: '24px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            ℹ️ No external administrators added. Only the Server Owner is currently exempt.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {trusted.map(t => (
              <div 
                key={t.target_id}
                style={{
                  padding: '12px 18px',
                  background: 'rgba(0, 0, 0, 0.25)',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid rgba(255, 255, 255, 0.04)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                  <span className="badge badge-active" style={{ fontSize: '0.7rem' }}>
                    {t.target_type}
                  </span>
                  <div>
                    <div style={{ fontSize: '0.88rem', fontWeight: 600, color: '#ffffff' }}>
                      {t.target_tag || t.target_id}
                    </div>
                    <div className="mono-text" style={{ fontSize: '0.72rem', color: 'var(--text-dim)', marginTop: '2px' }}>
                      ID: {t.target_id} {t.notes ? `• ${t.notes}` : ''}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onRemoveTrusted(t.target_id)}
                  className="btn btn-outline"
                  style={{ padding: '6px 12px', fontSize: '0.78rem', color: '#f87171', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                >
                  <Trash2 size={14} /> Remove
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
