import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ExternalLink, Menu, X, LayoutDashboard } from 'lucide-react';

export default function PublicNavbar({ auth }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const discordInviteUrl = "https://discord.com/api/oauth2/authorize?client_id=1513184619011375164&permissions=8&scope=bot%20applications.commands";

  const navLinks = [
    { label: 'Start Here', path: '/' },
    { label: 'Security', path: '/security' },
    { label: 'Music', path: '/music' },
    { label: 'Commands', path: '/commands' },
    { label: 'Company', path: '/company' },
    { label: 'Docs', path: '/docs' },
    { label: 'Support', path: '/support' }
  ];

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <header style={{
      position: 'sticky',
      top: 0,
      zIndex: 100,
      backgroundColor: '#ffffff',
      borderBottom: '1px solid #ebebeb',
      width: '100%'
    }}>
      <div className="container" style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: '68px'
      }}>
        {/* Brand & Geometric Logo */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
          <div style={{
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0
          }}>
            <img 
              src="/assets/spoofy_logo.png" 
              alt="SPOOFY Logo" 
              style={{ 
                width: '100%', 
                height: '100%', 
                objectFit: 'contain',
                filter: 'drop-shadow(0 1px 2px rgba(0, 0, 0, 0.45))'
              }} 
            />
          </div>
          <span style={{
            fontSize: '1.125rem',
            fontWeight: 800,
            letterSpacing: '-0.03em',
            color: '#000000'
          }}>
            SPOOFY
          </span>
        </Link>

        {/* Desktop Navigation Links */}
        <nav style={{
          display: 'none',
          alignItems: 'center',
          gap: '28px'
        }} className="desktop-nav">
          {navLinks.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              style={{
                fontSize: '0.8125rem',
                fontWeight: isActive(item.path) ? 600 : 500,
                color: isActive(item.path) ? '#000000' : '#666666',
                textDecoration: 'none',
                transition: 'color 0.15s ease'
              }}
              onMouseEnter={(e) => e.currentTarget.style.color = '#000000'}
              onMouseLeave={(e) => {
                if (!isActive(item.path)) e.currentTarget.style.color = '#666666';
              }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Desktop Action Buttons */}
        <div style={{ display: 'none', alignItems: 'center', gap: '12px' }} className="desktop-actions">
          {auth?.authenticated ? (
            <Link to="/dashboard" className="btn-editorial-outline">
              <LayoutDashboard size={12} /> Dashboard
            </Link>
          ) : (
            <Link to="/login" style={{ fontSize: '0.8125rem', fontWeight: 500, color: '#666666', marginRight: '6px' }}>
              Sign In
            </Link>
          )}

          <a
            href={discordInviteUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-editorial-black"
          >
            Add to Discord <ExternalLink size={12} />
          </a>
        </div>

        {/* Mobile Hamburger Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="mobile-toggle"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'transparent',
            border: 'none',
            color: '#000000',
            cursor: 'pointer',
            padding: '6px'
          }}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div style={{
          backgroundColor: '#ffffff',
          borderBottom: '1px solid #ebebeb',
          padding: '20px 24px 28px',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px'
        }}>
          {navLinks.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setMobileMenuOpen(false)}
              style={{
                color: isActive(item.path) ? '#000000' : '#555555',
                fontWeight: isActive(item.path) ? 700 : 500,
                fontSize: '1rem',
                padding: '6px 0',
                textDecoration: 'none'
              }}
            >
              {item.label}
            </Link>
          ))}

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '12px', borderTop: '1px solid #ebebeb', paddingTop: '16px' }}>
            {auth?.authenticated ? (
              <Link
                to="/dashboard"
                onClick={() => setMobileMenuOpen(false)}
                className="btn-editorial-outline"
                style={{ width: '100%', justifyContent: 'center' }}
              >
                <LayoutDashboard size={14} /> Open Management Dashboard
              </Link>
            ) : (
              <Link
                to="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="btn-editorial-outline"
                style={{ width: '100%', justifyContent: 'center' }}
              >
                Sign In
              </Link>
            )}

            <a
              href={discordInviteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-editorial-black"
              style={{ width: '100%', justifyContent: 'center' }}
            >
              Add to Discord <ExternalLink size={14} />
            </a>
          </div>
        </div>
      )}

      {/* Media query helper styles */}
      <style>{`
        @media (min-width: 860px) {
          .desktop-nav { display: flex !important; }
          .desktop-actions { display: flex !important; }
          .mobile-toggle { display: none !important; }
        }
      `}</style>
    </header>
  );
}
