import React from 'react';
import { Link } from 'react-router-dom';

export default function PublicFooter() {
  const currentYear = new Date().getFullYear();

  return (
    <footer style={{
      borderTop: '1px solid #ebebeb',
      backgroundColor: '#ffffff',
      padding: '64px 0 48px',
      marginTop: 'auto'
    }}>
      <div className="container">
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '48px'
        }}>
          {/* Main Content Grid: Brand Quote on Left, 4 Navigation Columns on Right */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '48px',
            alignItems: 'start'
          }}>
            {/* Left: Emblem, Brand and Quote */}
            <div style={{ maxWidth: '320px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}>
                  <img
                    src="/assets/spoofy_logo.png"
                    alt="SPOOFY"
                    style={{ 
                      width: '100%', 
                      height: '100%', 
                      objectFit: 'contain',
                      filter: 'drop-shadow(0 1px 2px rgba(0, 0, 0, 0.45))'
                    }}
                  />
                </div>
                <span style={{ fontSize: '1.05rem', fontWeight: 800, color: '#000000', letterSpacing: '-0.03em' }}>
                  SPOOFY
                </span>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <div style={{
                  fontSize: '0.625rem',
                  fontWeight: 700,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: '#000000'
                }}>
                  We Believe
                </div>
                <div style={{ fontSize: '0.8125rem', fontStyle: 'italic', color: '#555555', lineHeight: 1.6 }}>
                  “The key to building an authentic community is establishing quiet, uncompromising security.”
                </div>
                <div style={{ fontSize: '0.75rem', color: '#888888', marginTop: '2px' }}>
                  — VELORA Engineering Team
                </div>
              </div>
            </div>

            {/* 4 Navigation Columns */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(110px, 1fr))',
              gap: '32px',
              gridColumn: 'span 2'
            }}>
              <div>
                <div style={{
                  fontSize: '0.6875rem',
                  fontWeight: 700,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: '#000000',
                  marginBottom: '16px'
                }}>
                  About
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.8125rem' }}>
                  <Link to="/" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Start Here</Link>
                  <Link to="/company" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Our Platform</Link>
                  <Link to="/docs" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Technical Specs</Link>
                  <Link to="/status" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Cluster Status</Link>
                </div>
              </div>

              <div>
                <div style={{
                  fontSize: '0.6875rem',
                  fontWeight: 700,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: '#000000',
                  marginBottom: '16px'
                }}>
                  Security
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.8125rem' }}>
                  <Link to="/security" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>SPOOFY Shield</Link>
                  <Link to="/features" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>SPOOFY Sentinel</Link>
                  <Link to="/features" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>SPOOFY Recovery</Link>
                  <Link to="/music" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>SPOOFY Music</Link>
                </div>
              </div>

              <div>
                <div style={{
                  fontSize: '0.6875rem',
                  fontWeight: 700,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: '#000000',
                  marginBottom: '16px'
                }}>
                  Resources
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.8125rem' }}>
                  <Link to="/commands" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Slash Commands</Link>
                  <Link to="/docs" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Documentation</Link>
                  <Link to="/support" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Support Hub</Link>
                  <Link to="/legal/privacy" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Privacy Policy</Link>
                </div>
              </div>

              <div>
                <div style={{
                  fontSize: '0.6875rem',
                  fontWeight: 700,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: '#000000',
                  marginBottom: '16px'
                }}>
                  Connect
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.8125rem' }}>
                  <Link to="/support" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Discord Server</Link>
                  <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Twitter / X</a>
                  <a href="https://github.com" target="_blank" rel="noopener noreferrer" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>GitHub</a>
                  <Link to="/legal/terms" style={{ color: '#555555' }} onMouseEnter={(e) => e.currentTarget.style.color = '#000000'} onMouseLeave={(e) => e.currentTarget.style.color = '#555555'}>Terms of Service</Link>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Hairline & Fine Print */}
          <div style={{
            borderTop: '1px solid #ebebeb',
            paddingTop: '24px',
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '12px',
            fontSize: '0.75rem',
            color: '#888888'
          }}>
            <div>
              © {currentYear} VELORA Technologies Inc. All rights reserved.
            </div>
            <div>
              SPOOFY is engineered by VELORA. Designed with restraint and precision.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
