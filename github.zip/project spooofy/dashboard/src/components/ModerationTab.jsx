import React, { useState } from 'react';
import { 
  Users, 
  Gavel, 
  Clock, 
  CheckCircle2, 
  Search, 
  ShieldAlert, 
  UserX,
  AlertTriangle
} from 'lucide-react';

export default function ModerationTab({ 
  moderationCases = [], 
  onIssueWarning 
}) {
  const [warnUserId, setWarnUserId] = useState('');
  const [warnUserTag, setWarnUserTag] = useState('');
  const [warnReason, setWarnReason] = useState('');
  const [actionType, setActionType] = useState('WARN');
  const [searchQuery, setSearchQuery] = useState('');
  const [feedback, setFeedback] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!warnUserId.trim()) return;

    await onIssueWarning({
      user_id: warnUserId.trim(),
      user_tag: warnUserTag.trim() || `User_${warnUserId.trim().slice(-4)}`,
      reason: warnReason.trim() || 'Moderation infraction',
      action_type: actionType
    });

    setWarnUserId('');
    setWarnUserTag('');
    setWarnReason('');
    setFeedback(`Moderation action recorded for ${warnUserTag || warnUserId}`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const filteredCases = (moderationCases || []).filter(c => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      (c.user_tag && c.user_tag.toLowerCase().includes(q)) ||
      (c.user_id && c.user_id.includes(q)) ||
      (c.reason && c.reason.toLowerCase().includes(q)) ||
      (c.case_type && c.case_type.toLowerCase().includes(q))
    );
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Users size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Member Safety & Moderation
            </h2>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Record warnings, issue timeouts or bans, and review past moderation cases.
          </p>
        </div>

        {feedback && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#10b981', fontSize: '0.8125rem', fontWeight: 600 }}>
            <CheckCircle2 size={15} /> {feedback}
          </div>
        )}
      </div>

      {/* 2. Issue Action Form & Escalation Policy */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '16px' }}>
        {/* Form */}
        <form onSubmit={handleSubmit} style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '18px',
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
          <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Gavel size={16} color="var(--primary)" />
            Issue Moderation Action
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                Member Snowflake ID *
              </label>
              <input
                type="text"
                placeholder="e.g. 293847192837482910"
                value={warnUserId}
                onChange={(e) => setWarnUserId(e.target.value)}
                required
              />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                Member Username Tag
              </label>
              <input
                type="text"
                placeholder="Username#0000"
                value={warnUserTag}
                onChange={(e) => setWarnUserTag(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                Action Type
              </label>
              <select value={actionType} onChange={(e) => setActionType(e.target.value)}>
                <option value="WARN">Formal Warning</option>
                <option value="TIMEOUT_15M">15m Mute Timeout</option>
                <option value="TIMEOUT_1H">1h Quarantine</option>
                <option value="KICK">Kick from Server</option>
                <option value="BAN">Permanent Ban</option>
              </select>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                Infraction Reason *
              </label>
              <input
                type="text"
                placeholder="Reason for punishment"
                value={warnReason}
                onChange={(e) => setWarnReason(e.target.value)}
                required
              />
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '6px' }}>
            <button type="submit" className="btn btn-primary btn-sm">
              Execute Moderation Action
            </button>
          </div>
        </form>

        {/* Escalation Policy Guide */}
        <div style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '18px',
          display: 'flex',
          flexDirection: 'column',
          gap: '10px'
        }}>
          <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Clock size={16} color="var(--text-tertiary)" />
            Automated Escalation Ladders
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '0.75rem' }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '8px 10px',
              backgroundColor: 'var(--bg-base)',
              border: '1px solid var(--border-neutral)',
              borderRadius: '4px'
            }}>
              <div>
                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>1st - 2nd Strike</span>
                <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>Direct notice & database log</div>
              </div>
              <span className="badge">Warning</span>
            </div>

            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '8px 10px',
              backgroundColor: 'var(--bg-base)',
              border: '1px solid var(--border-neutral)',
              borderRadius: '4px'
            }}>
              <div>
                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>3rd Strike</span>
                <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>Automated 15m timeout</div>
              </div>
              <span className="badge badge-warning">15m Mute</span>
            </div>

            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '8px 10px',
              backgroundColor: 'var(--bg-base)',
              border: '1px solid var(--border-neutral)',
              borderRadius: '4px'
            }}>
              <div>
                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>5+ Strikes</span>
                <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>Permanent guild ban</div>
              </div>
              <span className="badge badge-critical">Permanent Ban</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Moderation Case Records Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '12px'
        }}>
          <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Case Records History ({filteredCases.length})
          </span>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '4px',
            padding: '4px 8px',
            width: '220px'
          }}>
            <Search size={13} color="var(--text-tertiary)" />
            <input
              type="text"
              placeholder="Filter by member, reason..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                background: 'transparent',
                border: 'none',
                padding: 0,
                fontSize: '0.75rem',
                outline: 'none',
                color: 'var(--text-primary)',
                width: '100%'
              }}
            />
          </div>
        </div>

        {filteredCases.length === 0 ? (
          <div style={{ padding: '32px 18px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
            No moderation cases found matching the criteria.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th style={{ width: '100px' }}>Action</th>
                <th style={{ width: '200px' }}>Target Member</th>
                <th>Reason</th>
                <th style={{ width: '180px' }}>Moderator</th>
                <th style={{ width: '140px', textAlign: 'right' }}>Logged Time</th>
              </tr>
            </thead>
            <tbody>
              {filteredCases.slice(0, 15).map((c) => (
                <tr key={c.id}>
                  <td>
                    <span className={`badge ${
                      c.case_type === 'BAN' ? 'badge-critical' :
                      c.case_type === 'KICK' || c.case_type === 'TIMEOUT' ? 'badge-warning' : 'badge-primary'
                    }`} style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                      {c.case_type || 'WARN'}
                    </span>
                  </td>
                  <td>
                    <div style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                      {c.user_tag || c.user_id}
                    </div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>
                      ID: {c.user_id}
                    </div>
                  </td>
                  <td style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
                    {c.reason || 'None specified'}
                  </td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    {c.moderator_tag || c.moderator_id || 'System'}
                  </td>
                  <td style={{ textAlign: 'right', fontSize: '0.75rem', color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>
                    {new Date(c.created_at * 1000).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
