import React, { useState } from 'react';
import { 
  Database, 
  RotateCcw, 
  Trash2, 
  Plus, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  X,
  Layers, 
  Settings,
  FolderTree,
  FileCheck
} from 'lucide-react';

export default function RecoveryTab({ 
  backups = [], 
  onCreateBackup, 
  onRestoreBackup, 
  onDeleteBackup 
}) {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [snapshotName, setSnapshotName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [restoreTarget, setRestoreTarget] = useState(null);
  const [restoreOptions, setRestoreOptions] = useState({ channels: true, roles: true, settings: true });
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreFeedback, setRestoreFeedback] = useState(null);
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState(null);

  const handleCreate = async (e) => {
    e.preventDefault();
    setIsCreating(true);
    try {
      await onCreateBackup(snapshotName.trim() || `Snapshot_${Date.now()}`);
      setSnapshotName('');
      setShowCreateModal(false);
    } finally {
      setIsCreating(false);
    }
  };

  const handleExecuteRestore = async () => {
    if (!restoreTarget) return;
    setIsRestoring(true);
    try {
      const results = await onRestoreBackup(restoreTarget.id, restoreOptions);
      setRestoreFeedback(results);
      setRestoreTarget(null);
    } catch (err) {
      alert(`Restoration failed: ${err.message}`);
    } finally {
      setIsRestoring(false);
    }
  };

  const confirmDelete = async () => {
    if (deleteConfirmTarget) {
      await onDeleteBackup(deleteConfirmTarget.id);
      setDeleteConfirmTarget(null);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Database size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Server Backups & Recovery Snapshots
            </h2>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Point-in-time state snapshots including channel layouts, roles, permissions, and server configurations.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="btn btn-primary btn-sm"
        >
          <Plus size={14} /> Create Snapshot
        </button>
      </div>

      {/* Restore Feedback Banner */}
      {restoreFeedback && (
        <div style={{
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          border: '1px solid rgba(16, 185, 129, 0.3)',
          borderRadius: '5px',
          padding: '12px 16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          fontSize: '0.8125rem',
          color: '#10b981'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <CheckCircle2 size={16} />
            <span>
              Restoration successful. Applied {restoreFeedback.channelsRestored ?? 0} channels, {restoreFeedback.rolesRestored ?? 0} roles.
            </span>
          </div>
          <button
            onClick={() => setRestoreFeedback(null)}
            style={{ background: 'none', border: 'none', color: '#10b981', cursor: 'pointer' }}
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* 2. Snapshots Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Available Snapshots ({backups.length})
          </span>
          <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
            Stored securely in local database
          </span>
        </div>

        {backups.length === 0 ? (
          <div style={{ padding: '36px 18px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
            No backup snapshots created for this server yet. Click "Create Snapshot" above to establish a baseline.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Snapshot Name</th>
                <th style={{ width: '130px' }}>Created Date</th>
                <th style={{ width: '140px' }}>Channels & Roles</th>
                <th style={{ width: '110px' }}>Created By</th>
                <th style={{ width: '160px', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {backups.map((b) => (
                <tr key={b.id}>
                  <td>
                    <div style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                      {b.name}
                    </div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>
                      ID: {b.id}
                    </div>
                  </td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    {new Date(b.created_at * 1000).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                      {b.channel_count ?? '—'} channels • {b.role_count ?? '—'} roles
                    </span>
                  </td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                    {b.creator_tag || 'System Admin'}
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '6px' }}>
                      <button
                        onClick={() => setRestoreTarget(b)}
                        className="btn btn-secondary btn-sm"
                        style={{ fontSize: '0.75rem', padding: '3px 8px' }}
                      >
                        <RotateCcw size={12} /> Restore
                      </button>
                      <button
                        onClick={() => setDeleteConfirmTarget(b)}
                        className="btn btn-ghost btn-sm"
                        style={{ color: '#f87171', padding: '3px 6px' }}
                        title="Delete snapshot"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal: Create Backup Snapshot */}
      {showCreateModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 999
        }}>
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '6px',
            padding: '24px',
            maxWidth: '440px',
            width: '90%'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Capture New Server Snapshot
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                style={{ background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer' }}
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreate} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                  Snapshot Label
                </label>
                <input
                  type="text"
                  placeholder="e.g. Pre-Event Configuration Baseline"
                  value={snapshotName}
                  onChange={(e) => setSnapshotName(e.target.value)}
                  required
                />
              </div>

              <p style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)', lineHeight: 1.4 }}>
                Captures full category tree, text/voice channel permissions, role hierarchy, and server configuration.
              </p>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '6px' }}>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn btn-secondary btn-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isCreating}
                  className="btn btn-primary btn-sm"
                >
                  {isCreating ? 'Capturing...' : 'Capture Snapshot'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Restore Snapshot Confirmation Dialog */}
      {restoreTarget && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 999
        }}>
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '6px',
            padding: '24px',
            maxWidth: '460px',
            width: '90%'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <RotateCcw size={18} color="var(--primary)" />
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Confirm Snapshot Restoration
              </h3>
            </div>

            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '14px' }}>
              You are restoring <strong>{restoreTarget.name}</strong>. Choose the components you wish to synchronize:
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '18px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8125rem', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={restoreOptions.channels}
                  onChange={(e) => setRestoreOptions(o => ({ ...o, channels: e.target.checked }))}
                />
                <span>Restore Channels & Overwrite Permissions</span>
              </label>

              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8125rem', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={restoreOptions.roles}
                  onChange={(e) => setRestoreOptions(o => ({ ...o, roles: e.target.checked }))}
                />
                <span>Restore Server Roles & Color Palette</span>
              </label>

              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8125rem', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={restoreOptions.settings}
                  onChange={(e) => setRestoreOptions(o => ({ ...o, settings: e.target.checked }))}
                />
                <span>Restore Server Verification & Vanity Settings</span>
              </label>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button
                onClick={() => setRestoreTarget(null)}
                className="btn btn-secondary btn-sm"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteRestore}
                disabled={isRestoring}
                className="btn btn-primary btn-sm"
              >
                {isRestoring ? 'Restoring...' : 'Execute Rollback'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Dialog: Delete Snapshot */}
      {deleteConfirmTarget && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 999
        }}>
          <div style={{
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            borderRadius: '6px',
            padding: '24px',
            maxWidth: '400px',
            width: '90%'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#ef4444', marginBottom: '12px' }}>
              <AlertTriangle size={18} />
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Delete Snapshot?
              </h3>
            </div>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              Are you sure you want to permanently delete <strong>{deleteConfirmTarget.name}</strong>? This snapshot cannot be recovered.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '18px' }}>
              <button
                onClick={() => setDeleteConfirmTarget(null)}
                className="btn btn-secondary btn-sm"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="btn btn-danger btn-sm"
              >
                Delete Snapshot
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
