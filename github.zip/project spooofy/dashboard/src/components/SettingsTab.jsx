import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  Save, 
  CheckCircle2, 
  FileText, 
  UserPlus, 
  Bell, 
  Hash, 
  HelpCircle,
  ShieldCheck
} from 'lucide-react';
import { 
  fetchWelcomeConfig, 
  updateWelcomeConfig, 
  fetchLoggingConfig, 
  updateLoggingConfig 
} from '../api';

export default function SettingsTab({ guildId, config, onUpdateConfig }) {
  const [welcomeCfg, setWelcomeCfg] = useState(null);
  const [loggingCfg, setLoggingCfg] = useState(null);
  const [feedback, setFeedback] = useState(null);

  useEffect(() => {
    Promise.all([
      fetchWelcomeConfig(guildId).catch(() => null),
      fetchLoggingConfig(guildId).catch(() => null)
    ]).then(([w, l]) => {
      setWelcomeCfg(w || {});
      setLoggingCfg(l || {});
    });
  }, [guildId]);

  const handleSaveWelcome = async (e) => {
    e.preventDefault();
    if (welcomeCfg) {
      await updateWelcomeConfig(guildId, welcomeCfg);
      setFeedback('Welcome settings saved.');
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  const handleSaveLogging = async (e) => {
    e.preventDefault();
    if (loggingCfg) {
      await updateLoggingConfig(guildId, loggingCfg);
      setFeedback('Audit log channels saved.');
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Settings size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Server & Bot Settings
            </h2>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Configure audit logging dispatch channels, automated welcome greetings, and server integration options.
          </p>
        </div>

        {feedback && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#10b981', fontSize: '0.8125rem', fontWeight: 600 }}>
            <CheckCircle2 size={15} /> {feedback}
          </div>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
        {/* 2. Logging Channels Setup */}
        <form onSubmit={handleSaveLogging} style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '20px',
          display: 'flex',
          flexDirection: 'column',
          gap: '14px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <FileText size={16} color="var(--primary)" />
              Audit & Security Logging Channels
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Security Alert Channel Snowflake ID
            </label>
            <input
              type="text"
              placeholder="e.g. 102938475610293847"
              value={loggingCfg?.security_channel_id || ''}
              onChange={(e) => setLoggingCfg(c => ({ ...c, security_channel_id: e.target.value }))}
            />
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '4px' }}>
              High and critical anti-nuke interceptions will be dispatched here immediately.
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Moderation Log Channel Snowflake ID
            </label>
            <input
              type="text"
              placeholder="e.g. 102938475610293848"
              value={loggingCfg?.mod_channel_id || ''}
              onChange={(e) => setLoggingCfg(c => ({ ...c, mod_channel_id: e.target.value }))}
            />
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '4px' }}>
              Logs warnings, kicks, bans, and timeouts.
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Server Changes Log Channel Snowflake ID
            </label>
            <input
              type="text"
              placeholder="e.g. 102938475610293849"
              value={loggingCfg?.server_channel_id || ''}
              onChange={(e) => setLoggingCfg(c => ({ ...c, server_channel_id: e.target.value }))}
            />
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '4px' }}>
              Tracks channel creations, role modifications, and server setting alterations.
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'auto', paddingTop: '8px' }}>
            <button type="submit" className="btn btn-primary btn-sm">
              <Save size={13} /> Save Logging Channels
            </button>
          </div>
        </form>

        {/* 3. Welcome & Departure Setup */}
        <form onSubmit={handleSaveWelcome} style={{
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '20px',
          display: 'flex',
          flexDirection: 'column',
          gap: '14px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <UserPlus size={16} color="var(--primary)" />
              Welcome & Departure Greetings
            </div>

            <label className="switch">
              <input
                type="checkbox"
                checked={Boolean(welcomeCfg?.welcome_enabled)}
                onChange={(e) => setWelcomeCfg(c => ({ ...c, welcome_enabled: e.target.checked ? 1 : 0 }))}
              />
              <span className="slider" />
            </label>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Welcome Channel Snowflake ID
            </label>
            <input
              type="text"
              placeholder="e.g. 102938475610293847"
              value={welcomeCfg?.welcome_channel_id || ''}
              onChange={(e) => setWelcomeCfg(c => ({ ...c, welcome_channel_id: e.target.value }))}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Welcome Message Template
            </label>
            <textarea
              rows={3}
              placeholder="Welcome {user} to {server}! You are member #{count}."
              value={welcomeCfg?.welcome_message || ''}
              onChange={(e) => setWelcomeCfg(c => ({ ...c, welcome_message: e.target.value }))}
            />
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '4px' }}>
              Supported variables: <code>&#123;user&#125;</code>, <code>&#123;server&#125;</code>, <code>&#123;count&#125;</code>
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Auto-Role Snowflake ID
            </label>
            <input
              type="text"
              placeholder="e.g. 102938475610293848"
              value={welcomeCfg?.auto_role_id || ''}
              onChange={(e) => setWelcomeCfg(c => ({ ...c, auto_role_id: e.target.value }))}
            />
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', marginTop: '4px' }}>
              Automatically assigned to new joining members after passing anti-raid verification.
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'auto', paddingTop: '8px' }}>
            <button type="submit" className="btn btn-primary btn-sm">
              <Save size={13} /> Save Welcome Settings
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
