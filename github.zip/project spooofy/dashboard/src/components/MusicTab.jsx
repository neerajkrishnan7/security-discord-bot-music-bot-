import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  SkipForward, 
  Square, 
  Volume2, 
  Repeat, 
  Music,
  Radio,
  ListMusic
} from 'lucide-react';
import { fetchMusicSession, actionMusicSession } from '../api';

export default function MusicTab({ guildId }) {
  const [session, setSession] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [volume, setVolume] = useState(80);

  useEffect(() => {
    loadMusic();
    const interval = setInterval(loadMusic, 6000);
    return () => clearInterval(interval);
  }, [guildId]);

  const loadMusic = async () => {
    try {
      const data = await fetchMusicSession(guildId);
      setSession(data);
      if (data?.volume) setVolume(data.volume);
    } catch (e) {}
  };

  const handleAction = async (action, payload = null) => {
    setIsLoading(true);
    try {
      const updated = await actionMusicSession(guildId, action, payload);
      setSession(updated);
    } finally {
      setIsLoading(false);
    }
  };

  const isPlaying = Boolean(session?.is_playing && !session?.is_paused);
  const queue = session?.queue || [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header & Now Playing Controller */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Music size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Lossless Audio Engine & 24/7 Streaming
            </h2>
          </div>
          <span className={`badge ${session?.is_playing ? 'badge-success' : 'badge-low'}`} style={{ fontSize: '0.6875rem' }}>
            {session?.is_playing ? (session?.is_paused ? 'PAUSED' : 'STREAMING') : 'STANDBY'}
          </span>
        </div>

        {/* Current Track Playback Bar */}
        <div style={{
          backgroundColor: 'var(--bg-base)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '4px',
          padding: '16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '16px'
        }}>
          <div>
            <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Current Audio Stream
            </div>
            <div style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '2px' }}>
              {session?.current_track_title || 'No active voice connection'}
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
              {session?.current_track_author ? `Artist: ${session.current_track_author}` : 'Connect to a voice channel and use /music play <query> in Discord'}
            </div>
          </div>

          {/* Controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            {isPlaying ? (
              <button
                onClick={() => handleAction('pause')}
                disabled={isLoading}
                className="btn btn-secondary btn-sm"
                title="Pause"
              >
                <Pause size={14} /> Pause
              </button>
            ) : (
              <button
                onClick={() => handleAction('resume')}
                disabled={isLoading}
                className="btn btn-primary btn-sm"
                title="Resume"
              >
                <Play size={14} /> Resume
              </button>
            )}

            <button
              onClick={() => handleAction('skip')}
              disabled={isLoading}
              className="btn btn-secondary btn-sm"
              title="Skip"
            >
              <SkipForward size={14} /> Skip
            </button>

            <button
              onClick={() => handleAction('stop')}
              disabled={isLoading}
              className="btn btn-secondary btn-sm"
              style={{ color: '#f87171' }}
              title="Stop and disconnect"
            >
              <Square size={14} /> Stop
            </button>
          </div>
        </div>

        {/* Secondary Options: Volume & 24/7 Channel */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px', paddingTop: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Volume2 size={15} color="var(--text-secondary)" />
            <input
              type="range"
              min="0"
              max="150"
              value={volume}
              onChange={(e) => {
                setVolume(e.target.value);
                handleAction('volume', { volume: parseInt(e.target.value, 10) });
              }}
              style={{ width: '120px', accentColor: 'var(--primary)' }}
            />
            <span style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>
              {volume}%
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8125rem', cursor: 'pointer' }}>
              <span style={{ color: 'var(--text-secondary)' }}>24/7 Persistent Stay in Voice Channel</span>
              <label className="switch">
                <input
                  type="checkbox"
                  checked={Boolean(session?.stay_247)}
                  onChange={(e) => handleAction('stay247', { enabled: e.target.checked })}
                />
                <span className="slider" />
              </label>
            </label>
          </div>
        </div>
      </div>

      {/* 2. Track Queue Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Playback Queue ({queue.length})
          </span>
          <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
            Lossless opus streams buffered at 48kHz / 256kbps
          </span>
        </div>

        {queue.length === 0 ? (
          <div style={{ padding: '32px 18px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
            The playback queue is currently empty. Request tracks via <code>/music play</code> in Discord.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th style={{ width: '60px' }}>#</th>
                <th>Track Title</th>
                <th>Artist / Source</th>
                <th style={{ width: '130px' }}>Requested By</th>
                <th style={{ width: '90px', textAlign: 'right' }}>Duration</th>
              </tr>
            </thead>
            <tbody>
              {queue.map((track, idx) => (
                <tr key={idx}>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                    {idx + 1}
                  </td>
                  <td>
                    <span style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                      {track.title}
                    </span>
                  </td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    {track.author || 'Web Stream'}
                  </td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                    {track.requester || 'User'}
                  </td>
                  <td style={{ textAlign: 'right', fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>
                    {track.duration || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
