import React, { useState, useEffect } from 'react';
import { Ticket, Lock, MessageSquare, Clock, User, CheckCircle2, ChevronRight } from 'lucide-react';
import { fetchGuildTickets, closeGuildTicket } from '../api';

export default function TicketsTab({ guildId }) {
  const [tickets, setTickets] = useState([]);
  const [filter, setFilter] = useState('ALL');

  useEffect(() => {
    loadTickets();
  }, [guildId]);

  const loadTickets = async () => {
    try {
      const list = await fetchGuildTickets(guildId);
      setTickets(list);
    } catch (e) {}
  };

  const handleClose = async (ticketId) => {
    await closeGuildTicket(guildId, ticketId, 'Closed via Guild Dashboard');
    await loadTickets();
  };

  const filtered = tickets.filter(t => {
    if (filter === 'OPEN') return t.status === 'OPEN';
    if (filter === 'CLOSED') return t.status === 'CLOSED';
    return true;
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Ticket size={18} color="var(--primary)" />
            <h2 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              Support Tickets Queue
            </h2>
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Member inquiries, private support channels, and resolution history.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          {['ALL', 'OPEN', 'CLOSED'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="btn btn-secondary btn-sm"
              style={{
                backgroundColor: filter === f ? 'var(--bg-base)' : undefined,
                borderColor: filter === f ? 'var(--primary)' : undefined,
                color: filter === f ? 'var(--text-primary)' : undefined
              }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Tickets Table */}
      <div style={{
        backgroundColor: 'var(--bg-panel)',
        border: '1px solid var(--border-neutral)',
        borderRadius: '5px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '12px 18px',
          borderBottom: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Ticket Inquiries ({filtered.length})
          </span>
          <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
            Use /ticket setup in Discord to deploy panels
          </span>
        </div>

        {filtered.length === 0 ? (
          <div style={{ padding: '36px 18px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8125rem' }}>
            No tickets found in this category.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th style={{ width: '90px' }}>Status</th>
                <th style={{ width: '180px' }}>Category</th>
                <th>Member / Creator</th>
                <th>Discord Channel</th>
                <th style={{ width: '130px' }}>Created Date</th>
                <th style={{ width: '110px', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(t => {
                const isOpen = t.status === 'OPEN';
                return (
                  <tr key={t.id}>
                    <td>
                      <span className={`badge ${isOpen ? 'badge-success' : 'badge-low'}`} style={{ fontSize: '0.6875rem', padding: '1px 6px' }}>
                        {t.status}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontWeight: 600, fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                        {t.category || 'General Support'}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontSize: '0.8125rem', color: 'var(--text-primary)' }}>
                        {t.creator_tag || t.creator_id}
                      </div>
                      <div style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>
                        ID: {t.creator_id}
                      </div>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                        #{t.channel_id}
                      </span>
                    </td>
                    <td style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                      {new Date(t.created_at * 1000).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      {isOpen && (
                        <button
                          onClick={() => handleClose(t.id)}
                          className="btn btn-secondary btn-sm"
                          style={{ fontSize: '0.75rem', padding: '3px 8px' }}
                        >
                          <Lock size={12} /> Close
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
