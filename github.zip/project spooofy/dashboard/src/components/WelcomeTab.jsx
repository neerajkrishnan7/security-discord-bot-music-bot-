import React, { useState, useEffect } from 'react';
import { UserPlus, Save, CheckCircle2, Eye, MessageSquare, Send } from 'lucide-react';
import { fetchWelcomeConfig, updateWelcomeConfig } from '../api';

export default function WelcomeTab({ guildId }) {
  const [cfg, setCfg] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    fetchWelcomeConfig(guildId).then(setCfg).catch(() => {});
  }, [guildId]);

  const handleSave = async (e) => {
    e.preventDefault();
    await updateWelcomeConfig(guildId, cfg);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  if (!cfg) return null;

  const previewMessage = (cfg.welcome_message || 'Welcome {user} to {server}!')
    .replace('{user}', '@CyberMember')
    .replace('{server}', 'SPOOFY Operations HQ')
    .replace('{count}', '1,420');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <form onSubmit={handleSave} className="glass-panel" style={{ padding: '28px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <h2 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <UserPlus size={20} color="var(--primary-light)" />
              Welcome & Departure Configuration
            </h2>
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Customize member greeting messages, channel notifications, and departure announcements.
            </p>
          </div>

          <button type="submit" className="btn btn-primary" style={{ fontSize: '0.82rem' }}>
            <Save size={16} /> Save Configuration
          </button>
        </div>

        {saveSuccess && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--success)', fontSize: '0.82rem', fontWeight: 600, marginBottom: '16px' }}>
            <CheckCircle2 size={16} /> Welcome settings saved to database
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '24px' }}>
          {/* Settings Column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
            {/* Welcome Enabled */}
            <div style={{ background: 'rgba(0, 0, 0, 0.25)', padding: '16px', borderRadius: 'var(--radius-sm)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#ffffff' }}>Enable Welcome Messages</div>
                <div style={{ fontSize: '0.74rem', color: 'var(--text-dim)' }}>Send message when a member joins</div>
              </div>
              <label className="switch">
                <input
                  type="checkbox"
                  checked={Boolean(cfg.welcome_enabled)}
                  onChange={(e) => setCfg({ ...cfg, welcome_enabled: e.target.checked ? 1 : 0 })}
                />
                <span className="slider"></span>
              </label>
            </div>

            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Welcome Channel ID</label>
              <input
                type="text"
                placeholder="e.g. 102938475610293847"
                value={cfg.welcome_channel_id || ''}
                onChange={(e) => setCfg({ ...cfg, welcome_channel_id: e.target.value })}
              />
            </div>

            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Welcome Message Template (Variables: <code>{'{user}'}</code>, <code>{'{server}'}</code>, <code>{'{count}'}</code>)
              </label>
              <textarea
                rows={3}
                value={cfg.welcome_message || ''}
                onChange={(e) => setCfg({ ...cfg, welcome_message: e.target.value })}
              />
            </div>

            {/* Direct Message Welcome */}
            <div style={{ background: 'rgba(0, 0, 0, 0.25)', padding: '16px', borderRadius: 'var(--radius-sm)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#ffffff' }}>Direct Message (DM) Welcome</div>
                <div style={{ fontSize: '0.74rem', color: 'var(--text-dim)' }}>Send welcome greeting directly to user's DMs</div>
              </div>
              <label className="switch">
                <input
                  type="checkbox"
                  checked={Boolean(cfg.dm_welcome_enabled)}
                  onChange={(e) => setCfg({ ...cfg, dm_welcome_enabled: e.target.checked ? 1 : 0 })}
                />
                <span className="slider"></span>
              </label>
            </div>

            {/* Goodbye Enabled */}
            <div style={{ background: 'rgba(0, 0, 0, 0.25)', padding: '16px', borderRadius: 'var(--radius-sm)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#ffffff' }}>Enable Departure Messages</div>
                <div style={{ fontSize: '0.74rem', color: 'var(--text-dim)' }}>Send notification when a member leaves</div>
              </div>
              <label className="switch">
                <input
                  type="checkbox"
                  checked={Boolean(cfg.goodbye_enabled)}
                  onChange={(e) => setCfg({ ...cfg, goodbye_enabled: e.target.checked ? 1 : 0 })}
                />
                <span className="slider"></span>
              </label>
            </div>
          </div>

          {/* Live Preview Card */}
          <div>
            <div style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Eye size={15} /> Real-Time Discord Message Preview
            </div>

            <div style={{
              background: '#1e1c2e',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              borderRadius: 'var(--radius-sm)',
              padding: '20px',
              borderLeft: '4px solid var(--primary)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                <div style={{ width: '28px', height: '28px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <img src="/assets/spoofy_logo.png" alt="SPOOFY" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                </div>
                <div>
                  <span style={{ fontWeight: 700, color: '#ffffff', fontSize: '0.85rem' }}>SPOOFY</span>
                  <span className="badge badge-active" style={{ fontSize: '0.58rem', marginLeft: '6px' }}>BOT</span>
                </div>
              </div>

              <div style={{ fontSize: '0.88rem', color: '#e2e8f0', lineHeight: 1.5 }}>
                {previewMessage}
              </div>

              <div style={{ fontSize: '0.7rem', color: 'var(--text-dim)', marginTop: '12px' }}>
                Protected by SPOOFY Shield • Today at {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
