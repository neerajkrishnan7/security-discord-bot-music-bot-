import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Server, 
  Lock, 
  Unlock, 
  Search, 
  Bell, 
  ShieldCheck, 
  ChevronRight, 
  Command,
  Radio,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';

const TAB_TITLES = {
  overview: 'Overview',
  security: 'Security Posture',
  antinuke: 'Anti-Nuke Defense',
  automod: 'Auto Moderation',
  members: 'Member Safety',
  audit: 'Audit Logs',
  backups: 'Backups & Snapshots',
  tickets: 'Support Tickets',
  music: 'Lossless Audio',
  settings: 'Server Settings'
};

export default function Header({ 
  health, 
  currentGuild, 
  activeTab = 'overview', 
  alertStats, 
  config, 
  onToggleLockdown, 
  auth 
}) {
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const isReady = health?.gateway?.isReady;
  const ping = health?.gateway?.pingMs ?? -1;
  const isLockdown = Boolean(config?.lockdown_active);
  const user = auth?.user || { username: 'Admin' };
  const tabLabel = TAB_TITLES[activeTab] || 'Workspace';

  return (
    <header style={{
      height: '56px',
      backgroundColor: 'var(--bg-base)',
      borderBottom: '1px solid var(--border-neutral)',
      padding: '0 20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 50,
      width: '100%'
    }}>
      {/* 1. Left: Breadcrumb Navigation */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8125rem' }}>
        <Link 
          to="/dashboard" 
          style={{ 
            color: 'var(--text-tertiary)', 
            textDecoration: 'none',
            display: 'flex',
            alignItems: 'center',
            gap: '5px',
            transition: 'color 0.15s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.color = 'var(--text-primary)'}
          onMouseLeave={(e) => e.currentTarget.style.color = 'var(--text-tertiary)'}
        >
          <Server size={13} />
          <span>Servers</span>
        </Link>

        <ChevronRight size={12} color="var(--text-tertiary)" />

        <span style={{ 
          color: 'var(--text-secondary)', 
          fontWeight: 500,
          maxWidth: '180px',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis'
        }}>
          {currentGuild?.name || 'Current Server'}
        </span>

        <ChevronRight size={12} color="var(--text-tertiary)" />

        <span style={{ 
          color: 'var(--text-primary)', 
          fontWeight: 600,
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          padding: '2px 8px',
          borderRadius: '4px',
          fontSize: '0.75rem'
        }}>
          {tabLabel}
        </span>
      </div>

      {/* 2. Center: Quick Search Command Navigation */}
      <div style={{ flex: 1, maxWidth: '340px', margin: '0 24px' }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          borderRadius: '5px',
          padding: '5px 10px',
          color: 'var(--text-tertiary)',
          fontSize: '0.75rem',
          cursor: 'pointer'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Search size={13} />
            <span>Search settings, members, audit...</span>
          </div>
          <kbd style={{
            fontSize: '0.625rem',
            backgroundColor: 'var(--bg-base)',
            border: '1px solid var(--border-neutral)',
            padding: '1px 5px',
            borderRadius: '3px',
            color: 'var(--text-tertiary)'
          }}>
            ⌘K
          </kbd>
        </div>
      </div>

      {/* 3. Right: Bot Telemetry Status, Notifications & Panic Controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        {/* Gateway Connection Indicator */}
        <div 
          title={isReady ? `Bot Gateway Connected (${ping}ms)` : 'Bot in Simulator/Local Mode'}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '4px 8px',
            borderRadius: '4px',
            backgroundColor: 'var(--bg-panel)',
            border: '1px solid var(--border-neutral)',
            fontSize: '0.75rem'
          }}
        >
          <div style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            backgroundColor: isReady ? '#10b981' : '#f59e0b'
          }} />
          <span style={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', fontSize: '0.6875rem' }}>
            {isReady ? `${ping}ms` : 'Operational'}
          </span>
        </div>

        {/* Notifications Icon with Incident Badge */}
        <div style={{ position: 'relative' }}>
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            title="Recent Security Notifications"
            style={{
              width: '30px',
              height: '30px',
              borderRadius: '4px',
              backgroundColor: 'var(--bg-panel)',
              border: '1px solid var(--border-neutral)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: alertStats?.active > 0 ? '#f87171' : 'var(--text-secondary)',
              cursor: 'pointer'
            }}
          >
            <Bell size={14} />
          </button>

          {alertStats?.active > 0 && (
            <span style={{
              position: 'absolute',
              top: '-3px',
              right: '-3px',
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: '#ef4444',
              border: '2px solid var(--bg-base)'
            }} />
          )}

          {showNotifications && (
            <div style={{
              position: 'absolute',
              top: '38px',
              right: 0,
              width: '280px',
              backgroundColor: 'var(--bg-panel)',
              border: '1px solid var(--border-neutral)',
              borderRadius: '6px',
              padding: '12px',
              boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
              zIndex: 100
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-primary)' }}>
                  Active Security Alerts
                </span>
                <span style={{ fontSize: '0.6875rem', color: 'var(--text-tertiary)' }}>
                  {alertStats?.active || 0} pending
                </span>
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                {alertStats?.active > 0 ? (
                  `${alertStats.active} incidents require review in the Audit Logs.`
                ) : (
                  'No unhandled security incidents. Perimeter is nominal.'
                )}
              </div>
            </div>
          )}
        </div>

        {/* Panic / Lockdown Action */}
        <button
          onClick={onToggleLockdown}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '5px 12px',
            borderRadius: '4px',
            fontSize: '0.75rem',
            fontWeight: 600,
            cursor: 'pointer',
            border: isLockdown ? '1px solid #ef4444' : '1px solid var(--border-neutral)',
            backgroundColor: isLockdown ? 'rgba(239, 68, 68, 0.15)' : 'var(--bg-panel)',
            color: isLockdown ? '#f87171' : 'var(--text-primary)',
            transition: 'all 0.15s ease'
          }}
          title={isLockdown ? 'Lift active server lockdown' : 'Activate immediate server lockdown'}
        >
          {isLockdown ? <Unlock size={13} /> : <Lock size={13} />}
          <span>{isLockdown ? 'LIFT LOCKDOWN' : 'LOCKDOWN'}</span>
        </button>

        {/* User Avatar Mini */}
        <div style={{
          width: '28px',
          height: '28px',
          borderRadius: '50%',
          backgroundColor: 'var(--bg-panel)',
          border: '1px solid var(--border-neutral)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '0.75rem',
          fontWeight: 600,
          color: 'var(--text-primary)',
          overflow: 'hidden'
        }}>
          {user.avatar ? (
            <img src={user.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%' }} />
          ) : (
            (user.username || 'A').substring(0, 1).toUpperCase()
          )}
        </div>
      </div>
    </header>
  );
}
