import { getDb } from './db.js';

export const DEFAULT_THRESHOLDS = [
  { action_type: 'channel_delete', limit_count: 2, window_seconds: 10, punishment: 'ban' },
  { action_type: 'channel_create', limit_count: 4, window_seconds: 15, punishment: 'quarantine' },
  { action_type: 'role_delete', limit_count: 2, window_seconds: 10, punishment: 'ban' },
  { action_type: 'role_create', limit_count: 4, window_seconds: 15, punishment: 'quarantine' },
  { action_type: 'ban_add', limit_count: 3, window_seconds: 20, punishment: 'ban' },
  { action_type: 'kick_add', limit_count: 4, window_seconds: 20, punishment: 'ban' },
  { action_type: 'webhook_create', limit_count: 2, window_seconds: 15, punishment: 'quarantine' },
  { action_type: 'perm_escalate', limit_count: 1, window_seconds: 10, punishment: 'strip_roles' },
  { action_type: 'mass_mention', limit_count: 2, window_seconds: 10, punishment: 'quarantine' }
];

export function getGuildConfig(guildId) {
  const db = getDb();
  let row = db.prepare('SELECT * FROM guild_configs WHERE guild_id = ?').get(guildId);

  if (!row) {
    db.prepare(`
      INSERT INTO guild_configs (guild_id, updated_at) VALUES (?, strftime('%s', 'now'))
    `).run(guildId);
    row = db.prepare('SELECT * FROM guild_configs WHERE guild_id = ?').get(guildId);

    // Initialize default thresholds
    const insertThreshold = db.prepare(`
      INSERT OR IGNORE INTO action_thresholds (guild_id, action_type, limit_count, window_seconds, punishment)
      VALUES (?, ?, ?, ?, ?)
    `);
    for (const t of DEFAULT_THRESHOLDS) {
      insertThreshold.run(guildId, t.action_type, t.limit_count, t.window_seconds, t.punishment);
    }
  }

  // Fetch thresholds
  const thresholds = db.prepare('SELECT * FROM action_thresholds WHERE guild_id = ?').all(guildId);
  return {
    ...row,
    thresholds
  };
}

export function updateGuildConfig(guildId, updates) {
  const db = getDb();
  getGuildConfig(guildId); // Ensure exists

  const allowedKeys = [
    'shield_enabled', 'anti_nuke_enabled', 'anti_raid_enabled', 'anti_bot_enabled',
    'anti_webhook_enabled', 'anti_role_abuse_enabled', 'anti_channel_delete_enabled',
    'anti_server_settings_enabled', 'anti_everyone_enabled', 'anti_invite_enabled',
    'anti_spam_enabled', 'anti_phishing_enabled', 'anti_impersonation_enabled',
    'account_age_min_days', 'account_age_action', 'verification_enabled',
    'verification_type', 'verification_role_id', 'quarantine_role_id',
    'sentinel_log_channel_id', 'mod_log_channel_id', 'member_log_channel_id',
    'punishment_default', 'lockdown_active', 'lockdown_policy', 'lockdown_expires_at',
    'server_name_backup', 'anti_token_leak_enabled', 'anti_ghost_ping_enabled', 'anti_alt_enabled', 'anti_alt_min_age_days', 'anti_alt_require_avatar', 'anti_alt_action', 'staff_role_id', 'dj_role_id', 'max_music_volume', 'max_queue_limit', 'strict_link_ban_channel_ids', 'verification_channel_id'
  ];

  const setClauses = [];
  const values = [];

  for (const [key, val] of Object.entries(updates)) {
    if (allowedKeys.includes(key)) {
      setClauses.push(`${key} = ?`);
      values.push(val);
    }
  }

  if (setClauses.length > 0) {
    setClauses.push("updated_at = strftime('%s', 'now')");
    values.push(guildId);
    const query = `UPDATE guild_configs SET ${setClauses.join(', ')} WHERE guild_id = ?`;
    db.prepare(query).run(...values);
  }

  return getGuildConfig(guildId);
}

export function updateThreshold(guildId, actionType, { limit_count, window_seconds, punishment }) {
  const db = getDb();
  db.prepare(`
    INSERT INTO action_thresholds (guild_id, action_type, limit_count, window_seconds, punishment)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, action_type) DO UPDATE SET
      limit_count = excluded.limit_count,
      window_seconds = excluded.window_seconds,
      punishment = excluded.punishment
  `).run(guildId, actionType, limit_count, window_seconds, punishment);

  return db.prepare('SELECT * FROM action_thresholds WHERE guild_id = ? AND action_type = ?').get(guildId, actionType);
}
