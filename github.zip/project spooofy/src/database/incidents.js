import { getDb } from './db.js';
import crypto from 'crypto';

export function createIncident({ title, description, severity = 'MEDIUM', affected_services = 'Discord Gateway', assigned_staff_id = null, assigned_staff_tag = null }) {
  const db = getDb();
  const id = 'inc_' + crypto.randomBytes(5).toString('hex');
  const now = Math.floor(Date.now() / 1000);

  db.prepare(`
    INSERT INTO internal_incidents (
      id, title, description, severity, status, affected_services, assigned_staff_id, assigned_staff_tag, investigation_notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, 'INVESTIGATING', ?, ?, ?, '', ?, ?)
  `).run(id, title, description, severity, affected_services, assigned_staff_id, assigned_staff_tag, now, now);

  return getIncident(id);
}

export function getIncident(id) {
  const db = getDb();
  return db.prepare('SELECT * FROM internal_incidents WHERE id = ?').get(id);
}

export function listIncidents(status = null, limit = 50) {
  const db = getDb();
  if (status) {
    return db.prepare('SELECT * FROM internal_incidents WHERE status = ? ORDER BY created_at DESC LIMIT ?').all(status, limit);
  }
  return db.prepare('SELECT * FROM internal_incidents ORDER BY created_at DESC LIMIT ?').all(limit);
}

export function updateIncident(id, { status, investigation_notes, assigned_staff_id, assigned_staff_tag }) {
  const db = getDb();
  const current = getIncident(id);
  if (!current) return null;

  const now = Math.floor(Date.now() / 1000);
  const updatedStatus = status || current.status;
  const updatedNotes = investigation_notes !== undefined ? investigation_notes : current.investigation_notes;
  const updatedStaffId = assigned_staff_id !== undefined ? assigned_staff_id : current.assigned_staff_id;
  const updatedStaffTag = assigned_staff_tag !== undefined ? assigned_staff_tag : current.assigned_staff_tag;

  db.prepare(`
    UPDATE internal_incidents SET status = ?, investigation_notes = ?, assigned_staff_id = ?, assigned_staff_tag = ?, updated_at = ?
    WHERE id = ?
  `).run(updatedStatus, updatedNotes, updatedStaffId, updatedStaffTag, now, id);

  return getIncident(id);
}
