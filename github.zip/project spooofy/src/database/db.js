import Database from 'better-sqlite3';
import { config } from '../config.js';

let dbInstance = null;

export function getDb() {
  if (!dbInstance) {
    dbInstance = new Database(config.databasePath);
    dbInstance.pragma('journal_mode = WAL');
    initTables(dbInstance);
  }
  return dbInstance;
}

function initTables(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS guild_configs (
      guild_id TEXT PRIMARY KEY,
      shield_enabled INTEGER DEFAULT 1,
      anti_nuke_enabled INTEGER DEFAULT 1,
      anti_raid_enabled INTEGER DEFAULT 1,
      anti_bot_enabled INTEGER DEFAULT 1,
      anti_webhook_enabled INTEGER DEFAULT 1,
      anti_role_abuse_enabled INTEGER DEFAULT 1,
      anti_channel_delete_enabled INTEGER DEFAULT 1,
      anti_server_settings_enabled INTEGER DEFAULT 1,
      anti_everyone_enabled INTEGER DEFAULT 1,
      anti_invite_enabled INTEGER DEFAULT 1,
      anti_spam_enabled INTEGER DEFAULT 1,
      anti_phishing_enabled INTEGER DEFAULT 1,
      anti_impersonation_enabled INTEGER DEFAULT 1,
      account_age_min_days INTEGER DEFAULT 3,
      account_age_action TEXT DEFAULT 'quarantine',
      verification_enabled INTEGER DEFAULT 0,
      verification_type TEXT DEFAULT 'button',
      verification_role_id TEXT DEFAULT '',
      quarantine_role_id TEXT DEFAULT '',
      sentinel_log_channel_id TEXT DEFAULT '',
      mod_log_channel_id TEXT DEFAULT '',
      member_log_channel_id TEXT DEFAULT '',
      punishment_default TEXT DEFAULT 'quarantine',
      lockdown_active INTEGER DEFAULT 0,
      lockdown_policy TEXT DEFAULT '{}',
      lockdown_expires_at INTEGER DEFAULT 0,
      server_name_backup TEXT DEFAULT '',
      updated_at INTEGER DEFAULT (strftime('%s', 'now'))
    );

    CREATE TABLE IF NOT EXISTS action_thresholds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      action_type TEXT NOT NULL,
      limit_count INTEGER NOT NULL,
      window_seconds INTEGER NOT NULL,
      punishment TEXT NOT NULL,
      UNIQUE(guild_id, action_type)
    );

    CREATE TABLE IF NOT EXISTS trusted_admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      target_id TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_tag TEXT,
      added_by TEXT NOT NULL,
      added_at INTEGER NOT NULL,
      notes TEXT,
      UNIQUE(guild_id, target_id)
    );

    CREATE TABLE IF NOT EXISTS security_alerts (
      id TEXT PRIMARY KEY,
      guild_id TEXT NOT NULL,
      severity TEXT NOT NULL,
      category TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      actor_id TEXT,
      actor_tag TEXT,
      target_type TEXT,
      target_id TEXT,
      target_name TEXT,
      action_taken TEXT,
      snapshot_data TEXT,
      status TEXT DEFAULT 'ACTIVE',
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      actor_id TEXT,
      actor_tag TEXT,
      target_id TEXT,
      target_name TEXT,
      reason TEXT,
      changes_json TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS moderation_cases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      case_type TEXT NOT NULL,
      user_id TEXT NOT NULL,
      user_tag TEXT,
      moderator_id TEXT NOT NULL,
      moderator_tag TEXT,
      reason TEXT,
      duration_seconds INTEGER DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS backups (
      id TEXT PRIMARY KEY,
      guild_id TEXT NOT NULL,
      backup_name TEXT NOT NULL,
      creator_id TEXT NOT NULL,
      creator_tag TEXT,
      channels_json TEXT NOT NULL,
      roles_json TEXT NOT NULL,
      settings_json TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tickets (
      id TEXT PRIMARY KEY,
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      creator_id TEXT NOT NULL,
      creator_tag TEXT,
      category TEXT DEFAULT 'General Support',
      priority TEXT DEFAULT 'MEDIUM',
      status TEXT DEFAULT 'OPEN',
      assigned_staff_id TEXT,
      internal_notes TEXT,
      created_at INTEGER NOT NULL,
      closed_at INTEGER,
      transcript TEXT
    );

    -- New Tables for Public Web, OAuth2, Staff Portal & Owner Admin Panel

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      discord_id TEXT UNIQUE NOT NULL,
      username TEXT NOT NULL,
      discriminator TEXT,
      avatar TEXT,
      email TEXT,
      is_system_admin INTEGER DEFAULT 0,
      created_at INTEGER NOT NULL,
      last_login INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      session_token TEXT UNIQUE NOT NULL,
      expires_at INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      user_agent TEXT,
      ip_address TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS staff_members (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      discord_id TEXT UNIQUE NOT NULL,
      username TEXT NOT NULL,
      avatar TEXT,
      role TEXT NOT NULL, -- 'OWNER', 'ADMINISTRATOR', 'SENIOR_STAFF', 'MODERATOR', 'SUPPORT_AGENT', 'DEVELOPER', 'AUDITOR'
      status TEXT DEFAULT 'ACTIVE', -- 'ACTIVE', 'SUSPENDED'
      created_by TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS staff_activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      staff_id TEXT NOT NULL,
      staff_tag TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT,
      target_id TEXT,
      details_json TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS internal_incidents (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      severity TEXT NOT NULL, -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
      status TEXT DEFAULT 'INVESTIGATING', -- 'INVESTIGATING', 'IDENTIFIED', 'MONITORING', 'RESOLVED'
      affected_services TEXT,
      assigned_staff_id TEXT,
      assigned_staff_tag TEXT,
      investigation_notes TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS internal_announcements (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      target_roles TEXT DEFAULT 'ALL',
      author_id TEXT NOT NULL,
      author_tag TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS global_configs (
      key TEXT PRIMARY KEY,
      value_json TEXT NOT NULL,
      updated_by TEXT,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS guild_music_sessions (
      guild_id TEXT PRIMARY KEY,
      channel_id TEXT,
      current_track_title TEXT,
      current_track_author TEXT,
      current_track_url TEXT,
      duration_ms INTEGER DEFAULT 0,
      position_ms INTEGER DEFAULT 0,
      is_playing INTEGER DEFAULT 0,
      is_paused INTEGER DEFAULT 0,
      volume INTEGER DEFAULT 100,
      loop_mode TEXT DEFAULT 'OFF',
      is_247 INTEGER DEFAULT 0,
      queue_json TEXT DEFAULT '[]',
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS guild_welcome_configs (
      guild_id TEXT PRIMARY KEY,
      welcome_enabled INTEGER DEFAULT 0,
      welcome_channel_id TEXT DEFAULT '',
      welcome_message TEXT DEFAULT 'Welcome {user} to {server}!',
      welcome_embed_json TEXT DEFAULT '{}',
      dm_welcome_enabled INTEGER DEFAULT 0,
      dm_welcome_message TEXT DEFAULT '',
      goodbye_enabled INTEGER DEFAULT 0,
      goodbye_channel_id TEXT DEFAULT '',
      goodbye_message TEXT DEFAULT '{user} left the server.'
    );

    CREATE TABLE IF NOT EXISTS guild_logging_configs (
      guild_id TEXT PRIMARY KEY,
      mod_log_channel_id TEXT DEFAULT '',
      security_log_channel_id TEXT DEFAULT '',
      member_log_channel_id TEXT DEFAULT '',
      message_log_channel_id TEXT DEFAULT '',
      role_log_channel_id TEXT DEFAULT '',
      channel_log_channel_id TEXT DEFAULT '',
      voice_log_channel_id TEXT DEFAULT ''
    );

    CREATE INDEX IF NOT EXISTS idx_alerts_guild ON security_alerts(guild_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_audit_guild ON audit_logs(guild_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_mod_guild ON moderation_cases(guild_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(session_token);
    CREATE INDEX IF NOT EXISTS idx_staff_discord ON staff_members(discord_id);
  `);

  // Safe table migrations for column additions
  const safeMigrations = [
    'ALTER TABLE tickets ADD COLUMN assigned_staff_id TEXT',
    'ALTER TABLE tickets ADD COLUMN internal_notes TEXT',
    'ALTER TABLE tickets ADD COLUMN category TEXT DEFAULT "General Support"',
    'ALTER TABLE tickets ADD COLUMN priority TEXT DEFAULT "MEDIUM"',
    'ALTER TABLE guild_configs ADD COLUMN anti_token_leak_enabled INTEGER DEFAULT 1',
    'ALTER TABLE guild_configs ADD COLUMN anti_ghost_ping_enabled INTEGER DEFAULT 1',
    'ALTER TABLE guild_configs ADD COLUMN anti_alt_enabled INTEGER DEFAULT 1',
    'ALTER TABLE guild_configs ADD COLUMN anti_alt_min_age_days INTEGER DEFAULT 7',
    'ALTER TABLE guild_configs ADD COLUMN anti_alt_require_avatar INTEGER DEFAULT 0',
    'ALTER TABLE guild_configs ADD COLUMN anti_alt_action TEXT DEFAULT "quarantine"',
    'ALTER TABLE guild_configs ADD COLUMN staff_role_id TEXT DEFAULT ""',
    'ALTER TABLE guild_configs ADD COLUMN dj_role_id TEXT DEFAULT ""',
    'ALTER TABLE guild_configs ADD COLUMN max_music_volume INTEGER DEFAULT 100',
    'ALTER TABLE guild_configs ADD COLUMN max_queue_limit INTEGER DEFAULT 50',
    'ALTER TABLE guild_configs ADD COLUMN strict_link_ban_channel_ids TEXT DEFAULT "[]"',
    'ALTER TABLE guild_configs ADD COLUMN verification_channel_id TEXT DEFAULT ""'
  ];
  for (const m of safeMigrations) {
    try { db.exec(m); } catch {}
  }
}
