import { getDb } from './db.js';

export function logAuditEvent({
  guild_id,
  event_type,
  actor_id = null,
  actor_tag = null,
  target_id = null,
  target_name = null,
  reason = null,
  changes_json = null
}) {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  const info = db.prepare(`
    INSERT INTO audit_logs (
      guild_id, event_type, actor_id, actor_tag, target_id, target_name, reason, changes_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    guild_id,
    event_type,
    actor_id,
    actor_tag,
    target_id,
    target_name,
    reason,
    typeof changes_json === 'object' && changes_json !== null ? JSON.stringify(changes_json) : changes_json,
    now
  );
  return db.prepare('SELECT * FROM audit_logs WHERE id = ?').get(info.lastInsertRowid);
}

export function getAuditLogs(guildId, limit = 50, offset = 0) {
  const db = getDb();
  return db.prepare(`
    SELECT * FROM audit_logs WHERE guild_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(guildId, limit, offset);
}

export function addModerationCase({
  guild_id,
  case_type,
  user_id,
  user_tag = null,
  moderator_id,
  moderator_tag = null,
  reason = null,
  duration_seconds = 0
}) {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  const info = db.prepare(`
    INSERT INTO moderation_cases (
      guild_id, case_type, user_id, user_tag, moderator_id, moderator_tag, reason, duration_seconds, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    guild_id,
    case_type,
    user_id,
    user_tag,
    moderator_id,
    moderator_tag,
    reason,
    duration_seconds,
    now
  );
  return db.prepare('SELECT * FROM moderation_cases WHERE id = ?').get(info.lastInsertRowid);
}

export function getModerationCases(guildId, userId = null, limit = 50) {
  const db = getDb();
  if (userId) {
    return db.prepare(`
      SELECT * FROM moderation_cases WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?
    `).all(guildId, userId, limit);
  }
  return db.prepare(`
    SELECT * FROM moderation_cases WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?
  `).all(guildId, limit);
}

export function getWarningCount(guildId, userId) {
  const db = getDb();
  const row = db.prepare(`
    SELECT COUNT(*) as count FROM moderation_cases 
    WHERE guild_id = ? AND user_id = ? AND case_type = 'WARN'
  `).get(guildId, userId);
  return row ? row.count : 0;
}
