import { getDb } from './db.js';
import crypto from 'crypto';

export const STAFF_ROLES = [
  'OWNER',
  'ADMINISTRATOR',
  'SECURITY_TEAM',
  'SUPPORT_TEAM',
  'SENIOR_STAFF',
  'MODERATOR',
  'DEVELOPER',
  'MUSIC_SUPPORT',
  'SUPPORT_AGENT',
  'AUDITOR'
];

export const STAFF_ROLE_RANKS = {
  OWNER: 100,
  ADMINISTRATOR: 80,
  SECURITY_TEAM: 70,
  SENIOR_STAFF: 60,
  MODERATOR: 40,
  DEVELOPER: 35,
  SUPPORT_TEAM: 30,
  MUSIC_SUPPORT: 25,
  SUPPORT_AGENT: 20,
  AUDITOR: 10
};

export function getStaffMember(discordId) {
  const db = getDb();
  return db.prepare("SELECT * FROM staff_members WHERE discord_id = ? AND status = 'ACTIVE'").get(discordId);
}

export function listStaffMembers() {
  const db = getDb();
  return db.prepare('SELECT * FROM staff_members ORDER BY created_at DESC').all();
}

export function addStaffMember({ user_id, discord_id, username, avatar = null, role = 'SUPPORT_AGENT', created_by, notes = '' }) {
  const db = getDb();
  const id = 'stf_' + crypto.randomBytes(5).toString('hex');
  const now = Math.floor(Date.now() / 1000);

  db.prepare(`
    INSERT INTO staff_members (id, user_id, discord_id, username, avatar, role, status, created_by, created_at, notes)
    VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?)
    ON CONFLICT(discord_id) DO UPDATE SET
      role = excluded.role,
      status = 'ACTIVE',
      username = excluded.username,
      avatar = excluded.avatar,
      notes = excluded.notes
  `).run(id, user_id, discord_id, username, avatar, role, created_by, now, notes);

  logStaffActivity({
    staff_id: created_by,
    staff_tag: 'Staff Admin',
    action: 'ONBOARD_STAFF',
    target_type: 'staff_member',
    target_id: discord_id,
    details: { role, username }
  });

  return getStaffMember(discord_id);
}

export function updateStaffRole(staffIdOrDiscordId, newRole, updatedBy = 'system') {
  const db = getDb();
  const member = db.prepare('SELECT * FROM staff_members WHERE id = ? OR discord_id = ?').get(staffIdOrDiscordId, staffIdOrDiscordId);
  if (!member) return null;

  db.prepare('UPDATE staff_members SET role = ? WHERE id = ?').run(newRole, member.id);

  logStaffActivity({
    staff_id: updatedBy,
    staff_tag: 'Admin',
    action: 'CHANGE_STAFF_ROLE',
    target_type: 'staff_member',
    target_id: member.discord_id,
    details: { oldRole: member.role, newRole }
  });

  return db.prepare('SELECT * FROM staff_members WHERE id = ?').get(member.id);
}

export function updateStaffStatus(staffIdOrDiscordId, status, updatedBy = 'system') {
  const db = getDb();
  const member = db.prepare('SELECT * FROM staff_members WHERE id = ? OR discord_id = ?').get(staffIdOrDiscordId, staffIdOrDiscordId);
  if (!member) return null;

  db.prepare('UPDATE staff_members SET status = ? WHERE id = ?').run(status, member.id);

  logStaffActivity({
    staff_id: updatedBy,
    staff_tag: 'Admin',
    action: status === 'ACTIVE' ? 'ACTIVATE_STAFF' : 'SUSPEND_STAFF',
    target_type: 'staff_member',
    target_id: member.discord_id,
    details: { status }
  });

  return db.prepare('SELECT * FROM staff_members WHERE id = ?').get(member.id);
}

export function logStaffActivity({ staff_id, staff_tag, action, target_type = null, target_id = null, details = null }) {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);

  db.prepare(`
    INSERT INTO staff_activity_logs (staff_id, staff_tag, action, target_type, target_id, details_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    staff_id,
    staff_tag,
    action,
    target_type,
    target_id,
    details ? JSON.stringify(details) : null,
    now
  );
}

export function getStaffActivityLogs(limit = 50) {
  const db = getDb();
  return db.prepare('SELECT * FROM staff_activity_logs ORDER BY created_at DESC LIMIT ?').all(limit);
}
