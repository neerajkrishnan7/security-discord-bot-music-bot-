import { getDb } from './db.js';
import crypto from 'crypto';

export function createAlert({
  guild_id,
  severity,
  category,
  title,
  description,
  actor_id = null,
  actor_tag = null,
  target_type = null,
  target_id = null,
  target_name = null,
  action_taken = null,
  snapshot_data = null
}) {
  const db = getDb();
  const id = 'alert_' + crypto.randomBytes(6).toString('hex');
  const now = Math.floor(Date.now() / 1000);

  db.prepare(`
    INSERT INTO security_alerts (
      id, guild_id, severity, category, title, description,
      actor_id, actor_tag, target_type, target_id, target_name,
      action_taken, snapshot_data, status, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?)
  `).run(
    id,
    guild_id,
    severity,
    category,
    title,
    description,
    actor_id,
    actor_tag,
    target_type,
    target_id,
    target_name,
    action_taken,
    typeof snapshot_data === 'object' && snapshot_data !== null ? JSON.stringify(snapshot_data) : snapshot_data,
    now
  );

  return db.prepare('SELECT * FROM security_alerts WHERE id = ?').get(id);
}

export function getAlerts(guildId, limit = 50, offset = 0) {
  const db = getDb();
  return db.prepare(`
    SELECT * FROM security_alerts 
    WHERE guild_id = ? 
    ORDER BY created_at DESC 
    LIMIT ? OFFSET ?
  `).all(guildId, limit, offset);
}

export function updateAlertStatus(alertId, status) {
  const db = getDb();
  db.prepare('UPDATE security_alerts SET status = ? WHERE id = ?').run(status, alertId);
  return db.prepare('SELECT * FROM security_alerts WHERE id = ?').get(alertId);
}

export function getAlertStats(guildId) {
  const db = getDb();
  const total = db.prepare('SELECT COUNT(*) as count FROM security_alerts WHERE guild_id = ?').get(guildId)?.count || 0;
  const critical = db.prepare("SELECT COUNT(*) as count FROM security_alerts WHERE guild_id = ? AND severity = 'CRITICAL'").get(guildId)?.count || 0;
  const high = db.prepare("SELECT COUNT(*) as count FROM security_alerts WHERE guild_id = ? AND severity = 'HIGH'").get(guildId)?.count || 0;
  const active = db.prepare("SELECT COUNT(*) as count FROM security_alerts WHERE guild_id = ? AND status = 'ACTIVE'").get(guildId)?.count || 0;

  return { total, critical, high, active };
}
