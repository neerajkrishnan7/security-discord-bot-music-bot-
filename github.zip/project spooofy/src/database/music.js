import { getDb } from './db.js';

export function getMusicSession(guildId) {
  const db = getDb();
  let row = db.prepare('SELECT * FROM guild_music_sessions WHERE guild_id = ?').get(guildId);

  if (!row) {
    const now = Math.floor(Date.now() / 1000);
    db.prepare(`
      INSERT INTO guild_music_sessions (guild_id, is_playing, is_paused, volume, loop_mode, queue_json, updated_at)
      VALUES (?, 0, 0, 100, 'OFF', '[]', ?)
    `).run(guildId, now);
    row = db.prepare('SELECT * FROM guild_music_sessions WHERE guild_id = ?').get(guildId);
  }

  return {
    ...row,
    queue: JSON.parse(row.queue_json || '[]')
  };
}

export function updateMusicSession(guildId, updates) {
  const db = getDb();
  getMusicSession(guildId); // Ensure exists

  const allowed = [
    'channel_id', 'current_track_title', 'current_track_author', 'current_track_url',
    'duration_ms', 'position_ms', 'is_playing', 'is_paused', 'volume', 'loop_mode',
    'is_247', 'queue_json'
  ];

  const setClauses = [];
  const values = [];

  for (const [key, val] of Object.entries(updates)) {
    if (allowed.includes(key)) {
      setClauses.push(`${key} = ?`);
      values.push(key === 'queue_json' && typeof val === 'object' ? JSON.stringify(val) : val);
    }
  }

  if (setClauses.length > 0) {
    setClauses.push("updated_at = strftime('%s', 'now')");
    values.push(guildId);
    db.prepare(`UPDATE guild_music_sessions SET ${setClauses.join(', ')} WHERE guild_id = ?`).run(...values);
  }

  return getMusicSession(guildId);
}

export function getAllActiveMusicSessions() {
  const db = getDb();
  return db.prepare('SELECT * FROM guild_music_sessions WHERE is_playing = 1').all();
}
