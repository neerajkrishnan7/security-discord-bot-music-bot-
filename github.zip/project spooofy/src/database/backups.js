import { getDb } from './db.js';
import crypto from 'crypto';

export function saveBackup({
  guild_id,
  backup_name,
  creator_id,
  creator_tag = null,
  channels,
  roles,
  settings
}) {
  const db = getDb();
  const id = 'bk_' + crypto.randomBytes(5).toString('hex');
  const now = Math.floor(Date.now() / 1000);

  db.prepare(`
    INSERT INTO backups (
      id, guild_id, backup_name, creator_id, creator_tag,
      channels_json, roles_json, settings_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    guild_id,
    backup_name,
    creator_id,
    creator_tag,
    JSON.stringify(channels),
    JSON.stringify(roles),
    JSON.stringify(settings),
    now
  );

  return getBackup(id);
}

export function getBackup(backupId) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM backups WHERE id = ?').get(backupId);
  if (!row) return null;
  return {
    ...row,
    channels: JSON.parse(row.channels_json),
    roles: JSON.parse(row.roles_json),
    settings: JSON.parse(row.settings_json)
  };
}

export function getBackups(guildId) {
  const db = getDb();
  const rows = db.prepare(`
    SELECT id, guild_id, backup_name, creator_id, creator_tag, created_at,
           length(channels_json) as channels_size,
           length(roles_json) as roles_size
    FROM backups WHERE guild_id = ? ORDER BY created_at DESC
  `).all(guildId);
  return rows;
}

export function deleteBackup(backupId) {
  const db = getDb();
  const info = db.prepare('DELETE FROM backups WHERE id = ?').run(backupId);
  return info.changes > 0;
}
