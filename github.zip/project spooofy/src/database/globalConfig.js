import { getDb } from './db.js';

export function getGlobalConfig(key, defaultValue = null) {
  const db = getDb();
  const row = db.prepare('SELECT value_json FROM global_configs WHERE key = ?').get(key);
  if (!row) return defaultValue;
  try {
    return JSON.parse(row.value_json);
  } catch (e) {
    return defaultValue;
  }
}

export function setGlobalConfig(key, value, updatedBy = 'system') {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  const jsonStr = JSON.stringify(value);

  db.prepare(`
    INSERT INTO global_configs (key, value_json, updated_by, updated_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET
      value_json = excluded.value_json,
      updated_by = excluded.updated_by,
      updated_at = excluded.updated_at
  `).run(key, jsonStr, updatedBy, now);

  return value;
}

export function getAllGlobalConfigs() {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM global_configs').all();
  const configs = {};
  for (const r of rows) {
    try {
      configs[r.key] = JSON.parse(r.value_json);
    } catch (e) {
      configs[r.key] = r.value_json;
    }
  }
  return configs;
}
