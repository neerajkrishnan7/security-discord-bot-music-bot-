import { getDb } from './db.js';
import crypto from 'crypto';

export function upsertUser({ discord_id, username, discriminator = null, avatar = null, email = null, is_system_admin = 0 }) {
  const db = getDb();
  let user = db.prepare('SELECT * FROM users WHERE discord_id = ?').get(discord_id);
  const now = Math.floor(Date.now() / 1000);

  if (!user) {
    const id = 'usr_' + crypto.randomBytes(6).toString('hex');
    db.prepare(`
      INSERT INTO users (id, discord_id, username, discriminator, avatar, email, is_system_admin, created_at, last_login)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, discord_id, username, discriminator, avatar, email, is_system_admin, now, now);
    user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  } else {
    db.prepare(`
      UPDATE users SET username = ?, discriminator = ?, avatar = ?, email = ?, last_login = ?
      WHERE discord_id = ?
    `).run(username, discriminator, avatar, email, now, discord_id);
    user = db.prepare('SELECT * FROM users WHERE discord_id = ?').get(discord_id);
  }

  return user;
}

export function getUserById(id) {
  const db = getDb();
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

export function getUserByDiscordId(discordId) {
  const db = getDb();
  return db.prepare('SELECT * FROM users WHERE discord_id = ?').get(discordId);
}

export function createSession(userId, userAgent = '', ipAddress = '') {
  const db = getDb();
  const id = 'sess_' + crypto.randomBytes(8).toString('hex');
  const sessionToken = crypto.randomBytes(32).toString('hex');
  const now = Math.floor(Date.now() / 1000);
  const expiresAt = now + (7 * 24 * 60 * 60); // 7 days

  db.prepare(`
    INSERT INTO sessions (id, user_id, session_token, expires_at, created_at, user_agent, ip_address)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(id, userId, sessionToken, expiresAt, now, userAgent, ipAddress);

  return { id, sessionToken, expiresAt };
}

export function getSession(sessionToken) {
  if (!sessionToken) return null;
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);

  const session = db.prepare(`
    SELECT s.*, u.discord_id, u.username, u.avatar, u.email, u.is_system_admin
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.session_token = ? AND s.expires_at > ?
  `).get(sessionToken, now);

  return session || null;
}

export function deleteSession(sessionToken) {
  const db = getDb();
  db.prepare('DELETE FROM sessions WHERE session_token = ?').run(sessionToken);
}
