import { getDb } from './db.js';
import crypto from 'crypto';

export function createAnnouncement({ title, content, target_roles = 'ALL', author_id, author_tag }) {
  const db = getDb();
  const id = 'ann_' + crypto.randomBytes(5).toString('hex');
  const now = Math.floor(Date.now() / 1000);

  db.prepare(`
    INSERT INTO internal_announcements (id, title, content, target_roles, author_id, author_tag, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(id, title, content, target_roles, author_id, author_tag, now);

  return db.prepare('SELECT * FROM internal_announcements WHERE id = ?').get(id);
}

export function listAnnouncements(limit = 20) {
  const db = getDb();
  return db.prepare('SELECT * FROM internal_announcements ORDER BY created_at DESC LIMIT ?').all(limit);
}
