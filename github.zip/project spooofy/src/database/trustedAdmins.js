import { getDb } from './db.js';

export function getTrustedAdmins(guildId) {
  const db = getDb();
  return db.prepare('SELECT * FROM trusted_admins WHERE guild_id = ? ORDER BY added_at DESC').all(guildId);
}

export function isTrusted(guildId, targetId, roleIds = []) {
  const db = getDb();
  // Check direct user
  const userMatch = db.prepare('SELECT 1 FROM trusted_admins WHERE guild_id = ? AND target_id = ?').get(guildId, targetId);
  if (userMatch) return true;

  // Check roles if provided
  if (roleIds && roleIds.length > 0) {
    const placeholders = roleIds.map(() => '?').join(',');
    const roleMatch = db.prepare(`
      SELECT 1 FROM trusted_admins 
      WHERE guild_id = ? AND target_type = 'role' AND target_id IN (${placeholders})
    `).get(guildId, ...roleIds);
    if (roleMatch) return true;
  }

  return false;
}

export function addTrustedAdmin(guildId, { target_id, target_type, target_tag, added_by, notes }) {
  const db = getDb();
  db.prepare(`
    INSERT INTO trusted_admins (guild_id, target_id, target_type, target_tag, added_by, added_at, notes)
    VALUES (?, ?, ?, ?, ?, strftime('%s', 'now'), ?)
    ON CONFLICT(guild_id, target_id) DO UPDATE SET
      target_tag = excluded.target_tag,
      added_by = excluded.added_by,
      added_at = excluded.added_at,
      notes = excluded.notes
  `).run(guildId, target_id, target_type, target_tag || '', added_by, notes || '');

  return db.prepare('SELECT * FROM trusted_admins WHERE guild_id = ? AND target_id = ?').get(guildId, target_id);
}

export function removeTrustedAdmin(guildId, targetId) {
  const db = getDb();
  const info = db.prepare('DELETE FROM trusted_admins WHERE guild_id = ? AND target_id = ?').run(guildId, targetId);
  return info.changes > 0;
}
