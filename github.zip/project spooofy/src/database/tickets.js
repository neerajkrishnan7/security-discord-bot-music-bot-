import { getDb } from './db.js';
import crypto from 'crypto';

export function createTicket({ guild_id, channel_id, creator_id, creator_tag, category = 'General Support' }) {
  const db = getDb();
  const id = 'ticket_' + crypto.randomBytes(4).toString('hex');
  const now = Math.floor(Date.now() / 1000);

  db.prepare(`
    INSERT INTO tickets (id, guild_id, channel_id, creator_id, creator_tag, category, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 'OPEN', ?)
  `).run(id, guild_id, channel_id, creator_id, creator_tag, category, now);

  return db.prepare('SELECT * FROM tickets WHERE id = ?').get(id);
}

export function closeTicket(ticketId, transcript = '') {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  db.prepare(`
    UPDATE tickets SET status = 'CLOSED', closed_at = ?, transcript = ? WHERE id = ?
  `).run(now, transcript, ticketId);
  return db.prepare('SELECT * FROM tickets WHERE id = ?').get(ticketId);
}

export function getTickets(guildId, status = null) {
  const db = getDb();
  if (status) {
    return db.prepare('SELECT * FROM tickets WHERE guild_id = ? AND status = ? ORDER BY created_at DESC').all(guildId, status);
  }
  return db.prepare('SELECT * FROM tickets WHERE guild_id = ? ORDER BY created_at DESC').all(guildId);
}

export function getTicketByChannel(channelId) {
  const db = getDb();
  return db.prepare('SELECT * FROM tickets WHERE channel_id = ?').get(channelId);
}
