import { AuditLogEvent, Events, PermissionFlagsBits } from 'discord.js';
import { handleDestructiveAction } from '../shield/antiNuke.js';
import { handleMemberJoin } from '../shield/antiRaid.js';
import { handleBotAdd } from '../shield/antiBot.js';
import { handleRoleUpdate } from '../shield/antiRoleAbuse.js';
import { handleGuildUpdate } from '../shield/antiSettings.js';
import { handleChatMessage } from '../shield/antiChat.js';
import { checkImpersonation } from '../shield/impersonation.js';
import { handleAltDetection } from '../shield/antiAlt.js';
import { findAuditLogEntry } from '../sentinel/auditLogger.js';
import { executeSafeRestore } from '../recovery/rollback.js';
import { logAuditEvent, addModerationCase } from '../../database/moderation.js';
import { updateAlertStatus } from '../../database/alerts.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { createTicket, closeTicket, getTickets } from '../../database/tickets.js';
import { getDb } from '../../database/db.js';
import { config } from '../../config.js';

export function registerGatewayEvents(client, commands) {
  // 1. Ready
  client.once(Events.ClientReady, (c) => {
    console.log(`[Discord] Logged in as ${c.user.tag}! Active guilds: ${c.guilds.cache.size}`);
    c.user.setPresence({
      activities: [{ name: '🛡️ SPOOFY Shield Active', type: 3 }],
      status: 'online'
    });
  });

  // 2. Slash Commands & Button Interactions
  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        const cmd = commands.get(interaction.commandName);
        if (cmd) {
          await cmd.execute(interaction, client);
        } else {
          await interaction.reply({ content: 'Unknown command.', ephemeral: true });
        }
      } else if (interaction.isButton()) {
        await handleButtonInteraction(interaction, client);
      }
    } catch (err) {
      console.error('[Interaction] Error handling interaction:', err);
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp({ content: `An error occurred: ${err.message}`, ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: `An error occurred: ${err.message}`, ephemeral: true }).catch(() => {});
      }
    }
  });

  // 3. Channel Delete (Anti-Nuke)
  client.on(Events.ChannelDelete, async (channel) => {
    if (!channel.guild) return;
    const entry = await findAuditLogEntry(channel.guild, AuditLogEvent.ChannelDelete, channel.id, 5000, 3);
    const actor = entry?.executor;
    if (actor) {
      await handleDestructiveAction({
        guild: channel.guild,
        actor,
        actionType: 'channel_delete',
        target: channel,
        client
      });
    }
  });

  // 4. Channel Create (Anti-Nuke / Channel Spam Flooding)
  client.on(Events.ChannelCreate, async (channel) => {
    if (!channel.guild) return;
    const entry = await findAuditLogEntry(channel.guild, AuditLogEvent.ChannelCreate, channel.id, 5000, 3);
    const actor = entry?.executor;
    if (actor) {
      const res = await handleDestructiveAction({
        guild: channel.guild,
        actor,
        actionType: 'channel_create',
        target: channel,
        client
      });
      // If user exceeded threshold and was punished, clean up the rogue spam channel
      if (res?.status === 'punished') {
        await channel.delete('SPOOFY Anti-Nuke: Rogue channel creation detected').catch(() => {});
      }
    }
  });

  // 5. Role Delete (Anti-Nuke)
  client.on(Events.RoleDelete, async (role) => {
    if (!role.guild) return;
    const entry = await findAuditLogEntry(role.guild, AuditLogEvent.RoleDelete, role.id, 5000, 3);
    const actor = entry?.executor;
    if (actor) {
      await handleDestructiveAction({
        guild: role.guild,
        actor,
        actionType: 'role_delete',
        target: role,
        client
      });
    }
  });

  // 6. Role Create (Anti-Nuke / Role Spam Flooding)
  client.on(Events.RoleCreate, async (role) => {
    if (!role.guild) return;
    const entry = await findAuditLogEntry(role.guild, AuditLogEvent.RoleCreate, role.id, 5000, 3);
    const actor = entry?.executor;
    if (actor) {
      const res = await handleDestructiveAction({
        guild: role.guild,
        actor,
        actionType: 'role_create',
        target: role,
        client
      });
      if (res?.status === 'punished') {
        await role.delete('SPOOFY Anti-Nuke: Rogue role creation detected').catch(() => {});
      }
    }
  });

  // 7. Member Ban Add (Anti-Nuke Mass Ban)
  client.on(Events.GuildBanAdd, async (ban) => {
    if (!ban.guild) return;
    const entry = await findAuditLogEntry(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id, 5000, 3);
    const actor = entry?.executor;
    if (actor) {
      await handleDestructiveAction({
        guild: ban.guild,
        actor,
        actionType: 'ban_add',
        target: ban,
        client
      });
    }
  });

  // 8. Member Remove / Kick & Prune Detection (Anti-Nuke Mass Kick & Prune)
  client.on(Events.GuildMemberRemove, async (member) => {
    if (!member.guild) return;
    let entry = await findAuditLogEntry(member.guild, AuditLogEvent.MemberKick, member.id, 5000, 3);
    let actionType = 'kick_add';

    if (!entry) {
      entry = await findAuditLogEntry(member.guild, AuditLogEvent.MemberPrune, null, 5000, 2);
      if (entry) actionType = 'prune_abuse';
    }

    const actor = entry?.executor;
    if (actor) {
      await handleDestructiveAction({
        guild: member.guild,
        actor,
        actionType,
        target: member,
        client
      });
    }
  });

  // 9. Role Update (Permission escalation detection)
  client.on(Events.GuildRoleUpdate, async (oldRole, newRole) => {
    await handleRoleUpdate(oldRole, newRole, client);
  });

  // 10. Guild Update (Anti-Settings / Vanity Tampering)
  client.on(Events.GuildUpdate, async (oldGuild, newGuild) => {
    await handleGuildUpdate(oldGuild, newGuild, client);
  });

  // 11. Member Add (Anti-Raid, Anti-Bot, Impersonation)
  client.on(Events.GuildMemberAdd, async (member) => {
    if (member.user.bot) {
      await handleBotAdd(member, client);
    } else {
      await handleMemberJoin(member, client);
      await checkImpersonation(member, client);
      await handleAltDetection(member, client);

      // Verification Gatekeeper DM Notice
      const guildConfig = getGuildConfig(member.guild.id);
      if (guildConfig.verification_enabled && guildConfig.verification_role_id) {
        const verifyNotice = guildConfig.verification_channel_id ? `<#${guildConfig.verification_channel_id}>` : 'the verification channel';
        member.send({
          embeds: [{
            title: `🛡️ Welcome to ${member.guild.name} — Verification Required`,
            color: config.branding.colorInt,
            description: `Hello <@${member.id}>!\n\nTo keep our server safe from automated raid bots, **you must verify first before accessing any channels**.\n\nPlease go to ${verifyNotice} in the server and click **✅ Verify Access** to unlock your membership!`,
            footer: { text: 'SPOOFY Gatekeeper Protection' }
          }]
        }).catch(() => {});
      }
    }
  });

  // 12. Message Create (Anti-Chat, Spam, Phishing, Mass Mentions)
  client.on(Events.MessageCreate, async (message) => {
    await handleChatMessage(message, client);
  });

  // 13. Webhook Update (Anti-Nuke Webhook Spam & Rogue Webhook Auto-Kill)
  client.on(Events.WebhooksUpdate, async (channel) => {
    if (!channel.guild) return;
    const entry = await findAuditLogEntry(channel.guild, AuditLogEvent.WebhookCreate, null, 5000, 3);
    const actor = entry?.executor;
    if (actor) {
      // Immediate rogue webhook auto-deletion if creator is untrusted
      const isOwner = actor.id === channel.guild.ownerId || (config.botOwnerId && actor.id === config.botOwnerId);
      const isBotSelf = actor.id === client.user?.id;

      if (!isOwner && !isBotSelf && channel.permissionsFor(channel.guild.members.me)?.has('ManageWebhooks')) {
        try {
          const webhooks = await channel.fetchWebhooks().catch(() => null);
          if (webhooks) {
            const rogue = webhooks.find(w => w.owner?.id === actor.id);
            if (rogue) {
              await rogue.delete('SPOOFY Anti-Webhook: Unauthorized rogue webhook eliminated on creation').catch(() => {});
            }
          }
        } catch (e) {}
      }

      await handleDestructiveAction({
        guild: channel.guild,
        actor,
        actionType: 'webhook_create',
        target: channel,
        client
      });
    }
  });
  // 14. Message Delete (Anti-Ghost Ping Detection)
  client.on(Events.MessageDelete, async (message) => {
    if (!message.guild || !message.author || message.author.bot) return;

    const guild = message.guild;
    const author = message.author;
    if (author.id === guild.ownerId || (config.botOwnerId && author.id === config.botOwnerId)) return;

    const guildConfig = getGuildConfig(guild.id);
    if (!guildConfig.shield_enabled || !guildConfig.anti_ghost_ping_enabled) return;

    const mentions = message.mentions?.users;
    const hasEveryone = message.content?.includes('@everyone') || message.content?.includes('@here');
    const hasMentions = (mentions && mentions.size > 0) || hasEveryone;

    if (hasMentions) {
      const pingedTargets = [];
      if (hasEveryone) pingedTargets.push('@everyone / @here');
      if (mentions) {
        for (const u of mentions.values()) {
          if (u.id !== author.id) pingedTargets.push(`<@${u.id}>`);
        }
      }

      if (pingedTargets.length > 0) {
        const targetDesc = pingedTargets.slice(0, 5).join(', ') + (pingedTargets.length > 5 ? ` and ${pingedTargets.length - 5} others` : '');

        await dispatchSecurityAlert(client, {
          guild_id: guild.id,
          severity: 'LOW',
          category: 'GHOST_PING',
          title: '👻 Ghost Ping Suppressed',
          description: `User **${author.tag}** ghost-pinged ${targetDesc} in <#${message.channel.id}> and deleted the message.`,
          actor_id: author.id,
          actor_tag: author.tag,
          action_taken: 'Ghost Ping Logged & Correlated'
        });

        message.channel.send({
          embeds: [{
            color: config.branding.colorMedInt,
            title: '👻 Ghost Ping Detected',
            description: `<@${author.id}> pinged ${targetDesc} and deleted their message.`,
            footer: { text: 'SPOOFY Anti-Ghost Ping' }
          }]
        }).catch(() => {});
      }
    }
  });
}

/**
 * Handle interactive buttons with strict permission verification
 */
async function handleButtonInteraction(interaction, client) {
  const customId = interaction.customId;
  const guild = interaction.guild;
  if (!guild) return;

  // 1. Verification button
  if (customId === 'spoofy_verify_button') {
    const guildConfig = getGuildConfig(guild.id);
    const roleId = guildConfig.verification_role_id;
    if (!roleId || !guild.roles.cache.has(roleId)) {
      return interaction.reply({ content: '❌ Verification role is not configured by server administrators.', ephemeral: true });
    }

    if (interaction.member.roles.cache.has(roleId)) {
      return interaction.reply({ content: 'ℹ️ You are already verified! All server channels are already unlocked for you.', ephemeral: true });
    }

    try {
      await interaction.member.roles.add(roleId, 'SPOOFY Verification: Passed Button Gateway');

      logAuditEvent({
        guild_id: guild.id,
        event_type: 'VERIFICATION_SUCCESS',
        actor_id: interaction.user.id,
        actor_tag: interaction.user.tag,
        target_id: roleId,
        target_name: guild.roles.cache.get(roleId)?.name || 'Verified Role',
        reason: 'Member verified access via interactive gateway'
      });

      return interaction.reply({ content: '✅ **Verification Successful!** Welcome to the server. All channels have now been unlocked for you.', ephemeral: true });
    } catch (err) {
      return interaction.reply({ content: `❌ Verification failed: ${err.message}. Please contact server staff.`, ephemeral: true });
    }
  }

  // 2. Ticket creation button
  if (customId === 'spoofy_ticket_open') {
    const channelName = `ticket-${interaction.user.username.slice(0, 10)}-${interaction.user.id.slice(-4)}`;

    try {
      const channel = await guild.channels.create({
        name: channelName,
        permissionOverwrites: [
          { id: guild.id, deny: ['ViewChannel'] },
          { id: interaction.user.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'AttachFiles'] },
          { id: client.user.id, allow: ['ViewChannel', 'SendMessages', 'ManageChannels'] }
        ]
      });

      createTicket({
        guild_id: guild.id,
        channel_id: channel.id,
        creator_id: interaction.user.id,
        creator_tag: interaction.user.tag,
        category: 'Support Ticket'
      });

      await channel.send({
        content: `👋 Hello <@${interaction.user.id}>! Support staff will assist you shortly.\nClick below to close this ticket when resolved.`,
        components: [
          {
            type: 1,
            components: [
              {
                type: 2,
                customId: 'spoofy_ticket_close',
                label: '🔒 Close Ticket',
                style: 2
              }
            ]
          }
        ]
      });

      return interaction.reply({ content: `✅ Ticket created: <#${channel.id}>`, ephemeral: true });
    } catch (err) {
      return interaction.reply({ content: `❌ Failed to create ticket channel: ${err.message}`, ephemeral: true });
    }
  }

  // 3. Ticket close button (Secured: requires ticket owner or staff with ManageChannels)
  if (customId === 'spoofy_ticket_close') {
    const isStaff = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels);
    const tickets = getTickets(guild.id);
    const dbTicket = tickets.find(t => t.channel_id === interaction.channel.id);
    const isCreator = dbTicket && dbTicket.creator_id === interaction.user.id;

    if (!isStaff && !isCreator) {
      return interaction.reply({
        content: '❌ **Access Denied**: You must be the ticket creator or authorized support staff to close this ticket.',
        ephemeral: true
      });
    }

    await interaction.reply({ content: '🔒 Closing ticket channel in 5 seconds...' });
    closeTicket(interaction.channel.id, `Closed by ${interaction.user.tag}`);
    setTimeout(() => {
      interaction.channel.delete('Ticket closed').catch(() => {});
    }, 5000);
    return;
  }

  // 4. Sentinel Alert Dismiss Button (Secured: requires ManageGuild or Administrator)
  if (customId.startsWith('alert_dismiss_')) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild) && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        content: '❌ **Access Denied**: You require **Manage Server** or **Administrator** permissions to dismiss security alerts.',
        ephemeral: true
      });
    }

    const alertId = customId.replace('alert_dismiss_', '');
    updateAlertStatus(alertId, 'DISMISSED');
    return interaction.reply({ content: `🛡️ Security incident alert \`${alertId}\` dismissed by <@${interaction.user.id}>.`, ephemeral: false });
  }

  // 5. Sentinel Alert Ban Button (Secured: requires BanMembers or Administrator)
  if (customId.startsWith('alert_ban_')) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers) && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        content: '❌ **Access Denied**: You require **Ban Members** or **Administrator** permissions to trigger defensive bans.',
        ephemeral: true
      });
    }

    const alertId = customId.replace('alert_ban_', '');
    const db = getDb();
    const alert = db.prepare('SELECT * FROM security_alerts WHERE id = ?').get(alertId);

    if (alert && alert.actor_id) {
      try {
        await guild.members.ban(alert.actor_id, {
          reason: `SPOOFY Sentinel: Defensive ban requested via alert ${alertId} by ${interaction.user.tag}`
        });

        addModerationCase({
          guild_id: guild.id,
          case_type: 'BAN',
          user_id: alert.actor_id,
          user_tag: alert.actor_tag,
          moderator_id: interaction.user.id,
          moderator_tag: interaction.user.tag,
          reason: `Defensive response to Sentinel incident ${alertId}`
        });

        return interaction.reply({
          content: `⚔️ Successfully executed defensive ban on hostile actor <@${alert.actor_id}> (${alert.actor_tag || alert.actor_id}) for incident \`${alertId}\`.`,
          ephemeral: false
        });
      } catch (err) {
        return interaction.reply({ content: `❌ Failed to execute defensive ban: ${err.message}`, ephemeral: true });
      }
    }

    return interaction.reply({ content: `⚠️ Could not locate hostile actor details for incident \`${alertId}\`.`, ephemeral: true });
  }

  // 6. Sentinel Alert Rollback Button (Secured: strictly Owner only)
  if (customId.startsWith('alert_rollback_')) {
    const isOwner = interaction.user.id === guild.ownerId || interaction.user.id === config.botOwnerId;
    if (!isOwner) {
      return interaction.reply({
        content: '❌ **Owner Protection**: Server restoration operations strictly require the Server Owner.',
        ephemeral: true
      });
    }

    const alertId = customId.replace('alert_rollback_', '');
    return interaction.reply({
      content: `🔄 Rollback requested for incident \`${alertId}\`. Please use \`/backup restore <id>\` to review snapshot details and safely execute restoration.`,
      ephemeral: true
    });
  }
}