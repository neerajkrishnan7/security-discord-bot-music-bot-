import { Client, GatewayIntentBits, Partials, Collection } from 'discord.js';
import { config } from '../config.js';
import { registerGatewayEvents } from './events/index.js';
import { deploySlashCommands } from './deployCommands.js';

// Import commands
import { shieldCommand } from './commands/shield.js';
import { sentinelCommand } from './commands/sentinel.js';
import { backupCommand } from './commands/backup.js';
import { lockdownCommand, unlockdownCommand } from './commands/lockdown.js';
import { lockCommand, unlockCommand } from './commands/lock.js';
import { panicCommand } from './commands/panic.js';
import { quarantineCommand } from './commands/quarantine.js';
import { antiraidCommand } from './commands/antiraid.js';
import { antialtCommand } from './commands/antialt.js';
import { automodCommand } from './commands/automod.js';
import { sweeperCommand } from './commands/sweeper.js';
import { scannerCommand } from './commands/scanner.js';
import { modCommand } from './commands/mod.js';
import { configCommand } from './commands/config.js';
import { whitelistCommand } from './commands/whitelist.js';
import { verifyCommand } from './commands/verify.js';
import { ticketCommand } from './commands/ticket.js';
import { helpCommand } from './commands/help.js';
import { musicCommand } from './commands/music.js';
import { pingCommand, serverinfoCommand, userinfoCommand } from './commands/utility.js';

export function createBotClient() {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildModeration,
      GatewayIntentBits.GuildIntegrations,
      GatewayIntentBits.GuildWebhooks,
      GatewayIntentBits.GuildInvites,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.MessageContent
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember, Partials.User]
  });

  const commands = new Collection();
  const commandList = [
    shieldCommand,
    sentinelCommand,
    backupCommand,
    lockdownCommand,
    unlockdownCommand,
    lockCommand,
    unlockCommand,
    panicCommand,
    quarantineCommand,
    antiraidCommand,
    antialtCommand,
    automodCommand,
    sweeperCommand,
    configCommand,
    whitelistCommand,
    scannerCommand,
    modCommand,
    verifyCommand,
    ticketCommand,
    helpCommand,
    musicCommand,
    pingCommand,
    serverinfoCommand,
    userinfoCommand
  ];

  for (const cmd of commandList) {
    commands.set(cmd.data.name, cmd);
  }

  // Register Gateway Events
  registerGatewayEvents(client, commands);

  // Health & Gateway Resilience Listeners
  client.on('error', (err) => {
    console.error('[Discord Client] Uncaught error:', err.message);
  });

  client.on('shardError', (error, shardId) => {
    console.error(`[Discord Gateway] Shard ${shardId} error:`, error.message);
  });

  client.on('shardDisconnect', (event, shardId) => {
    console.warn(`[Discord Gateway] Shard ${shardId} disconnected (${event.code}): ${event.reason}`);
  });

  client.on('shardReconnecting', (shardId) => {
    console.log(`[Discord Gateway] Shard ${shardId} attempting reconnection...`);
  });

  client.on('shardResume', (shardId, replayedEvents) => {
    console.log(`[Discord Gateway] Shard ${shardId} resumed! Replayed ${replayedEvents} events.`);
  });

  return { client, commands, commandList };
}

export async function startBot(client, commandList) {
  if (!config.token || config.token === 'your_bot_token_here') {
    console.warn('\n⚠️ [SPOOFY Bot] DISCORD_TOKEN is not configured in .env.');
    console.warn('   The bot is running in SIMULATOR & DASHBOARD mode.');
    console.warn('   You can fully test the Dashboard, Anti-Nuke Simulator, Sentinel Alerts, and API.\n');
    return false;
  }

  try {
    console.log('[Discord] Connecting to Discord Gateway...');
    await client.login(config.token);
    await deploySlashCommands(commandList);
    return true;
  } catch (err) {
    console.error('[Discord] Failed to connect to Discord Gateway:', err.message);
    return false;
  }
}
