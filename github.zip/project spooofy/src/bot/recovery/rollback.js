import { ChannelType, PermissionFlagsBits, PermissionsBitField } from 'discord.js';
import { getBackup } from '../../database/backups.js';
import { logAuditEvent } from '../../database/moderation.js';

/**
 * Generate a recovery preview comparing current guild state to a backup.
 */
export async function generateRecoveryPreview(guild, backupId) {
  const backup = getBackup(backupId);
  if (!backup) throw new Error('Backup not found');

  const currentChannelNames = new Set(guild.channels.cache.map(c => c.name));
  const currentRoleNames = new Set(guild.roles.cache.map(r => r.name));

  const missingChannels = backup.channels.filter(c => !currentChannelNames.has(c.name));
  const missingRoles = backup.roles.filter(r => !r.isEveryone && !currentRoleNames.has(r.name));

  const settingsDiff = [];
  if (guild.name !== backup.settings.name) {
    settingsDiff.push(`Name: "${guild.name}" -> "${backup.settings.name}"`);
  }
  if (guild.verificationLevel !== backup.settings.verificationLevel) {
    settingsDiff.push(`Verification Level: ${guild.verificationLevel} -> ${backup.settings.verificationLevel}`);
  }

  return {
    backupId: backup.id,
    backupName: backup.backup_name,
    createdAt: backup.created_at,
    totalBackupChannels: backup.channels.length,
    missingChannelsCount: missingChannels.length,
    missingChannelsList: missingChannels.slice(0, 15).map(c => c.name),
    totalBackupRoles: backup.roles.length,
    missingRolesCount: missingRoles.length,
    missingRolesList: missingRoles.slice(0, 15).map(r => r.name),
    settingsDiff
  };
}

/**
 * Execute safe recovery from a snapshot.
 * Critical safety rule: Never restore dangerous Administrator permissions blindly onto non-owner roles.
 */
export async function executeSafeRestore(guild, backupId, options = { channels: true, roles: true, settings: true }) {
  const backup = getBackup(backupId);
  if (!backup) throw new Error('Backup not found');

  const results = {
    channelsCreated: 0,
    rolesCreated: 0,
    settingsRestored: false,
    errors: []
  };

  const me = guild.members.me;
  if (!me) throw new Error('Bot member could not be resolved');

  // 1. Restore Roles (if enabled and bot has ManageRoles)
  const roleIdMap = new Map(); // Old ID -> New ID
  if (options.roles && me.permissions.has(PermissionFlagsBits.ManageRoles)) {
    const sortedRoles = [...backup.roles].reverse(); // Lower roles first

    for (const rData of sortedRoles) {
      if (rData.isEveryone) {
        roleIdMap.set(rData.id, guild.id);
        continue;
      }

      // Check if role already exists by name
      const existing = guild.roles.cache.find(r => r.name === rData.name);
      if (existing) {
        roleIdMap.set(rData.id, existing.id);
        continue;
      }

      try {
        // Sanitize permissions: Strip Administrator & ManageGuild for security unless owner confirmed
        let perms = BigInt(rData.permissions);
        const dangerousMask = PermissionFlagsBits.Administrator | PermissionFlagsBits.ManageGuild;
        perms = perms & ~dangerousMask; // Safe sanitize

        const createdRole = await guild.roles.create({
          name: rData.name,
          color: rData.color,
          hoist: rData.hoist,
          permissions: perms,
          mentionable: rData.mentionable,
          reason: `SPOOFY Recovery: Restoring from snapshot ${backup.backup_name}`
        });

        roleIdMap.set(rData.id, createdRole.id);
        results.rolesCreated++;
      } catch (err) {
        results.errors.push(`Failed to create role ${rData.name}: ${err.message}`);
      }
    }
  }

  // 2. Restore Channels (Categories first, then child channels)
  if (options.channels && me.permissions.has(PermissionFlagsBits.ManageChannels)) {
    const categoryIdMap = new Map(); // Old Category ID -> New Category ID

    // Phase 2a: Restore Categories
    const categories = backup.channels.filter(c => c.type === ChannelType.GuildCategory);
    for (const catData of categories) {
      const existing = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name === catData.name);
      if (existing) {
        categoryIdMap.set(catData.id, existing.id);
        continue;
      }

      try {
        const createdCat = await guild.channels.create({
          name: catData.name,
          type: ChannelType.GuildCategory,
          position: catData.position,
          reason: `SPOOFY Recovery: Restoring category from ${backup.backup_name}`
        });
        categoryIdMap.set(catData.id, createdCat.id);
        results.channelsCreated++;
      } catch (err) {
        results.errors.push(`Failed to create category ${catData.name}: ${err.message}`);
      }
    }

    // Phase 2b: Restore Child Channels
    const nonCategories = backup.channels.filter(c => c.type !== ChannelType.GuildCategory);
    for (const chData of nonCategories) {
      const existing = guild.channels.cache.find(c => c.name === chData.name && c.type === chData.type);
      if (existing) continue;

      try {
        const parentId = chData.parentId ? categoryIdMap.get(chData.parentId) : null;

        // Build permission overwrites mapping
        const mappedOverwrites = [];
        if (Array.isArray(chData.permissionOverwrites)) {
          for (const ow of chData.permissionOverwrites) {
            const mappedTargetId = roleIdMap.get(ow.id) || ow.id;
            mappedOverwrites.push({
              id: mappedTargetId,
              type: ow.type,
              allow: BigInt(ow.allow),
              deny: BigInt(ow.deny)
            });
          }
        }

        await guild.channels.create({
          name: chData.name,
          type: chData.type,
          parent: parentId,
          topic: chData.topic,
          nsfw: chData.nsfw,
          bitrate: chData.bitrate,
          userLimit: chData.userLimit,
          rateLimitPerUser: chData.rateLimitPerUser,
          permissionOverwrites: mappedOverwrites,
          reason: `SPOOFY Recovery: Restoring channel from ${backup.backup_name}`
        });

        results.channelsCreated++;
      } catch (err) {
        results.errors.push(`Failed to create channel ${chData.name}: ${err.message}`);
      }
    }
  }

  // 3. Restore Settings
  if (options.settings && me.permissions.has(PermissionFlagsBits.ManageGuild)) {
    try {
      if (backup.settings.name && guild.name !== backup.settings.name) {
        await guild.setName(backup.settings.name, 'SPOOFY Recovery: Restoring server name');
      }
      if (backup.settings.verificationLevel !== undefined) {
        await guild.setVerificationLevel(backup.settings.verificationLevel, 'SPOOFY Recovery: Restoring verification level');
      }
      results.settingsRestored = true;
    } catch (err) {
      results.errors.push(`Failed to restore settings: ${err.message}`);
    }
  }

  logAuditEvent({
    guild_id: guild.id,
    event_type: 'RECOVERY_RESTORE',
    actor_id: me.id,
    actor_tag: 'SPOOFY Recovery',
    target_name: backup.backup_name,
    reason: `Restored ${results.channelsCreated} channels, ${results.rolesCreated} roles`
  });

  return results;
}
