import { ChannelType, PermissionFlagsBits } from 'discord.js';
import { saveBackup } from '../../database/backups.js';

/**
 * Capture full snapshot of a Discord guild's channels, roles, and settings.
 */
export async function captureGuildSnapshot(guild, creator = null, backupName = null) {
  if (!guild) throw new Error('Guild not available for snapshot');

  // 1. Roles snapshot (sorted by position)
  const roles = [];
  const guildRoles = Array.from(guild.roles.cache.values()).sort((a, b) => b.position - a.position);

  for (const role of guildRoles) {
    if (role.managed) continue; // Skip bot-managed roles
    roles.push({
      id: role.id,
      name: role.name,
      color: role.color,
      hoist: role.hoist,
      position: role.position,
      permissions: role.permissions.bitfield.toString(),
      mentionable: role.mentionable,
      isEveryone: role.id === guild.id
    });
  }

  // 2. Channels snapshot (categories first, then children)
  const channels = [];
  const guildChannels = Array.from(guild.channels.cache.values());

  for (const channel of guildChannels) {
    if (channel.isThread()) continue;

    const overwrites = [];
    for (const [id, ow] of channel.permissionOverwrites.cache.entries()) {
      overwrites.push({
        id: ow.id,
        type: ow.type, // 0 = role, 1 = member
        allow: ow.allow.bitfield.toString(),
        deny: ow.deny.bitfield.toString()
      });
    }

    channels.push({
      id: channel.id,
      name: channel.name,
      type: channel.type,
      parentId: channel.parentId,
      position: channel.position,
      topic: channel.topic || null,
      nsfw: channel.nsfw || false,
      bitrate: channel.bitrate || undefined,
      userLimit: channel.userLimit || undefined,
      rateLimitPerUser: channel.rateLimitPerUser || 0,
      permissionOverwrites: overwrites
    });
  }

  // 3. Settings snapshot
  const settings = {
    name: guild.name,
    icon: guild.iconURL(),
    verificationLevel: guild.verificationLevel,
    explicitContentFilter: guild.explicitContentFilter,
    defaultMessageNotifications: guild.defaultMessageNotifications,
    afkTimeout: guild.afkTimeout,
    afkChannelId: guild.afkChannelId
  };

  const name = backupName || `Snapshot_${new Date().toISOString().replace(/[:.]/g, '-')}`;
  const creatorId = creator?.id || 'system';
  const creatorTag = creator?.tag || 'SPOOFY Auto-Backup';

  const backup = saveBackup({
    guild_id: guild.id,
    backup_name: name,
    creator_id: creatorId,
    creator_tag: creatorTag,
    channels,
    roles,
    settings
  });

  return backup;
}
