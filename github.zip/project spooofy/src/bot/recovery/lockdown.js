import { PermissionFlagsBits, ChannelType } from 'discord.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { logAuditEvent } from '../../database/moderation.js';

const activeLockdownTimers = new Map();

/**
 * Enable Emergency Server Lockdown
 */
export async function enableEmergencyLockdown(guild, client, { durationMinutes = 15, reason = 'Emergency Security Lockdown' } = {}) {
  const me = guild.members.me;
  if (!me || !me.permissions.has(PermissionFlagsBits.ManageRoles) && !me.permissions.has(PermissionFlagsBits.ManageChannels)) {
    throw new Error('Bot lacks ManageRoles or ManageChannels permission to initiate lockdown');
  }

  const everyoneRole = guild.roles.everyone;
  const lockedChannels = [];

  // Deny permissions for @everyone across text & voice channels
  const lockPerms = {
    SendMessages: false,
    SendMessagesInThreads: false,
    CreatePublicThreads: false,
    CreatePrivateThreads: false,
    AddReactions: false,
    Speak: false
  };

  for (const channel of guild.channels.cache.values()) {
    if (channel.isThread()) continue;
    if (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildAnnouncement) {
      try {
        await channel.permissionOverwrites.edit(everyoneRole, lockPerms, { reason });
        lockedChannels.push(channel.name);
      } catch (err) {
        // Continue with other channels if one fails
      }
    }
  }

  const expiresAt = durationMinutes > 0 ? Math.floor(Date.now() / 1000) + (durationMinutes * 60) : 0;

  updateGuildConfig(guild.id, {
    lockdown_active: 1,
    lockdown_expires_at: expiresAt
  });

  // Schedule auto-unlock timer if duration is specified
  if (durationMinutes > 0) {
    if (activeLockdownTimers.has(guild.id)) {
      clearTimeout(activeLockdownTimers.get(guild.id));
    }

    const timer = setTimeout(async () => {
      console.log(`[Lockdown] Auto-unlock timer expired for guild ${guild.name} (${guild.id})`);
      await disableEmergencyLockdown(guild, client, { reason: 'Lockdown duration expired (Auto-Unlock)' }).catch(err => {
        console.error('[Lockdown] Failed auto-unlock:', err.message);
      });
    }, durationMinutes * 60 * 1000);

    activeLockdownTimers.set(guild.id, timer);
  }

  logAuditEvent({
    guild_id: guild.id,
    event_type: 'EMERGENCY_LOCKDOWN_ON',
    actor_id: me.id,
    actor_tag: 'SPOOFY Shield',
    reason: `${reason} (${durationMinutes}m duration)`
  });

  return {
    lockedChannelsCount: lockedChannels.length,
    durationMinutes,
    expiresAt
  };
}

/**
 * Disable Emergency Server Lockdown
 */
export async function disableEmergencyLockdown(guild, client, { reason = 'Emergency lockdown lifted' } = {}) {
  const me = guild.members.me;
  if (!me) throw new Error('Bot member not resolved');

  const everyoneRole = guild.roles.everyone;
  const unlockedChannels = [];

  // Reset neutral permissions for @everyone (null resets the overwrite)
  const unlockPerms = {
    SendMessages: null,
    SendMessagesInThreads: null,
    CreatePublicThreads: null,
    CreatePrivateThreads: null,
    AddReactions: null,
    Speak: null
  };

  for (const channel of guild.channels.cache.values()) {
    if (channel.isThread()) continue;
    if (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildAnnouncement) {
      try {
        await channel.permissionOverwrites.edit(everyoneRole, unlockPerms, { reason });
        unlockedChannels.push(channel.name);
      } catch (err) {
        // Continue
      }
    }
  }

  // Clear timer
  if (activeLockdownTimers.has(guild.id)) {
    clearTimeout(activeLockdownTimers.get(guild.id));
    activeLockdownTimers.delete(guild.id);
  }

  updateGuildConfig(guild.id, {
    lockdown_active: 0,
    lockdown_expires_at: 0
  });

  logAuditEvent({
    guild_id: guild.id,
    event_type: 'EMERGENCY_LOCKDOWN_OFF',
    actor_id: me.id,
    actor_tag: 'SPOOFY Shield',
    reason
  });

  await dispatchSecurityAlert(client, {
    guild_id: guild.id,
    severity: 'LOW',
    category: 'ANTI_RAID',
    title: '🟢 Server Lockdown Deactivated',
    description: `Normal channel permissions have been restored across **${unlockedChannels.length} channels**. Reason: ${reason}.`,
    action_taken: 'Lockdown Lifted'
  });

  return {
    unlockedChannelsCount: unlockedChannels.length
  };
}
