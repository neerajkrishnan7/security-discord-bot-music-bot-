import { actionTracker } from './actionTracker.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { executePunishment } from './antiNuke.js';
import { enableEmergencyLockdown } from '../recovery/lockdown.js';
import { config } from '../../config.js';

/**
 * Handle new member join for Anti-Raid & Account Age verification.
 */
export async function handleMemberJoin(member, client) {
  const guild = member.guild;
  const guildConfig = getGuildConfig(guild.id);

  if (!guildConfig.shield_enabled) return;

  const now = Date.now();
  const accountCreated = member.user.createdTimestamp;
  const accountAgeDays = Math.floor((now - accountCreated) / (1000 * 60 * 60 * 24));

  // 1. Account Age Check
  if (accountAgeDays < (guildConfig.account_age_min_days || 3)) {
    console.log(`[AntiRaid] Young account detected: ${member.user.tag} (Age: ${accountAgeDays} days)`);

    const action = guildConfig.account_age_action || 'quarantine';
    let actionTaken = 'Monitored';

    if (action === 'kick') {
      actionTaken = await executePunishment(guild, member, 'kick', `SPOOFY Shield: Account age below threshold (${accountAgeDays}d < ${guildConfig.account_age_min_days}d)`);
    } else if (action === 'quarantine') {
      actionTaken = await executePunishment(guild, member, 'quarantine', `SPOOFY Shield: Young account verification quarantine (${accountAgeDays}d)`);
    }

    await dispatchSecurityAlert(client, {
      guild_id: guild.id,
      severity: 'MEDIUM',
      category: 'ANTI_RAID',
      title: 'Suspicious / Young Account Detected',
      description: `New member joined with an account created only **${accountAgeDays} days ago** (Threshold: ${guildConfig.account_age_min_days} days).`,
      actor_id: member.id,
      actor_tag: member.user.tag,
      action_taken: actionTaken
    });
  }

  // 2. Mass Join Detection (Raid Detection)
  if (guildConfig.anti_raid_enabled) {
    // Record join under pseudo-actor 'system_joins'
    const joinWindowSeconds = 12;
    const joinThreshold = 5; // 5 joins in 12s
    const joinCount = actionTracker.recordAction(guild.id, 'guild_joins', 'join', joinWindowSeconds);

    if (joinCount >= joinThreshold) {
      console.warn(`[AntiRaid] RAID DETECTED in ${guild.name}! ${joinCount} joins in ${joinWindowSeconds}s.`);

      // Enable emergency lockdown
      const lockdownMinutes = 15;
      await enableEmergencyLockdown(guild, client, {
        durationMinutes: lockdownMinutes,
        reason: `SPOOFY Shield Auto-Raid Defense: ${joinCount} joins in ${joinWindowSeconds}s`
      });

      // Dispatch CRITICAL alert
      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'CRITICAL',
        category: 'ANTI_RAID',
        title: '🚨 SERVER RAID DETECTED — EMERGENCY LOCKDOWN ACTIVATED',
        description: `Sudden join wave detected (${joinCount} members within ${joinWindowSeconds}s). Automatic server lockdown activated for ${lockdownMinutes} minutes to protect community.`,
        action_taken: `Activated Server Lockdown (${lockdownMinutes}m auto-unlock)`
      });

      // Reset count so we don't spam repeated locks
      actionTracker.resetActor(guild.id, 'guild_joins', 'join');
    }
  }
}
