import { actionTracker } from './actionTracker.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { isTrusted } from '../../database/trustedAdmins.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { addModerationCase, getWarningCount } from '../../database/moderation.js';
import { config } from '../../config.js';

// Suspicious phishing, IP grabbers, and scam domains
const PHISHING_PATTERNS = [
  /discorcl\./i,
  /dlscord\./i,
  /discord-(nitro|gift|drop|promo|giveaway)\./i,
  /discordnitro\./i,
  /steamcommunnity\./i,
  /steamcommunity-trade\./i,
  /roblox-gift\./i,
  /free-nitro/i,
  /claim-nitro/i,
  /grabify\.link/i,
  /iplogger\.(org|com|ru)/i,
  /2no\.co/i,
  /yip\.su/i,
  /blasze\.com/i,
  /ps3cfw\.com/i,
  /shorte\.st/i,
  /trib\.al/i
];

const SUSPICIOUS_EXTENSIONS = [
  '.exe', '.scr', '.vbs', '.bat', '.cmd', '.pif', '.jar', '.ps1'
];

const INVITE_REGEX = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li)|discord(app)?\.com\/invite)\/[a-zA-Z0-9]+/i;
const DISCORD_WEBHOOK_REGEX = /https:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+/i;
const DISCORD_TOKEN_REGEX = /[MN][A-Za-z\d]{23,26}\.[A-Za-z\d-_]{6}\.[A-Za-z\d-_]{27,}/;
const ANY_LINK_REGEX = /https?:\/\/[^\s<]+[^<.,:;"')\]\s]/i;

export async function handleChatMessage(message, client) {
  if (!message.guild || message.author.bot) return;

  const guild = message.guild;
  const author = message.author;
  const member = message.member;

  // Owner exemption
  if (author.id === guild.ownerId || (config.botOwnerId && author.id === config.botOwnerId)) {
    return;
  }

  // Check trusted
  const roleIds = member ? Array.from(member.roles.cache.keys()) : [];
  if (isTrusted(guild.id, author.id, roleIds)) {
    return;
  }

  const guildConfig = getGuildConfig(guild.id);
  if (!guildConfig.shield_enabled) return;

  const rawContent = message.content || '';
  // Strip zero-width invisible characters used by attackers to evade filters
  const content = rawContent.replace(/[\u200B-\u200D\uFEFF]/g, '');

  // 0. Anti-Token & Webhook Leak Protection
  if (guildConfig.anti_token_leak_enabled) {
    const isWebhookLeak = DISCORD_WEBHOOK_REGEX.test(content);
    const isTokenLeak = DISCORD_TOKEN_REGEX.test(content);

    if (isWebhookLeak || isTokenLeak) {
      if (message.deletable) await message.delete().catch(() => {});

      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'CRITICAL',
        category: 'CREDENTIAL_LEAK',
        title: '🔑 Discord Token / Webhook Leak Suppressed',
        description: `Member **${author.tag}** posted sensitive Discord API credentials or webhook URL in <#${message.channel.id}>. Message deleted immediately to prevent server hijacking.`,
        actor_id: author.id,
        actor_tag: author.tag,
        action_taken: 'Message Deleted & Incident Alerted'
      });

      author.send(`⚠️ **Security Notice**: You posted a Discord webhook or token in **${guild.name}**. SPOOFY deleted it immediately to protect your server and account from being hijacked. Please regenerate this credential immediately!`).catch(() => {});
      return;
    }
  }

  // 0.1 Strict Channel Link Protection & Cross-Channel Link Raid Detection
  const hasLink = ANY_LINK_REGEX.test(content);
  if (hasLink) {
    let strictChannels = [];
    try {
      strictChannels = JSON.parse(guildConfig.strict_link_ban_channel_ids || '[]');
    } catch {}

    // Check 1: Strict Channel Rule (Instant Ban for posting links in this designated channel)
    const isStrictChannel = Array.isArray(strictChannels) && strictChannels.includes(message.channel.id);
    if (isStrictChannel) {
      if (message.deletable) await message.delete().catch(() => {});

      let banStatus = 'Failed to ban';
      if (guild.members.me?.permissions.has('BanMembers') && (!member || member.bannable)) {
        await guild.members.ban(author.id, {
          deleteMessageSeconds: 86400,
          reason: 'Posting unwanted link in server'
        }).catch(err => { banStatus = `Ban failed: ${err.message}`; });
        banStatus = 'Banned Member (Strict Link Channel)';
      }

      addModerationCase({
        guild_id: guild.id,
        case_type: 'BAN',
        user_id: author.id,
        user_tag: author.tag,
        moderator_id: client.user.id,
        moderator_tag: 'SPOOFY Strict AutoMod',
        reason: 'Posting unwanted link in server'
      });

      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'CRITICAL',
        category: 'STRICT_LINK_VIOLATION',
        title: '🚨 Unwanted Link Detected — Member Banned',
        description: `Member **${author.tag}** (\`${author.id}\`) posted an unauthorized link in strictly protected channel <#${message.channel.id}>. Link deleted and member permanently banned.`,
        actor_id: author.id,
        actor_tag: author.tag,
        action_taken: banStatus
      });

      return;
    }

    // Check 2: Cross-Channel Link Raid Flood (Posting links across 3 or more channels rapidly)
    const uniqueChannels = actionTracker.recordChannelAction(guild.id, author.id, 'cross_channel_link', message.channel.id, 15);
    if (uniqueChannels >= 3) {
      if (message.deletable) await message.delete().catch(() => {});

      let raidBanStatus = 'Failed to ban';
      if (guild.members.me?.permissions.has('BanMembers') && (!member || member.bannable)) {
        await guild.members.ban(author.id, {
          deleteMessageSeconds: 86400,
          reason: 'Posting unwanted link in server (Cross-channel link spam detected)'
        }).catch(err => { raidBanStatus = `Ban failed: ${err.message}`; });
        raidBanStatus = `Banned Member (Cross-Channel Link Raid across ${uniqueChannels} channels)`;
      }

      addModerationCase({
        guild_id: guild.id,
        case_type: 'BAN',
        user_id: author.id,
        user_tag: author.tag,
        moderator_id: client.user.id,
        moderator_tag: 'SPOOFY Raid Shield',
        reason: 'Posting unwanted link in server (Cross-channel link spam detected)'
      });

      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'CRITICAL',
        category: 'CROSS_CHANNEL_RAID',
        title: '🚨 Cross-Channel Link Raid Suppressed — Member Banned',
        description: `Member **${author.tag}** (\`${author.id}\`) posted links across **${uniqueChannels} channels** within 15 seconds. Messages deleted and user permanently banned.`,
        actor_id: author.id,
        actor_tag: author.tag,
        action_taken: raidBanStatus
      });

      return;
    }
  }

  // 1. Anti-Everyone / Mass Mentions
  if (guildConfig.anti_everyone_enabled) {
    const hasEveryone = content.includes('@everyone') || content.includes('@here');
    const mentionCount = message.mentions.users.size;

    if (hasEveryone || mentionCount >= 5) {
      if (message.deletable) await message.delete().catch(() => {});

      if (member && guild.members.me?.permissions.has('ModerateMembers') && member.roles.highest.position < guild.members.me.roles.highest.position) {
        await member.timeout(15 * 60 * 1000, 'SPOOFY Shield: Unauthorized mass mentions').catch(() => {});
      }

      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'HIGH',
        category: 'ANTI_EVERYONE',
        title: 'Mass Mention / @everyone Suppressed',
        description: `User **${author.tag}** attempted mass mention in <#${message.channel.id}>. Message deleted & user timed out for 15 minutes.`,
        actor_id: author.id,
        actor_tag: author.tag,
        action_taken: 'Message Deleted & 15m Timeout'
      });
      return;
    }
  }

  // 2. Anti-Phishing, IP Loggers & Malicious Attachments
  if (guildConfig.anti_phishing_enabled) {
    const isPhishing = PHISHING_PATTERNS.some(regex => regex.test(content));
    let hasSuspiciousFile = false;
    let badFilename = '';

    for (const attachment of message.attachments.values()) {
      const lower = attachment.name.toLowerCase();
      if (SUSPICIOUS_EXTENSIONS.some(ext => lower.endsWith(ext))) {
        hasSuspiciousFile = true;
        badFilename = attachment.name;
        break;
      }
    }

    if (isPhishing || hasSuspiciousFile) {
      if (message.deletable) await message.delete().catch(() => {});

      if (member && guild.members.me?.permissions.has('ModerateMembers') && member.roles.highest.position < guild.members.me.roles.highest.position) {
        await member.timeout(60 * 60 * 1000, 'SPOOFY Shield: Malicious link or attachment').catch(() => {});
      }

      const threatType = isPhishing ? 'Phishing / IP Logger Link' : `Suspicious Executable (${badFilename})`;
      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'CRITICAL',
        category: 'ANTI_PHISHING',
        title: `${threatType} Blocked`,
        description: `Malicious payload detected from **${author.tag}** in <#${message.channel.id}>. Message deleted & member timed out for 1 hour.`,
        actor_id: author.id,
        actor_tag: author.tag,
        action_taken: 'Message Deleted & 1h Timeout'
      });
      return;
    }
  }

  // 3. Anti-Invite
  if (guildConfig.anti_invite_enabled) {
    if (INVITE_REGEX.test(content)) {
      if (message.deletable) await message.delete().catch(() => {});

      addModerationCase({
        guild_id: guild.id,
        case_type: 'WARN',
        user_id: author.id,
        user_tag: author.tag,
        moderator_id: client.user.id,
        moderator_tag: 'SPOOFY Shield Auto',
        reason: 'AutoMod: Unauthorized Discord invite link'
      });

      const totalWarns = getWarningCount(guild.id, author.id);
      if (totalWarns >= 3 && member && member.manageable) {
        await member.timeout(10 * 60 * 1000, 'AutoMod: Reached 3 warnings for invite spam').catch(() => {});
      }

      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'MEDIUM',
        category: 'ANTI_INVITE',
        title: 'Unauthorized Discord Invite Removed',
        description: `Deleted unauthorized invite link sent by **${author.tag}** in <#${message.channel.id}> (Warning #${totalWarns}).`,
        actor_id: author.id,
        actor_tag: author.tag,
        action_taken: 'Message Deleted & Member Warned'
      });
      return;
    }
  }

  // 4. Anti-Spam (Rapid chat message frequency)
  if (guildConfig.anti_spam_enabled) {
    const spamCount = actionTracker.recordAction(guild.id, author.id, 'chat_spam', 5);
    if (spamCount >= 5) {
      if (message.deletable) await message.delete().catch(() => {});

      if (member && guild.members.me?.permissions.has('ModerateMembers') && member.roles.highest.position < guild.members.me.roles.highest.position) {
        await member.timeout(5 * 60 * 1000, 'SPOOFY Shield: Rapid chat flooding').catch(() => {});
      }

      actionTracker.resetActor(guild.id, author.id, 'chat_spam');

      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'MEDIUM',
        category: 'ANTI_SPAM',
        title: 'Rapid Chat Spam Suppressed',
        description: `Member **${author.tag}** exceeded chat velocity limits in <#${message.channel.id}>. Message deleted & timed out for 5 minutes.`,
        actor_id: author.id,
        actor_tag: author.tag,
        action_taken: 'Message Deleted & 5m Timeout'
      });
    }
  }
}