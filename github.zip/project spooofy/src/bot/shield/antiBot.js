import { AuditLogEvent } from 'discord.js';
import { findAuditLogEntry } from '../sentinel/auditLogger.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { isTrusted } from '../../database/trustedAdmins.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { executePunishment } from './antiNuke.js';
import { config } from '../../config.js';

export async function handleBotAdd(member, client) {
  if (!member.user.bot) return;

  const guild = member.guild;
  const guildConfig = getGuildConfig(guild.id);

  if (!guildConfig.shield_enabled || !guildConfig.anti_bot_enabled) return;

  console.log(`[AntiBot] New bot joined: ${member.user.tag} (${member.id})`);

  // Query audit logs to identify who invited this bot
  const logEntry = await findAuditLogEntry(guild, AuditLogEvent.BotAdd, member.id, 10000, 3);
  const inviter = logEntry?.executor;

  if (inviter) {
    // Check owner exemption
    if (inviter.id === guild.ownerId || (config.botOwnerId && inviter.id === config.botOwnerId)) {
      console.log(`[AntiBot] Bot invited by guild owner (${inviter.tag}) - Allowed.`);
      return;
    }

    // Check trusted status
    const inviterMember = await guild.members.fetch(inviter.id).catch(() => null);
    const roleIds = inviterMember ? Array.from(inviterMember.roles.cache.keys()) : [];

    if (isTrusted(guild.id, inviter.id, roleIds)) {
      console.log(`[AntiBot] Bot invited by trusted admin (${inviter.tag}) - Allowed.`);
      return;
    }

    // UNAUTHORIZED BOT ADDITION DETECTED!
    console.warn(`[AntiBot] UNAUTHORIZED BOT ADDED by ${inviter.tag}! Executing quarantine defense.`);

    // 1. Kick/Ban the rogue bot immediately
    let botAction = 'Failed to remove bot';
    if (guild.members.me?.permissions.has('KickMembers')) {
      await member.kick('SPOOFY Anti-Bot: Unauthorized bot addition');
      botAction = 'Kicked Rogue Bot';
    } else if (guild.members.me?.permissions.has('BanMembers')) {
      await member.ban({ reason: 'SPOOFY Anti-Bot: Unauthorized bot addition' });
      botAction = 'Banned Rogue Bot';
    }

    // 2. Punish the inviter (strip roles or quarantine)
    let inviterAction = 'None';
    if (inviterMember) {
      inviterAction = await executePunishment(
        guild,
        inviterMember,
        'strip_roles',
        `SPOOFY Anti-Bot: Added unauthorized bot (${member.user.tag})`
      );
    }

    // 3. Dispatch CRITICAL alert
    await dispatchSecurityAlert(client, {
      guild_id: guild.id,
      severity: 'CRITICAL',
      category: 'ANTI_BOT',
      title: '🚨 UNAUTHORIZED BOT ADDITION PREVENTED',
      description: `User **${inviter.tag}** added bot **${member.user.tag}** without owner authorization. Rogue bot was eliminated and inviter permissions stripped.`,
      actor_id: inviter.id,
      actor_tag: inviter.tag,
      target_type: 'Bot',
      target_id: member.id,
      target_name: member.user.tag,
      action_taken: `${botAction} & ${inviterAction}`
    });
  } else {
    // If audit log was not immediately available, warn and quarantine the bot
    console.warn(`[AntiBot] Could not attribute inviter for bot ${member.user.tag}. Quarantining.`);
    if (guild.members.me?.permissions.has('KickMembers')) {
      await member.kick('SPOOFY Anti-Bot: Unauthorized unverified bot');
    }
  }
}
