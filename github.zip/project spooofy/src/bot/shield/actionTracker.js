/**
 * SPOOFY Action Tracker
 * In-memory sliding-window counter for tracking user actions and detecting thresholds.
 */
class ActionTracker {
  constructor() {
    // Key: `${guildId}:${actorId}:${actionType}` -> Array of timestamps (ms)
    this.actionHistory = new Map();
    // Periodic sweep every 5 minutes to prevent memory leaks
    setInterval(() => this.cleanup(), 5 * 60 * 1000);
  }

  /**
   * Record an action and return current count in the sliding window.
   */
  recordAction(guildId, actorId, actionType, windowSeconds = 10) {
    const key = `${guildId}:${actorId}:${actionType}`;
    const now = Date.now();
    const windowMs = windowSeconds * 1000;

    let timestamps = this.actionHistory.get(key) || [];
    // Filter out entries outside current sliding window
    timestamps = timestamps.filter(t => now - t <= windowMs);
    timestamps.push(now);
    this.actionHistory.set(key, timestamps);

    return timestamps.length;
  }

  /**
   * Get current count without recording a new action
   */
  getCount(guildId, actorId, actionType, windowSeconds = 10) {
    const key = `${guildId}:${actorId}:${actionType}`;
    const now = Date.now();
    const windowMs = windowSeconds * 1000;
    const timestamps = this.actionHistory.get(key) || [];
    return timestamps.filter(t => now - t <= windowMs).length;
  }

  /**
   * Reset action history for a specific actor
   */
  resetActor(guildId, actorId, actionType = null) {
    if (actionType) {
      this.actionHistory.delete(`${guildId}:${actorId}:${actionType}`);
    } else {
      for (const key of this.actionHistory.keys()) {
        if (key.startsWith(`${guildId}:${actorId}:`)) {
          this.actionHistory.delete(key);
        }
      }
    }
  }

  /**
   * Clean up expired buckets
   */
  /**
   * Track cross-channel actions (e.g. posting links across distinct channels).
   * Returns count of UNIQUE channels the actor has targeted within windowSeconds.
   */
  recordChannelAction(guildId, actorId, actionType, channelId, windowSeconds = 15) {
    const key = `${guildId}:${actorId}:${actionType}:channels`;
    const now = Date.now();
    const windowMs = windowSeconds * 1000;

    let entries = this.actionHistory.get(key) || [];
    // Filter active window
    entries = entries.filter(e => e.timestamp && (now - e.timestamp <= windowMs));
    entries.push({ channelId, timestamp: now });
    this.actionHistory.set(key, entries);

    const uniqueChannels = new Set(entries.map(e => e.channelId));
    return uniqueChannels.size;
  }

  cleanup() {
    const now = Date.now();
    const maxWindowMs = 60 * 60 * 1000; // 1 hour max retention
    for (const [key, timestamps] of this.actionHistory.entries()) {
      const active = timestamps.filter(t => now - t <= maxWindowMs);
      if (active.length === 0) {
        this.actionHistory.delete(key);
      } else {
        this.actionHistory.set(key, active);
      }
    }
  }
}

export const actionTracker = new ActionTracker();