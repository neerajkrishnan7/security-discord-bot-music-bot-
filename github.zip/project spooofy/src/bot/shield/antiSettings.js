import { AuditLogEvent } from 'discord.js';
import { findAuditLogEntry } from '../sentinel/auditLogger.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { isTrusted } from '../../database/trustedAdmins.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { executePunishment } from './antiNuke.js';
import { config } from '../../config.js';

export async function handleGuildUpdate(oldGuild, newGuild, client) {
  const guildConfig = getGuildConfig(newGuild.id);
  if (!guildConfig.shield_enabled || !guildConfig.anti_server_settings_enabled) return;

  const changes = [];
  if (oldGuild.name !== newGuild.name) {
    changes.push(`Name: "${oldGuild.name}" -> "${newGuild.name}"`);
  }
  if (oldGuild.icon !== newGuild.icon) {
    changes.push('Server Icon changed');
  }
  if (oldGuild.verificationLevel !== newGuild.verificationLevel) {
    changes.push(`Verification Level: ${oldGuild.verificationLevel} -> ${newGuild.verificationLevel}`);
  }

  if (changes.length === 0) return;

  console.warn(`[AntiSettings] Guild settings changed in "${newGuild.name}": ${changes.join(', ')}`);

  // Query audit logs
  const logEntry = await findAuditLogEntry(newGuild, AuditLogEvent.GuildUpdate, null, 8000, 3);
  const actor = logEntry?.executor;

  if (actor) {
    // Exempt owner and bot
    if (actor.id === newGuild.ownerId || (config.botOwnerId && actor.id === config.botOwnerId) || actor.id === client?.user?.id) {
      return;
    }

    const member = await newGuild.members.fetch(actor.id).catch(() => null);
    const roleIds = member ? Array.from(member.roles.cache.keys()) : [];

    if (isTrusted(newGuild.id, actor.id, roleIds)) {
      return;
    }

    console.warn(`[AntiSettings] UNAUTHORIZED GUILD MODIFICATION BY ${actor.tag}! Restoring original name...`);

    // 1. Revert server name if changed
    let revertAction = 'Reverted server settings';
    if (oldGuild.name !== newGuild.name && newGuild.members.me?.permissions.has('ManageGuild')) {
      await newGuild.setName(oldGuild.name, 'SPOOFY Anti-Settings: Unauthorized server name alteration');
    }

    // 2. Punish actor
    let actorPunishment = 'None';
    if (member) {
      actorPunishment = await executePunishment(
        newGuild,
        member,
        'strip_roles',
        `SPOOFY Anti-Settings: Unauthorized guild modifications (${changes.join(', ')})`
      );
    }

    // 3. Dispatch alert
    await dispatchSecurityAlert(client, {
      guild_id: newGuild.id,
      severity: 'HIGH',
      category: 'ANTI_SETTINGS',
      title: '🚨 UNAUTHORIZED SERVER SETTINGS MODIFICATION',
      description: `User **${actor.tag}** attempted unauthorized alterations to server core settings:\n${changes.map(c => `• ${c}`).join('\n')}`,
      actor_id: actor.id,
      actor_tag: actor.tag,
      action_taken: `${revertAction} & ${actorPunishment}`
    });
  }
}
