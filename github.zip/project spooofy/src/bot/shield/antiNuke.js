import { actionTracker } from './actionTracker.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { isTrusted } from '../../database/trustedAdmins.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { addModerationCase } from '../../database/moderation.js';
import { config } from '../../config.js';

/**
 * Handle potentially destructive action attribution and anti-nuke enforcement.
 */
export async function handleDestructiveAction({
  guild,
  actor,
  actionType, // 'channel_delete', 'role_delete', 'ban_add', 'kick_add', 'webhook_create'
  target,     // e.g. deleted channel, role, or member
  client
}) {
  if (!guild || !actor) return { status: 'ignored', reason: 'No guild or actor' };

  // Always exempt server owner and master bot owner
  if (actor.id === guild.ownerId || (config.botOwnerId && actor.id === config.botOwnerId)) {
    return { status: 'exempt', reason: 'Owner exemption' };
  }

  // Exempt bot itself
  if (actor.id === client?.user?.id) {
    return { status: 'exempt', reason: 'Bot self exemption' };
  }

  // Load config & check if anti-nuke / shield enabled
  const guildConfig = getGuildConfig(guild.id);
  if (!guildConfig.shield_enabled || !guildConfig.anti_nuke_enabled) {
    return { status: 'disabled' };
  }

  // Fetch member to check role exemptions
  const member = await guild.members.fetch(actor.id).catch(() => null);
  const roleIds = member ? Array.from(member.roles.cache.keys()) : [];

  // Check trusted admins table
  if (isTrusted(guild.id, actor.id, roleIds)) {
    return { status: 'exempt', reason: 'Trusted admin' };
  }

  // Find threshold for this action type
  const threshold = (guildConfig.thresholds || []).find(t => t.action_type === actionType) || {
    limit_count: 2,
    window_seconds: 10,
    punishment: 'ban'
  };

  // Record action in sliding window
  const count = actionTracker.recordAction(guild.id, actor.id, actionType, threshold.window_seconds);

  console.log(`[AntiNuke] Actor ${actor.tag || actor.id} performed ${actionType} (${count}/${threshold.limit_count} within ${threshold.window_seconds}s)`);

  // Check if threshold exceeded
  if (count >= threshold.limit_count) {
    let actionTaken = 'NONE';
    const punishment = threshold.punishment || guildConfig.punishment_default || 'quarantine';

    // Execute punishment safely
    if (member) {
      actionTaken = await executePunishment(guild, member, punishment, `SPOOFY Anti-Nuke: Exceeded ${actionType} threshold (${count}/${threshold.limit_count})`);
    } else {
      actionTaken = `Punishment [${punishment}] queued (Member left/uncached)`;
    }

    // Active Auto-Rollback: Instant Auto-Recreation of maliciously deleted entity
    let autoRecreated = false;
    if (actionType === 'channel_delete' && target && guild.members.me?.permissions.has('ManageChannels')) {
      try {
        await guild.channels.create({
          name: target.name || 'recovered-channel',
          type: target.type,
          topic: target.topic || '',
          parent: target.parentId || null,
          permissionOverwrites: target.permissionOverwrites?.cache?.map(o => ({
            id: o.id,
            allow: o.allow?.toArray ? o.allow.toArray() : [],
            deny: o.deny?.toArray ? o.deny.toArray() : []
          })) || [],
          reason: 'SPOOFY Anti-Nuke: Instant Auto-Recreation of deleted channel'
        });
        autoRecreated = true;
      } catch (e) {
        console.error('[AntiNuke] Failed to auto-recreate deleted channel:', e.message);
      }
    }

    if (actionType === 'role_delete' && target && guild.members.me?.permissions.has('ManageRoles')) {
      try {
        await guild.roles.create({
          name: target.name || 'recovered-role',
          color: target.color || 0,
          hoist: target.hoist || false,
          permissions: target.permissions || 0n,
          mentionable: target.mentionable || false,
          reason: 'SPOOFY Anti-Nuke: Instant Auto-Recreation of deleted role'
        });
        autoRecreated = true;
      } catch (e) {
        console.error('[AntiNuke] Failed to auto-recreate deleted role:', e.message);
      }
    }

    if (autoRecreated) {
      actionTaken += ' & Instantly Auto-Recreated';
    }

    // Reset tracker for this actor so we don't spam duplicate punishments
    actionTracker.resetActor(guild.id, actor.id, actionType);

    // Dispatch CRITICAL alert
    await dispatchSecurityAlert(client, {
      guild_id: guild.id,
      severity: 'CRITICAL',
      category: 'ANTI_NUKE',
      title: `Mass ${formatActionName(actionType)} Detected!`,
      description: `User exceeded destructive threshold (${count} actions in ${threshold.window_seconds}s). Rapid defense triggered!`,
      actor_id: actor.id,
      actor_tag: actor.tag || actor.username,
      target_type: target?.type || actionType,
      target_id: target?.id || 'Unknown',
      target_name: target?.name || target?.user?.tag || 'Unknown',
      action_taken: actionTaken,
      snapshot_data: target ? {
        id: target.id,
        name: target.name,
        type: target.type
      } : null
    });

    return { status: 'punished', count, punishment, actionTaken };
  } else {
    // Under threshold, but log MEDIUM warning alert if near limit
    if (count > 1) {
      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'MEDIUM',
        category: 'ANTI_NUKE',
        title: `Warning: ${formatActionName(actionType)} Frequency Warning`,
        description: `User performed ${count}/${threshold.limit_count} ${actionType} actions in ${threshold.window_seconds}s.`,
        actor_id: actor.id,
        actor_tag: actor.tag || actor.username,
        target_name: target?.name || 'Unknown',
        action_taken: 'Monitoring sliding window'
      });
    }
    return { status: 'tracked', count };
  }
}

/**
 * Execute punishment safely respecting Discord role hierarchy and permissions.
 */
export async function executePunishment(guild, member, punishment, reason) {
  const me = guild.members.me;
  if (!me) return 'Failed: Bot member not resolved';

  // Role hierarchy check
  if (member.roles.highest.position >= me.roles.highest.position) {
    return `Failed: Member has equal or higher role than ${config.branding.name} (Role Hierarchy)`;
  }

  try {
    if (punishment === 'ban') {
      if (!me.permissions.has('BanMembers')) return 'Failed: Bot lacks BanMembers permission';
      await member.ban({ reason });
      addModerationCase({
        guild_id: guild.id,
        case_type: 'BAN',
        user_id: member.id,
        user_tag: member.user?.tag,
        moderator_id: me.id,
        moderator_tag: `${config.branding.shield} Auto`,
        reason
      });
      return 'Banned Member';
    }

    if (punishment === 'kick') {
      if (!me.permissions.has('KickMembers')) return 'Failed: Bot lacks KickMembers permission';
      await member.kick(reason);
      addModerationCase({
        guild_id: guild.id,
        case_type: 'KICK',
        user_id: member.id,
        user_tag: member.user?.tag,
        moderator_id: me.id,
        moderator_tag: `${config.branding.shield} Auto`,
        reason
      });
      return 'Kicked Member';
    }

    if (punishment === 'strip_roles') {
      if (!me.permissions.has('ManageRoles')) return 'Failed: Bot lacks ManageRoles permission';
      const removableRoles = member.roles.cache.filter(r => r.id !== guild.id && r.position < me.roles.highest.position);
      await member.roles.remove(removableRoles, reason);
      addModerationCase({
        guild_id: guild.id,
        case_type: 'STRIP_ROLES',
        user_id: member.id,
        user_tag: member.user?.tag,
        moderator_id: me.id,
        moderator_tag: `${config.branding.shield} Auto`,
        reason
      });
      return `Stripped ${removableRoles.size} roles`;
    }

    if (punishment === 'quarantine') {
      const guildConfig = getGuildConfig(guild.id);
      let quarantineRoleId = guildConfig.quarantine_role_id;

      // If no quarantine role configured, strip roles & timeout for 28 days
      if (me.permissions.has('ModerateMembers')) {
        await member.timeout(28 * 24 * 60 * 60 * 1000, reason);
      }

      if (quarantineRoleId && guild.roles.cache.has(quarantineRoleId) && me.permissions.has('ManageRoles')) {
        const removableRoles = member.roles.cache.filter(r => r.id !== guild.id && r.position < me.roles.highest.position);
        await member.roles.remove(removableRoles, reason);
        await member.roles.add(quarantineRoleId, reason);
        return 'Quarantined & Stripped Roles';
      }

      return 'Timed out for 28 days (Quarantine)';
    }
  } catch (err) {
    return `Error executing punishment: ${err.message}`;
  }

  return 'No action taken';
}

function formatActionName(type) {
  const map = {
    channel_delete: 'Channel Deletions',
    channel_create: 'Channel Creations',
    role_delete: 'Role Deletions',
    role_create: 'Role Creations',
    ban_add: 'Mass Bans',
    kick_add: 'Mass Kicks',
    webhook_create: 'Unauthorized Webhooks',
    perm_escalate: 'Permission Escalations'
  };
  return map[type] || type;
}
