import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { findAuditLogEntry } from '../sentinel/auditLogger.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { isTrusted } from '../../database/trustedAdmins.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { executePunishment } from './antiNuke.js';
import { config } from '../../config.js';

const DANGEROUS_PERMISSIONS = [
  { flag: PermissionFlagsBits.Administrator, name: 'Administrator' },
  { flag: PermissionFlagsBits.ManageGuild, name: 'Manage Server' },
  { flag: PermissionFlagsBits.ManageRoles, name: 'Manage Roles' },
  { flag: PermissionFlagsBits.ManageChannels, name: 'Manage Channels' },
  { flag: PermissionFlagsBits.BanMembers, name: 'Ban Members' },
  { flag: PermissionFlagsBits.KickMembers, name: 'Kick Members' },
  { flag: PermissionFlagsBits.MentionEveryone, name: 'Mention Everyone' },
  { flag: PermissionFlagsBits.ManageWebhooks, name: 'Manage Webhooks' }
];

export async function handleRoleUpdate(oldRole, newRole, client) {
  const guild = newRole.guild;
  const guildConfig = getGuildConfig(guild.id);

  if (!guildConfig.shield_enabled || !guildConfig.anti_role_abuse_enabled) return;

  // Check which dangerous permissions were added
  const escalatedPerms = [];
  for (const perm of DANGEROUS_PERMISSIONS) {
    if (!oldRole.permissions.has(perm.flag) && newRole.permissions.has(perm.flag)) {
      escalatedPerms.push(perm.name);
    }
  }

  if (escalatedPerms.length === 0) return;

  console.warn(`[AntiRoleAbuse] Role "${newRole.name}" escalated with: ${escalatedPerms.join(', ')}`);

  // Query audit log
  const logEntry = await findAuditLogEntry(guild, AuditLogEvent.RoleUpdate, newRole.id, 8000, 3);
  const actor = logEntry?.executor;

  if (actor) {
    // Exempt owner and bot itself
    if (actor.id === guild.ownerId || (config.botOwnerId && actor.id === config.botOwnerId) || actor.id === client?.user?.id) {
      return;
    }

    const member = await guild.members.fetch(actor.id).catch(() => null);
    const roleIds = member ? Array.from(member.roles.cache.keys()) : [];

    if (isTrusted(guild.id, actor.id, roleIds)) {
      return;
    }

    console.warn(`[AntiRoleAbuse] UNAUTHORIZED PERMISSION ESCALATION BY ${actor.tag}! Reverting...`);

    // 1. Immediately revert role permissions
    let revertAction = 'Reverted escalated permissions';
    if (guild.members.me?.permissions.has('ManageRoles') && newRole.position < guild.members.me.roles.highest.position) {
      await newRole.setPermissions(oldRole.permissions, 'SPOOFY Shield: Unauthorized permission escalation reverted');
    } else {
      revertAction = 'Failed to revert (Role hierarchy)';
    }

    // 2. Punish rogue actor
    let actorPunishment = 'None';
    if (member) {
      actorPunishment = await executePunishment(
        guild,
        member,
        'strip_roles',
        `SPOOFY Anti-Role Abuse: Unauthorized escalation of ${escalatedPerms.join(', ')}`
      );
    }

    // 3. Dispatch alert
    await dispatchSecurityAlert(client, {
      guild_id: guild.id,
      severity: 'CRITICAL',
      category: 'ANTI_ROLE',
      title: '🚨 DANGEROUS PERMISSION ESCALATION REVERTED',
      description: `Actor **${actor.tag}** attempted to grant dangerous permission(s) \`[${escalatedPerms.join(', ')}]\` to role **${newRole.name}**. Threat neutralized!`,
      actor_id: actor.id,
      actor_tag: actor.tag,
      target_type: 'Role',
      target_id: newRole.id,
      target_name: newRole.name,
      action_taken: `${revertAction} & ${actorPunishment}`
    });
  }
}
