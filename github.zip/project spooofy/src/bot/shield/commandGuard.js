import { PermissionFlagsBits, EmbedBuilder } from 'discord.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { logAuditEvent } from '../../database/moderation.js';
import { config } from '../../config.js';

// Per-user command cooldown store: Map<userId_commandName, timestamp>
const cooldowns = new Map();

const STAFF_PERMISSIONS = [
  PermissionFlagsBits.Administrator,
  PermissionFlagsBits.ManageGuild,
  PermissionFlagsBits.ManageRoles,
  PermissionFlagsBits.ManageChannels,
  PermissionFlagsBits.ModerateMembers,
  PermissionFlagsBits.BanMembers,
  PermissionFlagsBits.KickMembers,
  PermissionFlagsBits.ViewAuditLog
];

/**
 * Determines if a guild member is authorized server staff.
 * Validates against custom staff roles and core moderation permissions.
 */
export function isServerStaff(guild, member) {
  if (!guild || !member) return false;

  // Server Owner and Bot Owner are always staff
  if (member.id === guild.ownerId || (config.botOwnerId && member.id === config.botOwnerId)) {
    return true;
  }

  // Check if server configured a specific staff role
  try {
    const cfg = getGuildConfig(guild.id);
    if (cfg?.staff_role_id && member.roles.cache.has(cfg.staff_role_id)) {
      return true;
    }
  } catch {}

  // Check if member holds any core staff/moderation permission
  return STAFF_PERMISSIONS.some(perm => member.permissions.has(perm));
}

/**
 * Determines if a member holds the server DJ role or is staff
 */
export function isDjOrStaff(guild, member) {
  if (isServerStaff(guild, member)) return true;

  try {
    const cfg = getGuildConfig(guild.id);
    if (cfg?.dj_role_id && member.roles.cache.has(cfg.dj_role_id)) {
      return true;
    }
  } catch {}

  return false;
}

/**
 * Validates command prerequisites:
 * 1. Guild context check
 * 2. Staff authorization check (Standard members blocked from security commands)
 * 3. Member permission check (enforced server-side)
 * 4. Command rate limit / cooldown check
 * 5. Bot permission check
 */
export async function guardCommand(interaction, options = {}) {
  const {
    requiredPermissions = [],
    botPermissions = [],
    ownerOnly = false,
    staffOnly = false,
    cooldownSeconds = 3
  } = options;

  // 1. Guild Context Check
  if (!interaction.inGuild() || !interaction.guild) {
    await interaction.reply({
      content: '❌ This command can only be executed within a Discord server.',
      ephemeral: true
    }).catch(() => {});
    return false;
  }

  const guild = interaction.guild;
  const member = interaction.member;
  const isOwner = interaction.user.id === guild.ownerId || interaction.user.id === config.botOwnerId;

  // 2. Owner-Only Check
  if (ownerOnly && !isOwner) {
    await interaction.reply({
      content: '❌ **Owner Protection**: This high-privilege command is strictly restricted to the Server Owner.',
      ephemeral: true
    }).catch(() => {});
    return false;
  }

  // 3. Staff-Only Check (Default for security and moderation commands)
  if (staffOnly && !isOwner) {
    if (!isServerStaff(guild, member)) {
      await interaction.reply({
        content: '❌ **Access Denied**: Security and moderation commands are strictly restricted to authorized server staff and moderators. Standard members can only use music features.',
        ephemeral: true
      }).catch(() => {});
      return false;
    }
  }

  // 4. Member Server-Side Permission Check
  if (!isOwner && requiredPermissions.length > 0) {
    if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
      const missing = requiredPermissions.filter(perm => !member.permissions.has(perm));
      if (missing.length > 0) {
        const permNames = missing.map(p => formatPermissionName(p)).join(', ');
        await interaction.reply({
          content: `❌ **Access Denied**: You require the **${permNames}** permission(s) to execute this command.`,
          ephemeral: true
        }).catch(() => {});
        return false;
      }
    }
  }

  // 5. Rate Limiting / Cooldown Check
  if (cooldownSeconds > 0 && !isOwner) {
    const key = `${interaction.user.id}_${interaction.commandName}`;
    const now = Date.now();
    const expiresAt = cooldowns.get(key) || 0;

    if (now < expiresAt) {
      const remaining = ((expiresAt - now) / 1000).toFixed(1);
      await interaction.reply({
        content: `⏱️ **Cooldown**: Please wait \`${remaining}s\` before using \`/${interaction.commandName}\` again.`,
        ephemeral: true
      }).catch(() => {});
      return false;
    }

    cooldowns.set(key, now + (cooldownSeconds * 1000));
  }

  // 6. Bot Client Permission Check
  if (botPermissions.length > 0) {
    const me = guild.members.me;
    if (!me) {
      await interaction.reply({
        content: '❌ Unable to resolve bot guild member permissions.',
        ephemeral: true
      }).catch(() => {});
      return false;
    }

    if (!me.permissions.has(PermissionFlagsBits.Administrator)) {
      const botMissing = botPermissions.filter(p => !me.permissions.has(p));
      if (botMissing.length > 0) {
        const permNames = botMissing.map(p => formatPermissionName(p)).join(', ');
        await interaction.reply({
          content: `❌ **Bot Configuration Error**: SPOOFY is missing required permission(s): **${permNames}**. Please adjust the bot's role permissions.`,
          ephemeral: true
        }).catch(() => {});
        return false;
      }
    }
  }

  return true;
}

/**
 * Validates role hierarchy between actor, target member, and bot.
 */
export function checkTargetHierarchy(interaction, targetMember, targetName = 'member') {
  const guild = interaction.guild;
  const actor = interaction.member;
  const me = guild.members.me;

  // Cannot target server owner
  if (targetMember.id === guild.ownerId) {
    return {
      allowed: false,
      reason: '❌ You cannot target the Server Owner.'
    };
  }

  // Cannot target yourself for punitive moderation
  if (targetMember.id === interaction.user.id) {
    return {
      allowed: false,
      reason: '❌ You cannot perform punitive actions on yourself.'
    };
  }

  // Cannot target bot itself
  if (targetMember.id === interaction.client.user.id) {
    return {
      allowed: false,
      reason: '❌ SPOOFY cannot target itself.'
    };
  }

  // Actor role check (unless actor is server owner)
  if (interaction.user.id !== guild.ownerId && interaction.user.id !== config.botOwnerId) {
    if (targetMember.roles.highest.position >= actor.roles.highest.position) {
      return {
        allowed: false,
        reason: `❌ You cannot target a ${targetName} with an equal or higher role than your own.`
      };
    }
  }

  // Bot role hierarchy check
  if (me && targetMember.roles.highest.position >= me.roles.highest.position) {
    return {
      allowed: false,
      reason: `❌ SPOOFY cannot manage this ${targetName} because their role is equal to or higher than the bot's highest role.`
    };
  }

  return { allowed: true };
}

/**
 * Logs command execution to audit log
 */
export function logCommandAudit(interaction, actionType, details = {}) {
  try {
    logAuditEvent({
      guild_id: interaction.guild.id,
      event_type: `COMMAND_${actionType.toUpperCase()}`,
      actor_id: interaction.user.id,
      actor_tag: interaction.user.tag,
      target_id: details.targetId || interaction.channelId,
      target_name: details.targetName || interaction.commandName,
      reason: details.reason || `Executed /${interaction.commandName}`,
      changes_json: JSON.stringify(details)
    });
  } catch (err) {
    console.error('[CommandAudit] Failed to record command audit log:', err);
  }
}

function formatPermissionName(flag) {
  for (const [key, value] of Object.entries(PermissionFlagsBits)) {
    if (value === flag) return key;
  }
  return String(flag);
}