import { getGuildConfig } from '../../database/guildConfig.js';
import { isTrusted } from '../../database/trustedAdmins.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { executePunishment } from './antiNuke.js';
import { config } from '../../config.js';

/**
 * Advanced Alt Account & Threat Detection Engine
 */
export async function handleAltDetection(member, client) {
  if (!member.guild || member.user.bot) return;

  const guild = member.guild;
  const user = member.user;

  // Owner exemption
  if (user.id === guild.ownerId || (config.botOwnerId && user.id === config.botOwnerId)) {
    return;
  }

  // Trusted exemption
  if (isTrusted(guild.id, user.id, [])) {
    return;
  }

  const guildConfig = getGuildConfig(guild.id);
  if (!guildConfig.shield_enabled || !guildConfig.anti_alt_enabled) return;

  const now = Date.now();
  const createdAgeMs = now - user.createdTimestamp;
  const createdAgeDays = createdAgeMs / (1000 * 60 * 60 * 24);

  const minAgeDays = guildConfig.anti_alt_min_age_days ?? 7;
  const requireAvatar = Boolean(guildConfig.anti_alt_require_avatar);

  const isUnderage = createdAgeDays < minAgeDays;
  const hasDefaultAvatar = requireAvatar && !user.avatar;

  const suspiciousIndicators = [];
  if (isUnderage) suspiciousIndicators.push(`Account age is only ${createdAgeDays.toFixed(1)} days (Threshold: ${minAgeDays}d)`);
  if (hasDefaultAvatar) suspiciousIndicators.push('Default Discord avatar (No custom avatar)');

  // Suspicious name patterns common with alt / raid bot accounts
  const isSuspiciousUsername = /^[a-z]+[0-9]{5,}$/i.test(user.username) || /discord.*gift/i.test(user.username);
  if (isSuspiciousUsername && createdAgeDays < 14) {
    suspiciousIndicators.push('Auto-generated alt username pattern');
  }

  if (suspiciousIndicators.length > 0) {
    const punishment = guildConfig.anti_alt_action || 'quarantine';
    const reason = `SPOOFY Anti-Alt: Suspicious account (${suspiciousIndicators.join('; ')})`;

    console.warn(`[AntiAlt] Flagged suspicious account ${user.tag} (${user.id}): ${suspiciousIndicators.join(', ')}`);

    const actionTaken = await executePunishment(guild, member, punishment, reason);

    await dispatchSecurityAlert(client, {
      guild_id: guild.id,
      severity: isUnderage && createdAgeDays < 2 ? 'HIGH' : 'MEDIUM',
      category: 'ANTI_ALT',
      title: '🛡️ Suspicious Alt Account Intercepted',
      description: `Member **${user.tag}** was flagged by the Anti-Alt engine and neutralized.\n• **Indicators**: ${suspiciousIndicators.join(' • ')}`,
      actor_id: user.id,
      actor_tag: user.tag,
      target_name: user.tag,
      action_taken: actionTaken
    });
  }
}
