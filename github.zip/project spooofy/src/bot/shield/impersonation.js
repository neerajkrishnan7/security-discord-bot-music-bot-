import { getGuildConfig } from '../../database/guildConfig.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { executePunishment } from './antiNuke.js';

/**
 * Levenshtein distance between two strings
 */
function levenshteinDistance(s1, s2) {
  const m = s1.length;
  const n = s2.length;
  const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = s1[i - 1].toLowerCase() === s2[j - 1].toLowerCase() ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }

  return dp[m][n];
}

function calculateSimilarity(str1, str2) {
  const s1 = str1.normalize('NFKD').replace(/[^\w\s]/gi, '').trim().toLowerCase();
  const s2 = str2.normalize('NFKD').replace(/[^\w\s]/gi, '').trim().toLowerCase();
  const maxLen = Math.max(s1.length, s2.length);
  if (maxLen === 0) return 1.0;
  const dist = levenshteinDistance(s1, s2);
  return 1 - (dist / maxLen);
}

export async function checkImpersonation(member, client) {
  const guild = member.guild;
  const guildConfig = getGuildConfig(guild.id);
  if (!guildConfig.shield_enabled || !guildConfig.anti_impersonation_enabled) return;

  const owner = await guild.fetchOwner().catch(() => null);
  if (!owner || member.id === owner.id) return;

  const targetsToCheck = [
    { id: owner.id, tag: owner.user.tag, name: owner.displayName }
  ];

  const memberName = member.displayName;

  for (const target of targetsToCheck) {
    const similarity = calculateSimilarity(memberName, target.name);
    if (similarity >= 0.85) {
      console.warn(`[Impersonation] Potential clone detected: "${memberName}" imitating "${target.name}" (${(similarity * 100).toFixed(0)}% match)`);

      // Reset nickname or quarantine
      let actionTaken = 'Monitored';
      if (member.manageable) {
        await member.setNickname('Moderated-Name-' + member.id.slice(-4), 'SPOOFY Impersonation Guard').catch(() => {});
        actionTaken = 'Reset Nickname to Default';
      }

      await dispatchSecurityAlert(client, {
        guild_id: guild.id,
        severity: 'HIGH',
        category: 'IMPERSONATION',
        title: 'Staff / Owner Impersonation Detected',
        description: `Member **${member.user.tag}** used display name "${memberName}" matching server owner/staff "${target.name}" with ${(similarity * 100).toFixed(0)}% similarity.`,
        actor_id: member.id,
        actor_tag: member.user.tag,
        action_taken: actionTaken
      });
      break;
    }
  }
}
