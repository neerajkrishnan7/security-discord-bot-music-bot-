import { AuditLogEvent } from 'discord.js';
import { logAuditEvent } from '../../database/moderation.js';

/**
 * Fetch and reliably attribute an audit log entry for a specific action and target.
 * Retries up to 3 times to account for Discord audit log ingestion latency.
 */
export async function findAuditLogEntry(guild, actionType, targetId = null, maxAgeMs = 7000, attempts = 3) {
  if (!guild || !guild.members?.me?.permissions.has('ViewAuditLog')) {
    return null;
  }

  for (let i = 0; i < attempts; i++) {
    try {
      const auditLogs = await guild.fetchAuditLogs({
        type: actionType,
        limit: 5
      });

      const now = Date.now();
      const matchingEntry = auditLogs.entries.find(entry => {
        const isRecent = (now - entry.createdTimestamp) <= maxAgeMs;
        if (!isRecent) return false;
        if (targetId && entry.target?.id) {
          return entry.target.id === targetId;
        }
        return true;
      });

      if (matchingEntry) {
        // Log to our persistent audit log
        logAuditEvent({
          guild_id: guild.id,
          event_type: AuditLogEvent[actionType] || String(actionType),
          actor_id: matchingEntry.executor?.id,
          actor_tag: matchingEntry.executor?.tag || matchingEntry.executor?.username,
          target_id: matchingEntry.target?.id || targetId,
          target_name: matchingEntry.target?.name || matchingEntry.target?.tag || 'Unknown',
          reason: matchingEntry.reason || 'None provided',
          changes_json: matchingEntry.changes || []
        });

        return matchingEntry;
      }
    } catch (err) {
      console.warn(`[AuditLog] Attempt ${i + 1} failed to fetch audit logs:`, err.message);
    }

    if (i < attempts - 1) {
      await new Promise(r => setTimeout(r, 600 + i * 400));
    }
  }

  return null;
}
