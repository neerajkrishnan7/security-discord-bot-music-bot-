import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { createAlert } from '../../database/alerts.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { config } from '../../config.js';
import { broadcastToDashboard } from '../../server/ws.js';

export async function dispatchSecurityAlert(client, alertData) {
  // 1. Persist alert to database
  const alert = createAlert(alertData);

  // 2. Broadcast to live dashboard via WebSocket
  broadcastToDashboard('security_alert', alert);

  // 3. Send to Discord Sentinel log channel if bot is connected and channel is configured
  if (!client || !client.isReady()) {
    return alert;
  }

  try {
    const guildConfig = getGuildConfig(alertData.guild_id);
    if (!guildConfig.sentinel_log_channel_id) {
      return alert;
    }

    const channel = await client.channels.fetch(guildConfig.sentinel_log_channel_id).catch(() => null);
    if (!channel || !channel.isTextBased()) {
      return alert;
    }

    let color = config.branding.colorInt;
    if (alert.severity === 'CRITICAL') color = config.branding.colorCritInt;
    else if (alert.severity === 'HIGH') color = config.branding.colorHighInt;
    else if (alert.severity === 'MEDIUM') color = config.branding.colorMedInt;

    const embed = new EmbedBuilder()
      .setTitle(`🛡️ ${config.branding.sentinel}: ${alert.title}`)
      .setDescription(alert.description)
      .setColor(color)
      .addFields(
        { name: '⚡ Severity', value: `\`${alert.severity}\``, inline: true },
        { name: '📁 Category', value: `\`${alert.category}\``, inline: true },
        { name: '🎯 Status', value: `\`${alert.status}\``, inline: true }
      );

    if (alert.actor_id) {
      embed.addFields({
        name: '👤 Responsible Actor',
        value: `<@${alert.actor_id}> (${alert.actor_tag || alert.actor_id})`,
        inline: false
      });
    }

    if (alert.target_name || alert.target_id) {
      embed.addFields({
        name: '🎯 Target Resource',
        value: `${alert.target_name || 'N/A'} (\`${alert.target_type || 'Resource'}\`: \`${alert.target_id || 'N/A'}\`)`,
        inline: true
      });
    }

    if (alert.action_taken) {
      embed.addFields({
        name: '⚔️ SPOOFY Shield Response',
        value: `\`${alert.action_taken}\``,
        inline: true
      });
    }

    embed.setFooter({
      text: `${config.branding.name} Sentinel • ID: ${alert.id}`,
      iconURL: client.user?.displayAvatarURL() || undefined
    });
    embed.setTimestamp(new Date(alert.created_at * 1000));

    // Interactive action row
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`alert_dismiss_${alert.id}`)
        .setLabel('Dismiss')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`alert_rollback_${alert.id}`)
        .setLabel('Restore / Rollback')
        .setStyle(ButtonStyle.Primary)
    );

    if (alert.actor_id) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`alert_ban_${alert.id}`)
          .setLabel('Ban Actor')
          .setStyle(ButtonStyle.Danger)
      );
    }

    await channel.send({ embeds: [embed], components: [row] }).catch(err => {
      console.error('[Sentinel] Failed to send embed to log channel:', err.message);
    });
  } catch (error) {
    console.error('[Sentinel] Error in dispatchSecurityAlert:', error.message);
  }

  return alert;
}
