import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const automodCommand = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Configure intelligent chat content filters, credential protection, and strict link channels')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View active real-time chat defense filters and protection status')
    )
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('Enable or disable a specific chat defense filter')
        .addStringOption(opt =>
          opt.setName('filter')
            .setDescription('Chat defense module to toggle')
            .setRequired(true)
            .addChoices(
              { name: 'Discord Token & Webhook Leak Protection', value: 'anti_token_leak_enabled' },
              { name: 'Anti-Ghost Ping Detection', value: 'anti_ghost_ping_enabled' },
              { name: 'Anti-Phishing & IP Grabber Shield', value: 'anti_phishing_enabled' },
              { name: 'Anti-Invite Link Filter', value: 'anti_invite_enabled' },
              { name: 'Anti-Everyone / Mass Mention Filter', value: 'anti_everyone_enabled' },
              { name: 'Rapid Chat Anti-Spam Filter', value: 'anti_spam_enabled' }
            )
        )
        .addBooleanOption(opt => opt.setName('enabled').setDescription('Enable (True) or Disable (False)').setRequired(true))
    )
    .addSubcommandGroup(group =>
      group.setName('strictlink')
        .setDescription('Manage channels where posting ANY link triggers an instant message deletion and BAN')
        .addSubcommand(sub =>
          sub.setName('add')
            .setDescription('Add a channel where posting any link immediately bans the user')
            .addChannelOption(opt =>
              opt.setName('channel')
                .setDescription('Channel to strictly protect')
                .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
                .setRequired(true)
            )
        )
        .addSubcommand(sub =>
          sub.setName('remove')
            .setDescription('Remove a channel from the strict link auto-ban list')
            .addChannelOption(opt =>
              opt.setName('channel')
                .setDescription('Channel to unprotect')
                .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
                .setRequired(true)
            )
        )
        .addSubcommand(sub =>
          sub.setName('list')
            .setDescription('List all channels where links trigger an immediate ban')
        )
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      cooldownSeconds: 2
    });
    if (!passed) return;

    const subGroup = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (subGroup === 'strictlink') {
      const cfg = getGuildConfig(guildId);
      let strictChannels = [];
      try {
        strictChannels = JSON.parse(cfg.strict_link_ban_channel_ids || '[]');
      } catch {}

      if (sub === 'list') {
        if (strictChannels.length === 0) {
          return interaction.reply({
            content: 'ℹ️ No strict-link channels configured yet. Use `/automod strictlink add <channel>` to designate channels where links trigger an immediate ban.',
            ephemeral: true
          });
        }

        const embed = new EmbedBuilder()
          .setTitle('🚨 Strict Link Auto-Ban Channels')
          .setColor(config.branding.colorCritInt)
          .setDescription(
            `Posting ANY link in the following channels results in an **immediate message deletion & permanent ban** with reason *"Posting unwanted link in server"*:\n\n` +
            strictChannels.map((id, i) => `${i + 1}. <#${id}> (\`${id}\`)`).join('\n')
          )
          .setFooter({ text: 'SPOOFY Strict AutoMod • Zero tolerance for unwanted links' })
          .setTimestamp();

        return interaction.reply({ embeds: [embed] });
      }

      const targetChannel = interaction.options.getChannel('channel');

      if (sub === 'add') {
        if (strictChannels.includes(targetChannel.id)) {
          return interaction.reply({
            content: `ℹ️ <#${targetChannel.id}> is already in the strict link auto-ban list.`,
            ephemeral: true
          });
        }

        strictChannels.push(targetChannel.id);
        updateGuildConfig(guildId, { strict_link_ban_channel_ids: JSON.stringify(strictChannels) });

        logCommandAudit(interaction, 'AUTOMOD_STRICTLINK_ADD', {
          channelId: targetChannel.id,
          channelName: targetChannel.name
        });

        return interaction.reply({
          content: `🚨 **Strict Link Auto-Ban Activated** for <#${targetChannel.id}>.\nIf any standard member posts an unwanted link here, the link will be deleted immediately and the user will be permanently banned with reason *"Posting unwanted link in server"*.`
        });
      }

      if (sub === 'remove') {
        if (!strictChannels.includes(targetChannel.id)) {
          return interaction.reply({
            content: `ℹ️ <#${targetChannel.id}> is not currently in the strict link list.`,
            ephemeral: true
          });
        }

        strictChannels = strictChannels.filter(id => id !== targetChannel.id);
        updateGuildConfig(guildId, { strict_link_ban_channel_ids: JSON.stringify(strictChannels) });

        logCommandAudit(interaction, 'AUTOMOD_STRICTLINK_REMOVE', {
          channelId: targetChannel.id,
          channelName: targetChannel.name
        });

        return interaction.reply({
          content: `✅ Removed <#${targetChannel.id}> from the strict link auto-ban list.`
        });
      }
    }

    if (sub === 'status' && !subGroup) {
      const cfg = getGuildConfig(guildId);
      let strictChannels = [];
      try {
        strictChannels = JSON.parse(cfg.strict_link_ban_channel_ids || '[]');
      } catch {}

      const embed = new EmbedBuilder()
        .setTitle('🛡️ SPOOFY AutoMod & Chat Defense Status')
        .setColor(config.branding.colorInt)
        .setDescription(`Real-time conversational protection posture for **${interaction.guild.name}**.`)
        .addFields(
          { name: '🚨 Strict Link Auto-Ban', value: strictChannels.length > 0 ? `🟢 \`${strictChannels.length} channel(s) active\`` : '⚪ `None set`', inline: true },
          { name: '🌐 Cross-Channel Raid Ban', value: '🟢 `ACTIVE (3+ channels)`', inline: true },
          { name: '🔑 Token / Webhook Leak Shield', value: cfg.anti_token_leak_enabled ? '🟢 `ACTIVE (Instant Delete)`' : '🔴 `DISABLED`', inline: true },
          { name: '👻 Ghost Ping Detection', value: cfg.anti_ghost_ping_enabled ? '🟢 `ACTIVE (Logging & Alerts)`' : '🔴 `DISABLED`', inline: true },
          { name: '🎣 Anti-Phishing & IP Grabbers', value: cfg.anti_phishing_enabled ? '🟢 `ACTIVE (1h Timeout)`' : '🔴 `DISABLED`', inline: true },
          { name: '🔗 Anti-Invite Links', value: cfg.anti_invite_enabled ? '🟢 `ACTIVE (Auto-Warn)`' : '🔴 `DISABLED`', inline: true },
          { name: '📢 Anti-Everyone / Mass Mentions', value: cfg.anti_everyone_enabled ? '🟢 `ACTIVE (15m Timeout)`' : '🔴 `DISABLED`', inline: true },
          { name: '⚡ Rapid Chat Anti-Spam', value: cfg.anti_spam_enabled ? '🟢 `ACTIVE (5m Timeout)`' : '🔴 `DISABLED`', inline: true }
        )
        .setFooter({ text: 'SPOOFY AutoMod • Unicode homoglyph & zero-width normalization' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'toggle' && !subGroup) {
      const filterKey = interaction.options.getString('filter');
      const enabled = interaction.options.getBoolean('enabled');

      updateGuildConfig(guildId, { [filterKey]: enabled ? 1 : 0 });

      logCommandAudit(interaction, 'AUTOMOD_TOGGLE', { filter: filterKey, enabled });

      const filterNames = {
        anti_token_leak_enabled: 'Token / Webhook Leak Protection',
        anti_ghost_ping_enabled: 'Anti-Ghost Ping Detection',
        anti_phishing_enabled: 'Anti-Phishing & IP Grabber Shield',
        anti_invite_enabled: 'Anti-Invite Link Filter',
        anti_everyone_enabled: 'Anti-Everyone / Mass Mention Filter',
        anti_spam_enabled: 'Rapid Chat Anti-Spam Filter'
      };

      return interaction.reply({
        content: `🛡️ **${filterNames[filterKey] || filterKey}** has been ${enabled ? '🟢 **ENABLED**' : '🔴 **DISABLED**'}.`
      });
    }
  }
};