import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { isTrusted } from '../../database/trustedAdmins.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const sweeperCommand = {
  data: new SlashCommandBuilder()
    .setName('sweeper')
    .setDescription('Deep server audit and cleaner for rogue webhooks and dangerous permission leaks')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('webhooks')
        .setDescription('Scan all channels for unauthorized or rogue webhooks and eliminate them')
        .addBooleanOption(opt =>
          opt.setName('clean')
            .setDescription('Automatically delete unauthorized rogue webhooks (True = Delete, False = Audit only)')
            .setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub.setName('roles')
        .setDescription('Audit all server roles for dangerous permissions, administrative sprawl, and empty roles')
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.Administrator],
      botPermissions: [PermissionFlagsBits.ManageWebhooks, PermissionFlagsBits.ManageRoles],
      cooldownSeconds: 8
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    await interaction.deferReply();

    if (sub === 'webhooks') {
      const shouldClean = interaction.options.getBoolean('clean') ?? true;
      let totalScanned = 0;
      let rogueCount = 0;
      const rogueWebhooks = [];

      try {
        const channels = guild.channels.cache.filter(c => c.isTextBased() && !c.isThread());

        for (const channel of channels.values()) {
          if (!channel.permissionsFor(guild.members.me)?.has('ManageWebhooks')) continue;

          const webhooks = await channel.fetchWebhooks().catch(() => null);
          if (!webhooks) continue;

          for (const wh of webhooks.values()) {
            totalScanned++;
            const creatorId = wh.owner?.id;
            const isOwner = creatorId === guild.ownerId || (config.botOwnerId && creatorId === config.botOwnerId);
            const isBotSelf = creatorId === client.user.id;
            const isTrustedCreator = creatorId ? isTrusted(guild.id, creatorId, []) : false;

            if (!isOwner && !isBotSelf && !isTrustedCreator) {
              rogueCount++;
              rogueWebhooks.push({
                id: wh.id,
                name: wh.name,
                channelId: channel.id,
                channelName: channel.name,
                creatorTag: wh.owner?.tag || 'Unknown'
              });

              if (shouldClean) {
                await wh.delete('SPOOFY Sweeper: Unauthorized rogue webhook eliminated').catch(() => {});
              }
            }
          }
        }

        logCommandAudit(interaction, 'SWEEPER_WEBHOOKS', {
          totalScanned,
          rogueCount,
          cleaned: shouldClean
        });

        const embed = new EmbedBuilder()
          .setTitle('🧹 Webhook Security Sweep')
          .setColor(rogueCount > 0 ? (shouldClean ? config.branding.colorSuccessInt : config.branding.colorCritInt) : config.branding.colorSuccessInt)
          .setDescription(`Scanned **${totalScanned}** webhooks across server channels.`)
          .addFields(
            { name: '🔍 Total Webhooks', value: `\`${totalScanned}\``, inline: true },
            { name: '🚨 Rogue / Untrusted', value: `\`${rogueCount}\``, inline: true },
            { name: '⚡ Action Status', value: shouldClean ? (rogueCount > 0 ? '🟢 `ELIMINATED`' : '✅ `CLEAN`') : '⚪ `AUDIT ONLY`', inline: true }
          )
          .setFooter({ text: 'SPOOFY Sentinel Webhook Sweeper' })
          .setTimestamp();

        if (rogueWebhooks.length > 0) {
          embed.addFields({
            name: `⚠️ Detected Rogue Webhooks (${rogueWebhooks.length})`,
            value: rogueWebhooks.slice(0, 5).map(w => `• **${w.name}** in <#${w.channelId}> (Owner: \`${w.creatorTag}\` / \`${w.id}\`)${shouldClean ? ' — *Deleted*' : ''}`).join('\n')
          });
        } else {
          embed.addFields({
            name: '✅ Verification Result',
            value: 'All existing webhooks belong to authorized administrators or official bot services.'
          });
        }

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Webhook sweep failed: ${err.message}` });
      }
    }

    if (sub === 'roles') {
      try {
        const roles = guild.roles.cache.filter(r => r.id !== guild.id);
        const adminRoles = [];
        const dangerousRoles = [];
        const emptyRoles = [];

        for (const role of roles.values()) {
          if (role.members.size === 0 && !role.managed) {
            emptyRoles.push(role);
          }

          if (role.permissions.has(PermissionFlagsBits.Administrator)) {
            adminRoles.push(role);
          } else if (
            role.permissions.has(PermissionFlagsBits.ManageGuild) ||
            role.permissions.has(PermissionFlagsBits.ManageRoles) ||
            role.permissions.has(PermissionFlagsBits.BanMembers) ||
            role.permissions.has(PermissionFlagsBits.KickMembers)
          ) {
            dangerousRoles.push(role);
          }
        }

        logCommandAudit(interaction, 'SWEEPER_ROLES', {
          adminRolesCount: adminRoles.length,
          dangerousRolesCount: dangerousRoles.length,
          emptyRolesCount: emptyRoles.length
        });

        const embed = new EmbedBuilder()
          .setTitle('🛡️ Role Permission & Hierarchy Audit')
          .setColor(adminRoles.length > 3 ? config.branding.colorCritInt : config.branding.colorInt)
          .setDescription(`Audited **${roles.size}** roles for administrative sprawl and privilege exposure.`)
          .addFields(
            { name: '👑 Full Administrator Roles', value: `\`${adminRoles.length}\` roles`, inline: true },
            { name: '⚠️ Elevated Permission Roles', value: `\`${dangerousRoles.length}\` roles`, inline: true },
            { name: '🗑️ Empty / Unused Roles', value: `\`${emptyRoles.length}\` roles`, inline: true }
          )
          .setFooter({ text: 'SPOOFY Least-Privilege Engine' })
          .setTimestamp();

        if (adminRoles.length > 0) {
          embed.addFields({
            name: '👑 Administrator Roles Details',
            value: adminRoles.map(r => `• <@&${r.id}> (\`${r.name}\`): **${r.members.size}** member(s)`).slice(0, 8).join('\n')
          });
        }

        if (emptyRoles.length > 0) {
          embed.addFields({
            name: 'ℹ️ Unused Roles Tip',
            value: `Found **${emptyRoles.length}** unused roles with 0 members. Consider pruning them to maintain clean server hygiene.`
          });
        }

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Role audit failed: ${err.message}` });
      }
    }
  }
};
