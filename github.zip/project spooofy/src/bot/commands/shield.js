import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, updateGuildConfig, updateThreshold } from '../../database/guildConfig.js';
import { getTrustedAdmins, addTrustedAdmin, removeTrustedAdmin } from '../../database/trustedAdmins.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const shieldCommand = {
  data: new SlashCommandBuilder()
    .setName('shield')
    .setDescription('Configure and monitor SPOOFY Shield enterprise anti-nuke and defenses')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View current SPOOFY Shield protection status and active modules')
    )
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('Enable or disable a specific defensive security module')
        .addStringOption(opt =>
          opt.setName('module')
            .setDescription('Security module to toggle')
            .setRequired(true)
            .addChoices(
              { name: 'Master Shield (All Defenses)', value: 'shield_enabled' },
              { name: 'Anti-Nuke (Destructive actions)', value: 'anti_nuke_enabled' },
              { name: 'Anti-Raid (Join flood & account age)', value: 'anti_raid_enabled' },
              { name: 'Anti-Bot (Unauthorized bot joins)', value: 'anti_bot_enabled' },
              { name: 'Anti-Role Escalation (Dangerous permissions)', value: 'anti_role_abuse_enabled' },
              { name: 'Anti-Server Tampering (Name/Vanity changes)', value: 'anti_server_settings_enabled' },
              { name: 'Anti-Everyone / Here Mentions', value: 'anti_everyone_enabled' },
              { name: 'Anti-Invite Link Spam', value: 'anti_invite_enabled' },
              { name: 'Anti-Phishing & Suspicious Links', value: 'anti_phishing_enabled' },
              { name: 'Anti-Spam (Rapid chat flood)', value: 'anti_spam_enabled' },
              { name: 'Anti-Staff Impersonation', value: 'anti_impersonation_enabled' }
            )
        )
        .addBooleanOption(opt =>
          opt.setName('enabled')
            .setDescription('Enable (True) or Disable (False)')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('threshold')
        .setDescription('Configure sliding-window action rate limits and automated punishment')
        .addStringOption(opt =>
          opt.setName('action')
            .setDescription('Action type to limit')
            .setRequired(true)
            .addChoices(
              { name: 'Channel Deletions', value: 'channel_delete' },
              { name: 'Channel Creations', value: 'channel_create' },
              { name: 'Role Deletions', value: 'role_delete' },
              { name: 'Role Creations', value: 'role_create' },
              { name: 'Member Bans', value: 'ban_add' },
              { name: 'Member Kicks', value: 'kick_add' },
              { name: 'Webhook Creations', value: 'webhook_create' },
              { name: 'Permission Escalations', value: 'perm_escalate' }
            )
        )
        .addIntegerOption(opt =>
          opt.setName('limit')
            .setDescription('Max actions permitted before punishment triggers')
            .setMinValue(1)
            .setMaxValue(20)
            .setRequired(true)
        )
        .addIntegerOption(opt =>
          opt.setName('window')
            .setDescription('Sliding window duration in seconds')
            .setMinValue(5)
            .setMaxValue(300)
            .setRequired(true)
        )
        .addStringOption(opt =>
          opt.setName('punishment')
            .setDescription('Automated defensive response')
            .setRequired(true)
            .addChoices(
              { name: 'Permanent Ban', value: 'ban' },
              { name: 'Kick Member', value: 'kick' },
              { name: 'Quarantine & Strip Roles', value: 'quarantine' },
              { name: 'Strip Dangerous Roles', value: 'strip_roles' }
            )
        )
    )
    .addSubcommandGroup(group =>
      group.setName('trusted')
        .setDescription('Manage trusted administrators exempt from anti-nuke thresholds')
        .addSubcommand(sub =>
          sub.setName('list')
            .setDescription('List all trusted users and roles')
        )
        .addSubcommand(sub =>
          sub.setName('add')
            .setDescription('Add a user or role to trusted list (Owner only)')
            .addUserOption(opt => opt.setName('user').setDescription('Target user').setRequired(false))
            .addRoleOption(opt => opt.setName('role').setDescription('Target role').setRequired(false))
            .addStringOption(opt => opt.setName('notes').setDescription('Reason / notes').setRequired(false))
        )
        .addSubcommand(sub =>
          sub.setName('remove')
            .setDescription('Remove a user or role from trusted list (Owner only)')
            .addStringOption(opt => opt.setName('id').setDescription('Target user or role ID').setRequired(true))
        )
    ),

  async execute(interaction, client) {
    const subGroup = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    // Server-side permission check
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.Administrator],
      cooldownSeconds: 2
    });
    if (!passed) return;

    if (sub === 'status' && !subGroup) {
      const cfg = getGuildConfig(guildId);
      const trusted = getTrustedAdmins(guildId);

      const embed = new EmbedBuilder()
        .setTitle(`🛡️ ${config.branding.shield} — Security Engine Status`)
        .setColor(config.branding.colorInt)
        .setDescription(`Active defensive status for **${interaction.guild.name}**.`)
        .addFields(
          { name: '⚡ Master Shield', value: cfg.shield_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '💣 Anti-Nuke', value: cfg.anti_nuke_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '🚨 Anti-Raid', value: cfg.anti_raid_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '🤖 Anti-Bot', value: cfg.anti_bot_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '👑 Anti-Role Escalation', value: cfg.anti_role_abuse_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '🌐 Anti-Server Tampering', value: cfg.anti_server_settings_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '📢 Anti-Everyone', value: cfg.anti_everyone_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '🔗 Anti-Invite', value: cfg.anti_invite_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '🎣 Anti-Phishing', value: cfg.anti_phishing_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '🔒 Emergency Lockdown', value: cfg.lockdown_active ? '🔴 `ENGAGED`' : '⚪ `INACTIVE`', inline: true },
          { name: '👥 Trusted Admins', value: `\`${trusted.length}\` authorized`, inline: true }
        )
        .setFooter({ text: `${config.branding.name} Protection • Real-time Sliding Window` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'toggle' && !subGroup) {
      const moduleKey = interaction.options.getString('module');
      const enabled = interaction.options.getBoolean('enabled');

      updateGuildConfig(guildId, { [moduleKey]: enabled ? 1 : 0 });

      logCommandAudit(interaction, 'SHIELD_TOGGLE', {
        module: moduleKey,
        enabled
      });

      const moduleNames = {
        shield_enabled: 'Master Shield',
        anti_nuke_enabled: 'Anti-Nuke Protection',
        anti_raid_enabled: 'Anti-Raid Defense',
        anti_bot_enabled: 'Anti-Bot Filter',
        anti_role_abuse_enabled: 'Anti-Role Escalation',
        anti_server_settings_enabled: 'Anti-Server Tampering',
        anti_everyone_enabled: 'Anti-Everyone Mentions',
        anti_invite_enabled: 'Anti-Invite Spam',
        anti_phishing_enabled: 'Anti-Phishing Filter',
        anti_spam_enabled: 'Anti-Spam Rapid Chat',
        anti_impersonation_enabled: 'Anti-Staff Impersonation'
      };

      const name = moduleNames[moduleKey] || moduleKey;
      return interaction.reply({
        content: `🛡️ **${name}** has been ${enabled ? '🟢 **ENABLED**' : '🔴 **DISABLED**'} for this server.`
      });
    }

    if (sub === 'threshold' && !subGroup) {
      const actionType = interaction.options.getString('action');
      const limitCount = interaction.options.getInteger('limit');
      const windowSeconds = interaction.options.getInteger('window');
      const punishment = interaction.options.getString('punishment');

      updateThreshold(guildId, actionType, {
        limit_count: limitCount,
        window_seconds: windowSeconds,
        punishment
      });

      logCommandAudit(interaction, 'SHIELD_THRESHOLD_UPDATE', {
        actionType,
        limitCount,
        windowSeconds,
        punishment
      });

      const embed = new EmbedBuilder()
        .setTitle('⚙️ Defensive Threshold Updated')
        .setColor(config.branding.colorSuccessInt)
        .setDescription(`Automated anti-nuke threshold for \`${actionType}\` has been adjusted.`)
        .addFields(
          { name: '📊 Trigger Limit', value: `\`${limitCount}\` actions`, inline: true },
          { name: '⏱️ Window', value: `\`${windowSeconds} seconds\``, inline: true },
          { name: '⚡ Automated Punishment', value: `\`${punishment.toUpperCase()}\``, inline: true }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (subGroup === 'trusted') {
      // Sensitive owner restriction
      if (interaction.user.id !== interaction.guild.ownerId && interaction.user.id !== config.botOwnerId) {
        return interaction.reply({
          content: '❌ **Owner Protection**: Only the server owner can modify the trusted administrator list.',
          ephemeral: true
        });
      }

      if (sub === 'list') {
        const list = getTrustedAdmins(guildId);
        if (list.length === 0) {
          return interaction.reply({ content: 'ℹ️ No trusted administrators or roles configured yet. Only the Server Owner is currently exempt.', ephemeral: true });
        }

        const embed = new EmbedBuilder()
          .setTitle('🛡️ SPOOFY Shield — Trusted Allowlist')
          .setColor(config.branding.colorInt)
          .setDescription(list.map((t, idx) => `${idx + 1}. **${t.target_tag || t.target_id}** (\`${t.target_type}\`) • Added by <@${t.added_by}> ${t.notes ? `\n   *Note: ${t.notes}*` : ''}`).join('\n\n'))
          .setTimestamp();

        return interaction.reply({ embeds: [embed] });
      }

      if (sub === 'add') {
        const user = interaction.options.getUser('user');
        const role = interaction.options.getRole('role');
        const notes = interaction.options.getString('notes') || '';

        if (!user && !role) {
          return interaction.reply({ content: '❌ Please specify either a user or a role to trust.', ephemeral: true });
        }

        const targetId = user ? user.id : role.id;
        const targetType = user ? 'user' : 'role';
        const targetTag = user ? user.tag : role.name;

        addTrustedAdmin(guildId, {
          target_id: targetId,
          target_type: targetType,
          target_tag: targetTag,
          added_by: interaction.user.id,
          notes
        });

        logCommandAudit(interaction, 'TRUSTED_ADMIN_ADD', {
          targetId,
          targetType,
          targetTag,
          notes
        });

        return interaction.reply({
          content: `✅ Successfully added **${targetTag}** (\`${targetType}\`) to the **${config.branding.shield}** trusted allowlist.`,
          ephemeral: false
        });
      }

      if (sub === 'remove') {
        const id = interaction.options.getString('id');
        const success = removeTrustedAdmin(guildId, id);
        if (success) {
          logCommandAudit(interaction, 'TRUSTED_ADMIN_REMOVE', { targetId: id });
          return interaction.reply({ content: `✅ Successfully removed ID \`${id}\` from trusted list.`, ephemeral: false });
        } else {
          return interaction.reply({ content: `❌ ID \`${id}\` was not found in the trusted list.`, ephemeral: true });
        }
      }
    }
  }
};
