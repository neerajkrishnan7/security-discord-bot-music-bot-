import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getTrustedAdmins, addTrustedAdmin, removeTrustedAdmin } from '../../database/trustedAdmins.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const whitelistCommand = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('Manage trusted administrators exempt from anti-nuke thresholds (Owner Only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all trusted users and roles exempt from anti-nuke')
    )
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add an administrator or role to the trusted allowlist (Owner Only)')
        .addUserOption(opt => opt.setName('user').setDescription('Target user').setRequired(false))
        .addRoleOption(opt => opt.setName('role').setDescription('Target role').setRequired(false))
        .addStringOption(opt => opt.setName('notes').setDescription('Reason / notes').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove an administrator or role from the trusted allowlist (Owner Only)')
        .addStringOption(opt => opt.setName('id').setDescription('Target user or role ID').setRequired(true))
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'list') {
      const passed = await guardCommand(interaction, {
        requiredPermissions: [PermissionFlagsBits.Administrator],
        cooldownSeconds: 2
      });
      if (!passed) return;

      const list = getTrustedAdmins(guildId);
      if (list.length === 0) {
        return interaction.reply({
          content: 'ℹ️ No trusted administrators or roles configured yet. Only the Server Owner is currently exempt.',
          ephemeral: true
        });
      }

      const embed = new EmbedBuilder()
        .setTitle('🛡️ SPOOFY Shield — Trusted Administrator Allowlist')
        .setColor(config.branding.colorInt)
        .setDescription(list.map((t, idx) => `${idx + 1}. **${t.target_tag || t.target_id}** (\`${t.target_type}\`) • Added by <@${t.added_by}> ${t.notes ? `\n   *Note: ${t.notes}*` : ''}`).join('\n\n'))
        .setFooter({ text: 'Trusted entities bypass anti-nuke action limits' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    // Add and remove strictly require Server Owner
    const passed = await guardCommand(interaction, {
      ownerOnly: true,
      cooldownSeconds: 3
    });
    if (!passed) return;

    if (sub === 'add') {
      const user = interaction.options.getUser('user');
      const role = interaction.options.getRole('role');
      const notes = interaction.options.getString('notes') || '';

      if (!user && !role) {
        return interaction.reply({ content: '❌ Please specify either a user or a role to trust.', ephemeral: true });
      }

      const targetId = user ? user.id : role.id;
      const targetType = user ? 'user' : 'role';
      const targetTag = user ? user.tag : role.name;

      addTrustedAdmin(guildId, {
        target_id: targetId,
        target_type: targetType,
        target_tag: targetTag,
        added_by: interaction.user.id,
        notes
      });

      logCommandAudit(interaction, 'WHITELIST_ADD', {
        targetId,
        targetType,
        targetTag,
        notes
      });

      return interaction.reply({
        content: `✅ Successfully added **${targetTag}** (\`${targetType}\`) to the trusted whitelist.`,
        ephemeral: false
      });
    }

    if (sub === 'remove') {
      const id = interaction.options.getString('id');
      const success = removeTrustedAdmin(guildId, id);

      if (success) {
        logCommandAudit(interaction, 'WHITELIST_REMOVE', { targetId: id });
        return interaction.reply({ content: `✅ Successfully removed ID \`${id}\` from the trusted whitelist.`, ephemeral: false });
      } else {
        return interaction.reply({ content: `❌ ID \`${id}\` was not found in the trusted whitelist.`, ephemeral: true });
      }
    }
  }
};
