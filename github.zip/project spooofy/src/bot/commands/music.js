import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getMusicSession, updateMusicSession } from '../../database/music.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { guardCommand, isDjOrStaff } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const musicCommand = {
  data: new SlashCommandBuilder()
    .setName('music')
    .setDescription('SPOOFY High-Fidelity Music streaming, queue, and playback controls')
    .addSubcommand(sub =>
      sub.setName('play')
        .setDescription('Play a song or add it to queue (Available to all members)')
        .addStringOption(opt => opt.setName('query').setDescription('Song title, artist, or URL').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('queue')
        .setDescription('View upcoming songs in the server music queue (Available to all members)')
    )
    .addSubcommand(sub =>
      sub.setName('nowplaying')
        .setDescription('Display current track details, channel, and volume (Available to all members)')
    )
    .addSubcommand(sub =>
      sub.setName('pause')
        .setDescription('Pause current music playback (DJ or Server Staff)')
    )
    .addSubcommand(sub =>
      sub.setName('resume')
        .setDescription('Resume paused music playback (DJ or Server Staff)')
    )
    .addSubcommand(sub =>
      sub.setName('skip')
        .setDescription('Skip current playing song (DJ or Server Staff)')
    )
    .addSubcommand(sub =>
      sub.setName('stop')
        .setDescription('Stop music playback and clear queue (DJ or Server Staff)')
    )
    .addSubcommand(sub =>
      sub.setName('volume')
        .setDescription('Adjust playback volume (1-100%) (DJ or Server Staff)')
        .addIntegerOption(opt => opt.setName('percent').setDescription('Volume percentage').setMinValue(1).setMaxValue(100).setRequired(true))
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: false, // Music is accessible to all members!
      cooldownSeconds: 2
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;
    const guildId = guild.id;
    const voiceChannel = interaction.member?.voice?.channel;
    const session = getMusicSession(guildId);
    const guildConfig = getGuildConfig(guildId);

    // Voice presence check for playback modification
    if (['play', 'pause', 'resume', 'skip', 'stop', 'volume'].includes(sub)) {
      if (!voiceChannel) {
        return interaction.reply({
          content: '❌ You must be connected to a voice channel to use music controls.',
          ephemeral: true
        });
      }

      // Check if bot is already in a channel, ensure user is in the SAME channel
      const botVoiceChannelId = session?.channel_id;
      if (session?.is_playing && botVoiceChannelId && voiceChannel.id !== botVoiceChannelId) {
        return interaction.reply({
          content: `❌ **Channel Conflict**: SPOOFY is currently streaming in <#${botVoiceChannelId}>. You must join that voice channel to use playback controls.`,
          ephemeral: true
        });
      }
    }

    // Role check for DJ/Staff restricted actions
    if (['pause', 'resume', 'skip', 'stop', 'volume'].includes(sub)) {
      const isStaffOrDj = isDjOrStaff(guild, interaction.member);
      const isAloneWithBot = voiceChannel.members.filter(m => !m.user.bot).size === 1;

      if (!isStaffOrDj && !isAloneWithBot) {
        const djRoleMention = guildConfig.dj_role_id ? `<@&${guildConfig.dj_role_id}>` : 'DJ role';
        return interaction.reply({
          content: `❌ **DJ Restricted**: Music controls (pause, skip, stop, volume) are restricted to members with the ${djRoleMention} or Server Staff when multiple listeners are present. Standard members can queue songs with \`/music play\`.`,
          ephemeral: true
        });
      }
    }

    if (sub === 'play') {
      const query = interaction.options.getString('query').trim();
      if (!query || query.length > 250) {
        return interaction.reply({ content: '❌ Search query must be between 1 and 250 characters.', ephemeral: true });
      }

      // Queue limit check (default 50)
      const maxQueue = guildConfig.max_queue_limit || 50;
      if (session.queue.length >= maxQueue) {
        return interaction.reply({
          content: `❌ Server queue has reached its maximum limit of **${maxQueue} tracks**. Please wait for tracks to finish playing.`,
          ephemeral: true
        });
      }

      const track = {
        title: query.length > 60 ? query.slice(0, 57) + '...' : query,
        author: 'Artist Stream',
        url: query.startsWith('http') ? query : `https://youtube.com/results?search_query=${encodeURIComponent(query)}`,
        duration_ms: 215000,
        requester: interaction.user.tag
      };

      const newQueue = [...session.queue, track];

      if (!session.is_playing) {
        updateMusicSession(guildId, {
          channel_id: voiceChannel.id,
          current_track_title: track.title,
          current_track_author: track.author,
          current_track_url: track.url,
          duration_ms: track.duration_ms,
          position_ms: 0,
          is_playing: 1,
          is_paused: 0,
          queue_json: newQueue.slice(1)
        });

        const embed = new EmbedBuilder()
          .setTitle('🎶 Now Playing')
          .setColor(config.branding.colorInt)
          .setDescription(`**[${track.title}](${track.url})**`)
          .addFields(
            { name: 'Channel', value: `<#${voiceChannel.id}>`, inline: true },
            { name: 'Requested By', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Duration', value: '3:35', inline: true }
          )
          .setFooter({ text: 'SPOOFY High-Fidelity Audio • Dashboard sync active' });

        return interaction.reply({ embeds: [embed] });
      } else {
        updateMusicSession(guildId, { queue_json: newQueue });
        return interaction.reply({
          content: `🎵 Added to queue (Position #${newQueue.length}): **${track.title}**`
        });
      }
    }

    if (sub === 'queue') {
      if (!session.is_playing && session.queue.length === 0) {
        return interaction.reply({ content: 'ℹ️ The server music queue is currently empty.', ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setTitle('📋 Server Music Queue')
        .setColor(config.branding.colorInt)
        .setDescription(
          `**Currently Playing**: ${session.current_track_title ? `[${session.current_track_title}](${session.current_track_url || '#'})` : 'None'}\n\n` +
          `**Upcoming Tracks** (${session.queue.length}):\n` +
          (session.queue.length === 0
            ? '*No more tracks in queue.*'
            : session.queue.slice(0, 10).map((t, i) => `${i + 1}. **${t.title}** (Req: ${t.requester || 'User'})`).join('\n'))
        )
        .setFooter({ text: `${session.queue.length > 10 ? `...and ${session.queue.length - 10} more` : 'SPOOFY Music'}` });

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'nowplaying') {
      if (!session.is_playing) {
        return interaction.reply({ content: 'ℹ️ No track is currently playing in this server.', ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setTitle('🎶 Now Playing')
        .setColor(config.branding.colorInt)
        .setDescription(`**[${session.current_track_title}](${session.current_track_url || '#'})**`)
        .addFields(
          { name: 'Channel', value: session.channel_id ? `<#${session.channel_id}>` : 'Unknown', inline: true },
          { name: 'Volume', value: `${session.volume}%`, inline: true },
          { name: 'Status', value: session.is_paused ? '⏸️ Paused' : '▶️ Streaming', inline: true }
        )
        .setFooter({ text: 'SPOOFY High-Fidelity Audio' });

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'pause') {
      if (!session.is_playing) {
        return interaction.reply({ content: '❌ No music is currently playing.', ephemeral: true });
      }
      if (session.is_paused) {
        return interaction.reply({ content: 'ℹ️ Playback is already paused. Use `/music resume`.', ephemeral: true });
      }

      updateMusicSession(guildId, { is_paused: 1 });
      return interaction.reply({ content: '⏸️ Playback paused.' });
    }

    if (sub === 'resume') {
      if (!session.is_playing) {
        return interaction.reply({ content: '❌ No music session active.', ephemeral: true });
      }
      if (!session.is_paused) {
        return interaction.reply({ content: 'ℹ️ Playback is already running.', ephemeral: true });
      }

      updateMusicSession(guildId, { is_paused: 0 });
      return interaction.reply({ content: '▶️ Playback resumed.' });
    }

    if (sub === 'skip') {
      if (!session.is_playing) {
        return interaction.reply({ content: '❌ No music is currently playing to skip.', ephemeral: true });
      }

      if (session.queue.length > 0) {
        const next = session.queue[0];
        updateMusicSession(guildId, {
          current_track_title: next.title,
          current_track_author: next.author,
          current_track_url: next.url,
          position_ms: 0,
          queue_json: session.queue.slice(1)
        });
        return interaction.reply({ content: `⏭️ Skipped! Now playing: **${next.title}**` });
      } else {
        updateMusicSession(guildId, {
          is_playing: 0,
          current_track_title: null,
          current_track_author: null,
          current_track_url: null
        });
        return interaction.reply({ content: '⏭️ Skipped! Queue is now empty. Playback stopped.' });
      }
    }

    if (sub === 'stop') {
      updateMusicSession(guildId, {
        is_playing: 0,
        is_paused: 0,
        current_track_title: null,
        current_track_author: null,
        current_track_url: null,
        queue_json: []
      });
      return interaction.reply({ content: '⏹️ Stopped playback and cleared the music queue.' });
    }

    if (sub === 'volume') {
      const vol = interaction.options.getInteger('percent');
      const maxVol = guildConfig.max_music_volume || 100;
      const safeVol = Math.min(vol, maxVol);
      updateMusicSession(guildId, { volume: safeVol });
      return interaction.reply({ content: `🔊 Volume set to **${safeVol}%**${safeVol < vol ? ` (Capped at server maximum of ${maxVol}%)` : ''}.` });
    }
  }
};
