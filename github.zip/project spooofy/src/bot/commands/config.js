import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const configCommand = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configure server security parameters, fixed staff roles, and logging channels')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('view')
        .setDescription('View current security configuration, dedicated log channels, and active roles')
    )
    .addSubcommand(sub =>
      sub.setName('role')
        .setDescription('Bind fixed roles for Staff security commands or Music DJ controls')
        .addStringOption(opt =>
          opt.setName('type')
            .setDescription('Role type to assign')
            .setRequired(true)
            .addChoices(
              { name: 'Security Staff Role (Grants access to security & moderation commands)', value: 'staff_role_id' },
              { name: 'Music DJ Role (Grants access to music playback controls)', value: 'dj_role_id' }
            )
        )
        .addRoleOption(opt =>
          opt.setName('role')
            .setDescription('Role to bind')
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('logging')
        .setDescription('Assign dedicated logging channels for security events, moderation, or members')
        .addStringOption(opt =>
          opt.setName('type')
            .setDescription('Log channel stream to configure')
            .setRequired(true)
            .addChoices(
              { name: 'Security & Sentinel Alerts', value: 'sentinel_log_channel_id' },
              { name: 'Moderation Cases & Infractions', value: 'mod_log_channel_id' },
              { name: 'Member Join / Leave Activity', value: 'member_log_channel_id' }
            )
        )
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('Target text channel')
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('punishment')
        .setDescription('Set default automated punishment when anti-nuke thresholds are violated')
        .addStringOption(opt =>
          opt.setName('action')
            .setDescription('Automated response')
            .setRequired(true)
            .addChoices(
              { name: 'Quarantine & Strip Roles', value: 'quarantine' },
              { name: 'Permanent Ban', value: 'ban' },
              { name: 'Kick Member', value: 'kick' },
              { name: 'Strip Dangerous Roles', value: 'strip_roles' }
            )
        )
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      cooldownSeconds: 3
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;
    const cfg = getGuildConfig(guild.id);

    if (sub === 'view') {
      const embed = new EmbedBuilder()
        .setTitle(`⚙️ ${guild.name} — Security Configuration`)
        .setColor(config.branding.colorInt)
        .setDescription('Current security policy and administrative role/channel assignments.')
        .addFields(
          {
            name: '👑 Fixed Access Roles',
            value:
              `• **Security Staff Role**: ${cfg.staff_role_id ? `<@&${cfg.staff_role_id}>` : '*Not Set (Checks permissions)*'}\n` +
              `• **Music DJ Role**: ${cfg.dj_role_id ? `<@&${cfg.dj_role_id}>` : '*Not Set (Open / Staff only)*'}\n` +
              `• **Quarantine Role**: ${cfg.quarantine_role_id ? `<@&${cfg.quarantine_role_id}>` : '*Not Set (Timeouts used)*'}\n` +
              `• **Verification Role**: ${cfg.verification_role_id ? `<@&${cfg.verification_role_id}>` : '*Not Set*'}`,
            inline: false
          },
          {
            name: '📜 Dedicated Logging Channels',
            value:
              `• **Security Alerts**: ${cfg.sentinel_log_channel_id ? `<#${cfg.sentinel_log_channel_id}>` : '*Not Assigned*'}\n` +
              `• **Moderation**: ${cfg.mod_log_channel_id ? `<#${cfg.mod_log_channel_id}>` : '*Not Assigned*'}\n` +
              `• **Member Activity**: ${cfg.member_log_channel_id ? `<#${cfg.member_log_channel_id}>` : '*Not Assigned*'}`,
            inline: false
          },
          {
            name: '🛡️ Automated Enforcement Defaults',
            value:
              `• **Default Punishment**: \`${(cfg.punishment_default || 'quarantine').toUpperCase()}\`\n` +
              `• **Master Shield**: ${cfg.shield_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`'}\n` +
              `• **Anti-Nuke**: ${cfg.anti_nuke_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`'}\n` +
              `• **Anti-Raid**: ${cfg.anti_raid_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`'}\n` +
              `• **Anti-Alt**: ${cfg.anti_alt_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`'}`,
            inline: false
          }
        )
        .setFooter({ text: 'SPOOFY Administrative Engine • Fixed role access active' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'role') {
      const type = interaction.options.getString('type');
      const role = interaction.options.getRole('role');

      updateGuildConfig(guild.id, { [type]: role.id });

      logCommandAudit(interaction, 'CONFIG_ROLE_UPDATE', {
        type,
        roleId: role.id,
        roleName: role.name
      });

      const roleLabels = {
        staff_role_id: 'Security Staff Role',
        dj_role_id: 'Music DJ Role'
      };

      return interaction.reply({
        content: `✅ Successfully set **${roleLabels[type] || type}** to <@&${role.id}>.\n${type === 'staff_role_id' ? '🔒 Members with this role are now authorized to execute security and moderation commands.' : '🎵 Members with this role can now control music playback.'}`
      });
    }

    if (sub === 'logging') {
      const type = interaction.options.getString('type');
      const channel = interaction.options.getChannel('channel');

      updateGuildConfig(guild.id, { [type]: channel.id });

      logCommandAudit(interaction, 'CONFIG_LOGGING_UPDATE', {
        type,
        channelId: channel.id,
        channelName: channel.name
      });

      const typeNames = {
        sentinel_log_channel_id: 'Security & Sentinel Alerts',
        mod_log_channel_id: 'Moderation Cases',
        member_log_channel_id: 'Member Activity'
      };

      return interaction.reply({
        content: `✅ Successfully assigned <#${channel.id}> as the dedicated channel for **${typeNames[type] || type}**.`
      });
    }

    if (sub === 'punishment') {
      const action = interaction.options.getString('action');

      updateGuildConfig(guild.id, { punishment_default: action });

      logCommandAudit(interaction, 'CONFIG_PUNISHMENT_UPDATE', { punishmentDefault: action });

      return interaction.reply({
        content: `⚡ Default anti-nuke response punishment set to **${action.toUpperCase()}**.`
      });
    }
  }
};
