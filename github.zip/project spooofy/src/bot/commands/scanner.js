import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { scanServerPermissions } from '../scanner/permScanner.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const scannerCommand = {
  data: new SlashCommandBuilder()
    .setName('scanner')
    .setDescription('Deep audit of server permissions, dangerous roles, and hierarchy risks')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.Administrator],
      cooldownSeconds: 8
    });
    if (!passed) return;

    await interaction.deferReply();
    const guild = interaction.guild;

    try {
      const scan = await scanServerPermissions(guild);

      logCommandAudit(interaction, 'PERMISSION_SCAN', {
        securityScore: scan.securityScore,
        statusRating: scan.statusRating,
        findingsCount: scan.findings.length
      });

      let color = config.branding.colorSuccessInt;
      if (scan.statusRating === 'CRITICAL') color = config.branding.colorCritInt;
      else if (scan.statusRating === 'WARNING') color = config.branding.colorHighInt;

      const embed = new EmbedBuilder()
        .setTitle(`🛡️ SPOOFY Permission Scanner — Audit Report`)
        .setColor(color)
        .setDescription(`Security analysis for **${guild.name}**.\n**Security Score:** \`${scan.securityScore}/100\` (${scan.statusRating})`)
        .setFooter({ text: 'SPOOFY Security Intelligence • Least Privilege Engine' })
        .setTimestamp();

      if (scan.findings.length === 0) {
        embed.addFields({
          name: '✅ Perfect Configuration',
          value: 'No dangerous administrator permissions or critical role hierarchy vulnerabilities were detected.'
        });
      } else {
        for (const f of scan.findings.slice(0, 5)) {
          embed.addFields({
            name: `${f.severity === 'CRITICAL' ? '🚨' : f.severity === 'HIGH' ? '⚠️' : 'ℹ️'} [${f.severity}] ${f.title}`,
            value: `${f.description}\n**Recommendation**: *${f.recommendation}*`
          });
        }

        if (scan.findings.length > 5) {
          embed.addFields({
            name: '➕ More Findings',
            value: `View full interactive details and 1-click recommendations on the **SPOOFY Dashboard** (${scan.findings.length - 5} more).`
          });
        }
      }

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `❌ Permission scan failed: ${err.message}` });
    }
  }
};
