import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const antiraidCommand = {
  data: new SlashCommandBuilder()
    .setName('antiraid')
    .setDescription('Configure and monitor automated join raid defense and account age filters')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View current anti-raid parameters, thresholds, and recent join defense status')
    )
    .addSubcommand(sub =>
      sub.setName('mode')
        .setDescription('Set overall anti-raid sensitivity preset')
        .addStringOption(opt =>
          opt.setName('preset')
            .setDescription('Sensitivity preset')
            .setRequired(true)
            .addChoices(
              { name: 'OFF — Normal join flow without raid throttling', value: 'OFF' },
              { name: 'MODERATE — 3-day account age minimum + quarantine flag', value: 'MODERATE' },
              { name: 'AGGRESSIVE — 7-day account age + immediate kick + rapid join throttle', value: 'AGGRESSIVE' }
            )
        )
    )
    .addSubcommand(sub =>
      sub.setName('minage')
        .setDescription('Set minimum Discord account age requirement to join server')
        .addIntegerOption(opt =>
          opt.setName('days')
            .setDescription('Minimum age in days (0 = disabled, max 30)')
            .setMinValue(0)
            .setMaxValue(30)
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName('action')
        .setDescription('Set automated punishment for raid participants and underage accounts')
        .addStringOption(opt =>
          opt.setName('punishment')
            .setDescription('Automated action')
            .setRequired(true)
            .addChoices(
              { name: 'Quarantine & Strip Roles', value: 'quarantine' },
              { name: 'Kick from Server', value: 'kick' },
              { name: 'Permanent Ban', value: 'ban' }
            )
        )
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      cooldownSeconds: 3
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'status') {
      const cfg = getGuildConfig(guildId);

      const embed = new EmbedBuilder()
        .setTitle('🚨 SPOOFY Anti-Raid Defense Posture')
        .setColor(cfg.anti_raid_enabled ? config.branding.colorSuccessInt : config.branding.colorCritInt)
        .setDescription(`Current anti-raid configuration for **${interaction.guild.name}**.`)
        .addFields(
          { name: '🛡️ Anti-Raid Engine', value: cfg.anti_raid_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '📅 Min Account Age', value: `\`${cfg.account_age_min_days} day(s)\``, inline: true },
          { name: '⚡ Underage Action', value: `\`${cfg.account_age_action.toUpperCase()}\``, inline: true },
          { name: '🤖 Anti-Bot Filter', value: cfg.anti_bot_enabled ? '🟢 `BLOCKING UNTRUSTED`' : '⚪ `ALLOWING`', inline: true },
          { name: '🔒 Emergency Lockdown', value: cfg.lockdown_active ? '🔴 `ENGAGED`' : '⚪ `INACTIVE`', inline: true }
        )
        .setFooter({ text: 'SPOOFY Anti-Raid • Sliding join rate window protection' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'mode') {
      const preset = interaction.options.getString('preset');

      if (preset === 'OFF') {
        updateGuildConfig(guildId, { anti_raid_enabled: 0 });
      } else if (preset === 'MODERATE') {
        updateGuildConfig(guildId, {
          anti_raid_enabled: 1,
          account_age_min_days: 3,
          account_age_action: 'quarantine'
        });
      } else if (preset === 'AGGRESSIVE') {
        updateGuildConfig(guildId, {
          anti_raid_enabled: 1,
          account_age_min_days: 7,
          account_age_action: 'kick'
        });
      }

      logCommandAudit(interaction, 'ANTIRAID_MODE_UPDATE', { preset });

      return interaction.reply({
        content: `🚨 Anti-Raid sensitivity preset has been updated to **${preset}**.`
      });
    }

    if (sub === 'minage') {
      const days = interaction.options.getInteger('days');
      updateGuildConfig(guildId, { account_age_min_days: days });

      logCommandAudit(interaction, 'ANTIRAID_MINAGE_UPDATE', { days });

      return interaction.reply({
        content: `📅 Minimum account age requirement set to **${days} day(s)**. Accounts younger than this will trigger automated containment upon join.`
      });
    }

    if (sub === 'action') {
      const punishment = interaction.options.getString('punishment');
      updateGuildConfig(guildId, { account_age_action: punishment });

      logCommandAudit(interaction, 'ANTIRAID_ACTION_UPDATE', { punishment });

      return interaction.reply({
        content: `⚡ Anti-Raid response action updated to **${punishment.toUpperCase()}**.`
      });
    }
  }
};
