import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const lockCommand = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Freeze and lock a channel to prevent message spam or raid activity')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(opt =>
      opt.setName('channel')
        .setDescription('Channel to lock (defaults to current channel)')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildVoice)
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt.setName('reason')
        .setDescription('Reason for locking channel')
        .setRequired(false)
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageChannels],
      botPermissions: [PermissionFlagsBits.ManageChannels],
      cooldownSeconds: 3
    });
    if (!passed) return;

    const targetChannel = interaction.options.getChannel('channel') || interaction.channel;
    const reason = interaction.options.getString('reason') || `Channel locked by ${interaction.user.tag}`;

    await interaction.deferReply();

    try {
      await targetChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
        SendMessages: false,
        SendMessagesInThreads: false,
        CreatePublicThreads: false,
        CreatePrivateThreads: false
      }, { reason });

      logCommandAudit(interaction, 'CHANNEL_LOCK', {
        channelId: targetChannel.id,
        channelName: targetChannel.name,
        reason
      });

      const embed = new EmbedBuilder()
        .setTitle('🔒 Channel Locked')
        .setColor(config.branding.colorCritInt)
        .setDescription(`**<#${targetChannel.id}>** has been locked to prevent unauthorized messages.`)
        .addFields(
          { name: '👤 Moderator', value: `<@${interaction.user.id}>`, inline: true },
          { name: '📝 Reason', value: reason, inline: true }
        )
        .setFooter({ text: 'SPOOFY Channel Guard • Use /unlock to restore chatting' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `❌ Failed to lock channel: ${err.message}` });
    }
  }
};

export const unlockCommand = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock a previously locked channel to allow members to chat again')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(opt =>
      opt.setName('channel')
        .setDescription('Channel to unlock (defaults to current channel)')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildVoice)
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt.setName('reason')
        .setDescription('Reason for unlocking channel')
        .setRequired(false)
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageChannels],
      botPermissions: [PermissionFlagsBits.ManageChannels],
      cooldownSeconds: 3
    });
    if (!passed) return;

    const targetChannel = interaction.options.getChannel('channel') || interaction.channel;
    const reason = interaction.options.getString('reason') || `Channel unlocked by ${interaction.user.tag}`;

    await interaction.deferReply();

    try {
      await targetChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
        SendMessages: null,
        SendMessagesInThreads: null,
        CreatePublicThreads: null,
        CreatePrivateThreads: null
      }, { reason });

      logCommandAudit(interaction, 'CHANNEL_UNLOCK', {
        channelId: targetChannel.id,
        channelName: targetChannel.name,
        reason
      });

      const embed = new EmbedBuilder()
        .setTitle('🟢 Channel Unlocked')
        .setColor(config.branding.colorSuccessInt)
        .setDescription(`**<#${targetChannel.id}>** has been unlocked. Members can chat normally.`)
        .addFields(
          { name: '👤 Moderator', value: `<@${interaction.user.id}>`, inline: true },
          { name: '📝 Reason', value: reason, inline: true }
        )
        .setFooter({ text: 'SPOOFY Channel Guard' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `❌ Failed to unlock channel: ${err.message}` });
    }
  }
};
