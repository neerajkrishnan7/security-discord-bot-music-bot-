import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { enableEmergencyLockdown, disableEmergencyLockdown } from '../recovery/lockdown.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { dispatchSecurityAlert } from '../sentinel/alertDispatcher.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const panicCommand = {
  data: new SlashCommandBuilder()
    .setName('panic')
    .setDescription('RED ALERT: Immediate emergency containment protocol for active server attacks')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('engage')
        .setDescription('Engage maximum security lockdown: freeze channels, pause invites, trigger alarms')
        .addStringOption(opt => opt.setName('reason').setDescription('Emergency alert reason').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('lift')
        .setDescription('Deactivate panic protocol and restore normal server operations')
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for lifting emergency state').setRequired(false))
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.Administrator],
      botPermissions: [PermissionFlagsBits.ManageGuild, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageRoles],
      cooldownSeconds: 5
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;
    const reason = interaction.options.getString('reason') || 'RED ALERT: Manual emergency panic initiated by administrator';

    await interaction.deferReply();

    if (sub === 'engage') {
      try {
        const lockdownResult = await enableEmergencyLockdown(guild, client, {
          durationMinutes: 0,
          reason: `[PANIC ENGAGED] ${reason}`
        });

        updateGuildConfig(guild.id, {
          shield_enabled: 1,
          anti_nuke_enabled: 1,
          anti_raid_enabled: 1,
          anti_bot_enabled: 1,
          anti_everyone_enabled: 1,
          anti_invite_enabled: 1,
          lockdown_active: 1
        });

        // 2. Revoke all active invite links to eliminate raid ingress points
        let deletedInvitesCount = 0;
        if (guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
          try {
            const invites = await guild.invites.fetch().catch(() => null);
            if (invites) {
              for (const inv of invites.values()) {
                await inv.delete('SPOOFY Panic Mode: Server invites revoked during active emergency').catch(() => {});
                deletedInvitesCount++;
              }
            }
          } catch (e) {}
        }

        await dispatchSecurityAlert(client, {
          guild_id: guild.id,
          severity: 'CRITICAL',
          category: 'PANIC_MODE',
          title: '🚨 EMERGENCY PANIC PROTOCOL ENGAGED!',
          description: `Server has entered full emergency state authorized by <@${interaction.user.id}> (${interaction.user.tag}). All public communication is frozen and defensive thresholds are at maximum sensitivity.`,
          actor_id: interaction.user.id,
          actor_tag: interaction.user.tag,
          target_name: guild.name,
          action_taken: `Locked ${lockdownResult.lockedChannelsCount} channels & maximized shield defenses`
        });

        logCommandAudit(interaction, 'PANIC_ENGAGE', {
          reason,
          lockedChannels: lockdownResult.lockedChannelsCount
        });

        const embed = new EmbedBuilder()
          .setTitle('🚨 RED ALERT: EMERGENCY PANIC PROTOCOL ENGAGED')
          .setColor(config.branding.colorCritInt)
          .setDescription(`**${guild.name}** has entered emergency lockdown mode.\n\nAll text and voice channels have been frozen to neutralize rogue admins or raid floods.`)
          .addFields(
            { name: '🔒 Frozen Channels', value: `\`${lockdownResult.lockedChannelsCount}\` channels`, inline: true },
            { name: '⚡ Shield Status', value: '🔴 `MAXIMUM SENSITIVITY`', inline: true },
            { name: '👤 Authorized By', value: `<@${interaction.user.id}>`, inline: true },
            { name: '📝 Reason', value: reason, inline: false },
            { name: '🛡️ Recovery Protocol', value: 'Admins retain private access. Use `/panic lift` or `/backup restore` when the threat is neutralized.', inline: false }
          )
          .setFooter({ text: 'SPOOFY Sentinel Defense Protocol • Incident recorded' })
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Emergency panic activation encountered an error: ${err.message}` });
      }
    }

    if (sub === 'lift') {
      try {
        const unlockResult = await disableEmergencyLockdown(guild, client, {
          reason: `[PANIC LIFTED] ${reason}`
        });

        updateGuildConfig(guild.id, {
          lockdown_active: 0
        });

        logCommandAudit(interaction, 'PANIC_LIFT', {
          reason,
          unlockedChannels: unlockResult.unlockedChannelsCount
        });

        const embed = new EmbedBuilder()
          .setTitle('🟢 EMERGENCY PANIC PROTOCOL DEACTIVATED')
          .setColor(config.branding.colorSuccessInt)
          .setDescription(`Normal server operations have been restored across **${unlockResult.unlockedChannelsCount}** channels.`)
          .addFields(
            { name: '👤 Lifted By', value: `<@${interaction.user.id}>`, inline: true },
            { name: '📝 Reason', value: reason, inline: true }
          )
          .setFooter({ text: 'SPOOFY Shield remains active in standard monitoring mode' })
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Failed to lift emergency panic: ${err.message}` });
      }
    }
  }
};
