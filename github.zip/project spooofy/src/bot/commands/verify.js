import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } from 'discord.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const verifyCommand = {
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Configure and deploy member join verification and gatekeeper system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View current member verification configuration and gateway status')
    )
    .addSubcommand(sub =>
      sub.setName('setup')
        .setDescription('Deploy the interactive button verification panel into a channel')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to grant upon verification').setRequired(true))
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('Channel to deploy verification into (defaults to current channel)')
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
            .setRequired(false)
        )
        .addStringOption(opt => opt.setName('title').setDescription('Custom panel title').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('gatekeeper')
        .setDescription('Automatically isolate server channels so new members must verify before viewing the server')
        .addRoleOption(opt => opt.setName('verified_role').setDescription('Role granted to verified members to access channels').setRequired(true))
        .addChannelOption(opt =>
          opt.setName('verify_channel')
            .setDescription('The verification channel (defaults to current channel)')
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
            .setRequired(false)
        )
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      botPermissions: [PermissionFlagsBits.ManageRoles, PermissionFlagsBits.ManageChannels],
      cooldownSeconds: 5
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;
    const cfg = getGuildConfig(guild.id);

    if (sub === 'status') {
      const embed = new EmbedBuilder()
        .setTitle('🛡️ SPOOFY Member Verification Gatekeeper')
        .setColor(cfg.verification_enabled ? config.branding.colorSuccessInt : config.branding.colorCritInt)
        .setDescription(`Member verification status for **${guild.name}**.`)
        .addFields(
          { name: '⚡ Gateway Status', value: cfg.verification_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '👑 Verified Member Role', value: cfg.verification_role_id ? `<@&${cfg.verification_role_id}>` : '*Not Set*', inline: true },
          { name: '📍 Verification Channel', value: cfg.verification_channel_id ? `<#${cfg.verification_channel_id}>` : '*Not Set*', inline: true },
          { name: '🔒 Security Rule', value: 'New members must complete verification in the gateway before gaining server privileges.', inline: false }
        )
        .setFooter({ text: 'SPOOFY Gatekeeper Protection' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'setup') {
      const role = interaction.options.getRole('role');
      const targetChannel = interaction.options.getChannel('channel') || interaction.channel;
      const title = interaction.options.getString('title') || 'Server Verification Gateway';

      const me = guild.members.me;
      if (me && role.position >= me.roles.highest.position) {
        return interaction.reply({
          content: `❌ SPOOFY cannot grant **@${role.name}** because it is positioned higher than or equal to the bot's highest role. Move the bot's role above this verification role.`,
          ephemeral: true
        });
      }

      updateGuildConfig(guild.id, {
        verification_enabled: 1,
        verification_role_id: role.id,
        verification_channel_id: targetChannel.id
      });

      logCommandAudit(interaction, 'VERIFY_SETUP', {
        channelId: targetChannel.id,
        roleId: role.id,
        roleName: role.name
      });

      const embed = new EmbedBuilder()
        .setTitle(`🛡️ ${title}`)
        .setColor(config.branding.colorInt)
        .setDescription(
          'Welcome to the server! To protect our community from automated raid bots and malicious accounts, **all new members must verify before accessing channels**.\n\n' +
          'Click **Verify Access** below to verify and unlock the server.'
        )
        .setFooter({ text: 'SPOOFY Gatekeeper • Anti-Bot & Anti-Raid Gateway' });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('spoofy_verify_button')
          .setLabel('✅ Verify Access')
          .setStyle(ButtonStyle.Success)
      );

      await targetChannel.send({ embeds: [embed], components: [row] });

      return interaction.reply({
        content: `✅ Verification gateway deployed into <#${targetChannel.id}> with verified role <@&${role.id}>!\nNew members will be prompted to verify here when joining.`,
        ephemeral: true
      });
    }

    if (sub === 'gatekeeper') {
      const role = interaction.options.getRole('verified_role');
      const verifyChannel = interaction.options.getChannel('verify_channel') || interaction.channel;

      const me = guild.members.me;
      if (me && role.position >= me.roles.highest.position) {
        return interaction.reply({
          content: `❌ The verified role <@&${role.name}> is higher than or equal to the bot's highest role. Move the bot's role above it.`,
          ephemeral: true
        });
      }

      await interaction.deferReply();

      try {
        let isolatedCount = 0;
        const everyone = guild.roles.everyone;

        // 1. Configure Verification Channel permissions
        await verifyChannel.permissionOverwrites.edit(everyone, {
          ViewChannel: true,
          SendMessages: false,
          ReadMessageHistory: true
        }, { reason: 'SPOOFY Gatekeeper: Setup verification channel' });

        await verifyChannel.permissionOverwrites.edit(role, {
          ViewChannel: true,
          SendMessages: false,
          ReadMessageHistory: true
        }, { reason: 'SPOOFY Gatekeeper: Verified role view permission' });

        // 2. Isolate other channels across the server
        const channels = guild.channels.cache.filter(c => c.id !== verifyChannel.id && !c.isThread());
        for (const ch of channels.values()) {
          try {
            await ch.permissionOverwrites.edit(everyone, {
              ViewChannel: false
            }, { reason: 'SPOOFY Gatekeeper: Isolate channel for unverified members' });

            await ch.permissionOverwrites.edit(role, {
              ViewChannel: true
            }, { reason: 'SPOOFY Gatekeeper: Grant channel access to verified members' });

            isolatedCount++;
          } catch (e) {}
        }

        updateGuildConfig(guild.id, {
          verification_enabled: 1,
          verification_role_id: role.id,
          verification_channel_id: verifyChannel.id
        });

        // 3. Deploy verification panel into verification channel
        const embed = new EmbedBuilder()
          .setTitle('🛡️ Server Verification Gateway')
          .setColor(config.branding.colorInt)
          .setDescription(
            `Welcome to **${guild.name}**!\n\n` +
            '🔒 **Verification Required**: All new members must verify their access before server channels unlock.\n\n' +
            'Click the button below to verify your membership and gain full access.'
          )
          .setFooter({ text: 'SPOOFY Gatekeeper System • Instant Role Unlock' });

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('spoofy_verify_button')
            .setLabel('✅ Verify Access')
            .setStyle(ButtonStyle.Success)
        );

        await verifyChannel.send({ embeds: [embed], components: [row] });

        logCommandAudit(interaction, 'VERIFY_GATEKEEPER_ENGAGE', {
          verifyChannelId: verifyChannel.id,
          roleId: role.id,
          isolatedChannels: isolatedCount
        });

        const replyEmbed = new EmbedBuilder()
          .setTitle('🔒 Gatekeeper Server Isolation Active')
          .setColor(config.branding.colorSuccessInt)
          .setDescription(
            `Successfully activated full server gatekeeper protection!\n\n` +
            `• **Verification Channel**: <#${verifyChannel.id}>\n` +
            `• **Verified Member Role**: <@&${role.id}>\n` +
            `• **Protected Channels**: \`${isolatedCount}\` channels hidden from unverified members\n\n` +
            `New members will only see <#${verifyChannel.id}> when joining, and must click **Verify Access** to unlock the server.`
          )
          .setTimestamp();

        return interaction.editReply({ embeds: [replyEmbed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Failed to configure gatekeeper: ${err.message}` });
      }
    }
  }
};