import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } from 'discord.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const ticketCommand = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Configure and deploy support ticket system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('setup')
        .setDescription('Deploy interactive ticket creation panel into this channel')
        .addStringOption(opt => opt.setName('title').setDescription('Panel title').setRequired(false))
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      botPermissions: [PermissionFlagsBits.ManageChannels],
      cooldownSeconds: 5
    });
    if (!passed) return;

    const title = interaction.options.getString('title') || 'SPOOFY Support & Assistance';

    const embed = new EmbedBuilder()
      .setTitle(`🎫 ${title}`)
      .setColor(config.branding.colorInt)
      .setDescription(
        'Need assistance, report an incident, or inquire with server staff?\n\n' +
        'Click the button below to open a private encrypted ticket channel with our team.'
      )
      .setFooter({ text: 'SPOOFY Ticket Sentinel • Isolated Permissions' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('spoofy_ticket_open')
        .setLabel('📩 Create Support Ticket')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.channel.send({ embeds: [embed], components: [row] });

    logCommandAudit(interaction, 'TICKET_SETUP', {
      channelId: interaction.channel.id,
      title
    });

    return interaction.reply({ content: '✅ Support ticket panel deployed successfully.', ephemeral: true });
  }
};
