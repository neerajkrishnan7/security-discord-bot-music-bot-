import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const antialtCommand = {
  data: new SlashCommandBuilder()
    .setName('antialt')
    .setDescription('Configure intelligent alt account interception and suspicious profile defense')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View current anti-alt parameters, age thresholds, and enforcement action')
    )
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('Enable or disable automated alt account interception')
        .addBooleanOption(opt => opt.setName('enabled').setDescription('Enable (True) or Disable (False)').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('config')
        .setDescription('Configure minimum account age, avatar requirements, and automated punishment')
        .addIntegerOption(opt =>
          opt.setName('min_age_days')
            .setDescription('Minimum Discord account age required to join without trigger (0-60 days)')
            .setMinValue(0)
            .setMaxValue(60)
            .setRequired(true)
        )
        .addBooleanOption(opt =>
          opt.setName('require_avatar')
            .setDescription('Flag accounts using default Discord avatars without custom profile pictures')
            .setRequired(false)
        )
        .addStringOption(opt =>
          opt.setName('action')
            .setDescription('Automated response for detected alt accounts')
            .setRequired(false)
            .addChoices(
              { name: 'Quarantine & Strip Roles (Recommended)', value: 'quarantine' },
              { name: 'Kick from Server', value: 'kick' },
              { name: 'Permanent Ban', value: 'ban' }
            )
        )
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      cooldownSeconds: 3
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'status') {
      const cfg = getGuildConfig(guildId);

      const embed = new EmbedBuilder()
        .setTitle('🛡️ SPOOFY Anti-Alt & Profile Inspection Engine')
        .setColor(cfg.anti_alt_enabled ? config.branding.colorSuccessInt : config.branding.colorCritInt)
        .setDescription(`Active alt account protection policy for **${interaction.guild.name}**.`)
        .addFields(
          { name: '⚡ Alt Interception Engine', value: cfg.anti_alt_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`', inline: true },
          { name: '📅 Min Account Age Threshold', value: `\`${cfg.anti_alt_min_age_days ?? 7} day(s)\``, inline: true },
          { name: '🖼️ Custom Avatar Required', value: cfg.anti_alt_require_avatar ? '🟢 `YES`' : '⚪ `NO`', inline: true },
          { name: '⚡ Enforcement Action', value: `\`${(cfg.anti_alt_action || 'quarantine').toUpperCase()}\``, inline: true },
          { name: '🤖 Anti-Bot Filter', value: cfg.anti_bot_enabled ? '🟢 `BLOCKING UNTRUSTED`' : '⚪ `OFF`', inline: true }
        )
        .setFooter({ text: 'SPOOFY Profile Intelligence • Intercepts throwaway raid accounts' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'toggle') {
      const enabled = interaction.options.getBoolean('enabled');
      updateGuildConfig(guildId, { anti_alt_enabled: enabled ? 1 : 0 });

      logCommandAudit(interaction, 'ANTIALT_TOGGLE', { enabled });

      return interaction.reply({
        content: `🛡️ Anti-Alt account interception has been ${enabled ? '🟢 **ENABLED**' : '🔴 **DISABLED**'}.`
      });
    }

    if (sub === 'config') {
      const minAge = interaction.options.getInteger('min_age_days');
      const requireAvatar = interaction.options.getBoolean('require_avatar');
      const action = interaction.options.getString('action');

      const updates = { anti_alt_min_age_days: minAge };
      if (requireAvatar !== null) updates.anti_alt_require_avatar = requireAvatar ? 1 : 0;
      if (action) updates.anti_alt_action = action;

      updateGuildConfig(guildId, updates);

      logCommandAudit(interaction, 'ANTIALT_CONFIG_UPDATE', updates);

      const embed = new EmbedBuilder()
        .setTitle('⚙️ Anti-Alt Defense Policy Updated')
        .setColor(config.branding.colorSuccessInt)
        .setDescription('Account inspection parameters have been updated.')
        .addFields(
          { name: '📅 Minimum Age', value: `\`${minAge} days\``, inline: true },
          { name: '🖼️ Avatar Required', value: requireAvatar !== null ? (requireAvatar ? 'Yes' : 'No') : 'Unchanged', inline: true },
          { name: '⚡ Action', value: action ? `\`${action.toUpperCase()}\`` : 'Unchanged', inline: true }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  }
};
