import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { captureGuildSnapshot } from '../recovery/snapshot.js';
import { generateRecoveryPreview, executeSafeRestore } from '../recovery/rollback.js';
import { getBackups } from '../../database/backups.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const backupCommand = {
  data: new SlashCommandBuilder()
    .setName('backup')
    .setDescription('SPOOFY Recovery snapshot and rollback management')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('create')
        .setDescription('Create a full server snapshot (Channels, Roles, Settings)')
        .addStringOption(opt => opt.setName('name').setDescription('Backup title / label').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all existing server snapshots')
    )
    .addSubcommand(sub =>
      sub.setName('restore')
        .setDescription('Safely restore server structure from a snapshot (Owner Only)')
        .addStringOption(opt => opt.setName('id').setDescription('Backup snapshot ID').setRequired(true))
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'restore') {
      const passed = await guardCommand(interaction, {
      staffOnly: true,
        ownerOnly: true,
        botPermissions: [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageRoles],
        cooldownSeconds: 15
      });
      if (!passed) return;

      const backupId = interaction.options.getString('id');
      await interaction.deferReply();

      try {
        const preview = await generateRecoveryPreview(guild, backupId);

        // Execute recovery
        const results = await executeSafeRestore(guild, backupId, { channels: true, roles: true, settings: true });

        logCommandAudit(interaction, 'BACKUP_RESTORE', {
          backupId,
          channelsCreated: results.channelsCreated,
          rolesCreated: results.rolesCreated
        });

        const embed = new EmbedBuilder()
          .setTitle(`🔄 ${config.branding.recovery} — Recovery Completed`)
          .setColor(config.branding.colorSuccessInt)
          .setDescription(`Restoration from snapshot **${preview.backupName}** completed safely.`)
          .addFields(
            { name: '📁 Channels Rebuilt', value: `\`${results.channelsCreated}\``, inline: true },
            { name: '👑 Roles Rebuilt', value: `\`${results.rolesCreated}\``, inline: true },
            { name: '⚙️ Settings Restored', value: results.settingsRestored ? '✅ Yes' : '⚪ Skipped/Unchanged', inline: true }
          )
          .setFooter({ text: 'Security note: Compromised Admin perms were sanitized during recovery.' })
          .setTimestamp();

        if (results.errors.length > 0) {
          embed.addFields({
            name: '⚠️ Warnings / Skipped Items',
            value: results.errors.slice(0, 5).join('\n')
          });
        }

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Recovery failed: ${err.message}` });
      }
    }

    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.Administrator],
      cooldownSeconds: sub === 'create' ? 10 : 3
    });
    if (!passed) return;

    if (sub === 'create') {
      await interaction.deferReply();
      const customName = interaction.options.getString('name');

      try {
        const backup = await captureGuildSnapshot(guild, interaction.user, customName);

        logCommandAudit(interaction, 'BACKUP_CREATE', {
          backupId: backup.id,
          backupName: backup.backup_name,
          channelsCount: backup.channels.length,
          rolesCount: backup.roles.length
        });

        const embed = new EmbedBuilder()
          .setTitle(`📦 ${config.branding.recovery} — Snapshot Created`)
          .setColor(config.branding.colorSuccessInt)
          .setDescription(`Successfully captured full guild snapshot: **${backup.backup_name}**`)
          .addFields(
            { name: '🆔 Snapshot ID', value: `\`${backup.id}\``, inline: true },
            { name: '📁 Channels Saved', value: `\`${backup.channels.length}\``, inline: true },
            { name: '👑 Roles Saved', value: `\`${backup.roles.length}\``, inline: true },
            { name: '👤 Creator', value: `<@${interaction.user.id}>`, inline: true }
          )
          .setFooter({ text: 'Stored securely in SPOOFY database • Ready for rollback' })
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Snapshot creation failed: ${err.message}` });
      }
    }

    if (sub === 'list') {
      const backups = getBackups(guild.id);
      if (backups.length === 0) {
        return interaction.reply({
          content: 'ℹ️ No backups found for this server. Use `/backup create` to capture a snapshot.',
          ephemeral: true
        });
      }

      const embed = new EmbedBuilder()
        .setTitle(`📦 ${config.branding.recovery} — Saved Snapshots`)
        .setColor(config.branding.colorInt)
        .setDescription(backups.map(b => `• **${b.backup_name}** (ID: \`${b.id}\`)\n  Created <t:${b.created_at}:R> by <@${b.creator_id}>`).join('\n\n'))
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  }
};
