import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { addModerationCase, getWarningCount, getModerationCases } from '../../database/moderation.js';
import { guardCommand, checkTargetHierarchy, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const modCommand = {
  data: new SlashCommandBuilder()
    .setName('mod')
    .setDescription('Enterprise moderation suite with escalation, rate limiting, and hierarchy enforcement')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub =>
      sub.setName('warn')
        .setDescription('Issue a formal warning to a member')
        .addUserOption(opt => opt.setName('user').setDescription('Target member').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for warning').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('timeout')
        .setDescription('Temporarily timeout a member')
        .addUserOption(opt => opt.setName('user').setDescription('Target member').setRequired(true))
        .addIntegerOption(opt => opt.setName('minutes').setDescription('Timeout duration in minutes').setMinValue(1).setMaxValue(40320).setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for timeout').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('kick')
        .setDescription('Kick a member from the server')
        .addUserOption(opt => opt.setName('user').setDescription('Target member').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for kick').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('ban')
        .setDescription('Ban a member from the server')
        .addUserOption(opt => opt.setName('user').setDescription('Target member').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for ban').setRequired(false))
        .addIntegerOption(opt => opt.setName('delete_days').setDescription('Delete message history days (0-7)').setMinValue(0).setMaxValue(7).setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('unban')
        .setDescription('Unban a user from the server by their Discord ID')
        .addStringOption(opt => opt.setName('user_id').setDescription('Discord User ID to unban').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for unban').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('history')
        .setDescription('View past moderation infractions and case history for a user')
        .addUserOption(opt => opt.setName('user').setDescription('Target member to inspect').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('purge')
        .setDescription('Bulk delete messages from the current channel (Anti-Spam / Raid cleanup)')
        .addIntegerOption(opt => opt.setName('count').setDescription('Number of messages to delete (1-100)').setMinValue(1).setMaxValue(100).setRequired(true))
        .addUserOption(opt => opt.setName('user').setDescription('Only delete messages from this specific user').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('slowmode')
        .setDescription('Set slowmode delay for current channel to control chat velocity')
        .addIntegerOption(opt => opt.setName('seconds').setDescription('Slowmode delay in seconds (0 = disable)').setMinValue(0).setMaxValue(21600).setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for setting slowmode').setRequired(false))
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();

    // Map subcommand to required permissions and bot permissions
    const permMap = {
      warn: {
        required: [PermissionFlagsBits.ModerateMembers],
        bot: []
      },
      timeout: {
        required: [PermissionFlagsBits.ModerateMembers],
        bot: [PermissionFlagsBits.ModerateMembers]
      },
      kick: {
        required: [PermissionFlagsBits.KickMembers],
        bot: [PermissionFlagsBits.KickMembers]
      },
      ban: {
        required: [PermissionFlagsBits.BanMembers],
        bot: [PermissionFlagsBits.BanMembers]
      },
      unban: {
        required: [PermissionFlagsBits.BanMembers],
        bot: [PermissionFlagsBits.BanMembers]
      },
      history: {
        required: [PermissionFlagsBits.ModerateMembers],
        bot: []
      },
      purge: {
        required: [PermissionFlagsBits.ManageMessages],
        bot: [PermissionFlagsBits.ManageMessages]
      },
      slowmode: {
        required: [PermissionFlagsBits.ManageChannels],
        bot: [PermissionFlagsBits.ManageChannels]
      }
    };

    const configPerms = permMap[sub] || { required: [PermissionFlagsBits.ModerateMembers], bot: [] };

    // Enforce server-side security checks
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: configPerms.required,
      botPermissions: configPerms.bot,
      cooldownSeconds: 2
    });
    if (!passed) return;

    // Handle unban
    if (sub === 'unban') {
      const targetUserId = interaction.options.getString('user_id').trim();
      const reason = interaction.options.getString('reason') || `Unbanned by ${interaction.user.tag}`;

      await interaction.deferReply();

      try {
        await interaction.guild.bans.remove(targetUserId, reason);

        addModerationCase({
          guild_id: interaction.guild.id,
          case_type: 'UNBAN',
          user_id: targetUserId,
          user_tag: targetUserId,
          moderator_id: interaction.user.id,
          moderator_tag: interaction.user.tag,
          reason
        });

        logCommandAudit(interaction, 'UNBAN', {
          targetId: targetUserId,
          reason
        });

        return interaction.editReply({
          content: `✅ Successfully unbanned user ID \`${targetUserId}\`. Reason: *${reason}*`
        });
      } catch (err) {
        return interaction.editReply({
          content: `❌ Failed to unban user: ${err.message}`
        });
      }
    }

    // Handle history
    if (sub === 'history') {
      const targetUser = interaction.options.getUser('user');
      const cases = getModerationCases(interaction.guild.id, targetUser.id, 10);
      const totalWarns = getWarningCount(interaction.guild.id, targetUser.id);

      const embed = new EmbedBuilder()
        .setTitle(`📜 Moderation Record — ${targetUser.tag}`)
        .setColor(totalWarns > 2 ? config.branding.colorCritInt : config.branding.colorInt)
        .setDescription(`User ID: \`${targetUser.id}\` • Active Warnings: \`${totalWarns}\`\n\n**Recent Infractions (${cases.length})**:`)
        .setFooter({ text: 'SPOOFY Moderation Engine' })
        .setTimestamp();

      if (cases.length === 0) {
        embed.setDescription(`User ID: \`${targetUser.id}\`\n\n✅ Clean record: No moderation infractions or warnings recorded.`);
      } else {
        const typeIcons = {
          WARN: '⚠️',
          TIMEOUT: '⏳',
          KICK: '👢',
          BAN: '🔨',
          UNBAN: '🔓',
          QUARANTINE: '☣️',
          STRIP_ROLES: '🛡️'
        };

        for (const c of cases) {
          const icon = typeIcons[c.case_type] || '📝';
          embed.addFields({
            name: `${icon} [${c.case_type}] Case #${c.id} • <t:${c.created_at}:R>`,
            value: `• **Moderator**: <@${c.moderator_id}>\n• **Reason**: *${c.reason || 'None provided'}*${c.duration_seconds > 0 ? `\n• **Duration**: ${Math.floor(c.duration_seconds / 60)}m` : ''}`
          });
        }
      }

      return interaction.reply({ embeds: [embed] });
    }

    // Handle channel-based commands: purge and slowmode
    if (sub === 'purge') {
      const count = interaction.options.getInteger('count');
      const targetUser = interaction.options.getUser('user');

      await interaction.deferReply({ ephemeral: true });

      try {
        const channel = interaction.channel;
        const messages = await channel.messages.fetch({ limit: count });
        let toDelete = messages;

        if (targetUser) {
          toDelete = messages.filter(m => m.author.id === targetUser.id);
        }

        const deleted = await channel.bulkDelete(toDelete, true);

        logCommandAudit(interaction, 'PURGE', {
          deletedCount: deleted.size,
          channelId: channel.id,
          channelName: channel.name,
          targetUser: targetUser?.tag || null
        });

        return interaction.editReply({
          content: `🧹 Successfully purged **${deleted.size}** messages${targetUser ? ` from <@${targetUser.id}>` : ''}.`
        });
      } catch (err) {
        return interaction.editReply({
          content: `❌ Failed to purge messages: ${err.message}`
        });
      }
    }

    if (sub === 'slowmode') {
      const seconds = interaction.options.getInteger('seconds');
      const reason = interaction.options.getString('reason') || `Slowmode adjusted by ${interaction.user.tag}`;

      await interaction.deferReply();

      try {
        await interaction.channel.setRateLimitPerUser(seconds, reason);

        logCommandAudit(interaction, 'SLOWMODE', {
          channelId: interaction.channel.id,
          seconds,
          reason
        });

        const embed = new EmbedBuilder()
          .setTitle(seconds > 0 ? '⏱️ Channel Slowmode Enabled' : '🟢 Channel Slowmode Disabled')
          .setColor(seconds > 0 ? config.branding.colorMedInt : config.branding.colorSuccessInt)
          .setDescription(seconds > 0
            ? `Slowmode has been set to **${seconds} seconds** per user.`
            : 'Slowmode has been deactivated. Users can chat normally.'
          )
          .addFields(
            { name: '👤 Moderator', value: `<@${interaction.user.id}>`, inline: true },
            { name: '📝 Reason', value: reason, inline: true }
          )
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Failed to set slowmode: ${err.message}` });
      }
    }

    // Member-based commands: warn, timeout, kick, ban
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason specified';
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    if (member) {
      const hierarchy = checkTargetHierarchy(interaction, member);
      if (!hierarchy.allowed) {
        return interaction.reply({ content: hierarchy.reason, ephemeral: true });
      }
    }

    if (sub === 'warn') {
      addModerationCase({
        guild_id: interaction.guild.id,
        case_type: 'WARN',
        user_id: user.id,
        user_tag: user.tag,
        moderator_id: interaction.user.id,
        moderator_tag: interaction.user.tag,
        reason
      });

      const totalWarns = getWarningCount(interaction.guild.id, user.id);
      let escalationNote = '';

      if (totalWarns === 3 && member && member.manageable) {
        await member.timeout(15 * 60 * 1000, 'Escalation: Reached 3 warnings').catch(() => {});
        escalationNote = '\n⚡ **Escalation triggered**: User automatically timed out for 15 minutes (3rd Warning).';
      } else if (totalWarns >= 5 && member && member.bannable) {
        await member.ban({ reason: 'Escalation: Exceeded 5 warnings' }).catch(() => {});
        escalationNote = '\n🚨 **Escalation triggered**: User automatically banned for excessive warnings (5+ Warnings).';
      }

      logCommandAudit(interaction, 'WARN', {
        targetId: user.id,
        targetTag: user.tag,
        totalWarns,
        reason
      });

      const embed = new EmbedBuilder()
        .setTitle('⚠️ Member Warned')
        .setColor(config.branding.colorMedInt)
        .setDescription(`Warned <@${user.id}> (${user.tag}).${escalationNote}`)
        .addFields(
          { name: '📝 Reason', value: reason, inline: true },
          { name: '📊 Warning Count', value: `\`${totalWarns}\` active warning(s)`, inline: true },
          { name: '🛡️ Moderator', value: `<@${interaction.user.id}>`, inline: true }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'timeout') {
      const minutes = interaction.options.getInteger('minutes');
      if (!member) return interaction.reply({ content: '❌ Member not found in server.', ephemeral: true });

      await member.timeout(minutes * 60 * 1000, `${reason} (Mod: ${interaction.user.tag})`);
      addModerationCase({
        guild_id: interaction.guild.id,
        case_type: 'TIMEOUT',
        user_id: user.id,
        user_tag: user.tag,
        moderator_id: interaction.user.id,
        moderator_tag: interaction.user.tag,
        reason,
        duration_seconds: minutes * 60
      });

      logCommandAudit(interaction, 'TIMEOUT', {
        targetId: user.id,
        minutes,
        reason
      });

      return interaction.reply({
        content: `⏳ <@${user.id}> has been timed out for **${minutes} minutes**. Reason: *${reason}*`
      });
    }

    if (sub === 'kick') {
      if (!member) return interaction.reply({ content: '❌ Member not found in server.', ephemeral: true });

      await member.kick(`${reason} (Mod: ${interaction.user.tag})`);
      addModerationCase({
        guild_id: interaction.guild.id,
        case_type: 'KICK',
        user_id: user.id,
        user_tag: user.tag,
        moderator_id: interaction.user.id,
        moderator_tag: interaction.user.tag,
        reason
      });

      logCommandAudit(interaction, 'KICK', {
        targetId: user.id,
        reason
      });

      return interaction.reply({
        content: `👢 **${user.tag}** has been kicked from the server. Reason: *${reason}*`
      });
    }

    if (sub === 'ban') {
      const deleteDays = interaction.options.getInteger('delete_days') || 0;
      await interaction.guild.members.ban(user.id, {
        deleteMessageSeconds: deleteDays * 86400,
        reason: `${reason} (Mod: ${interaction.user.tag})`
      });

      addModerationCase({
        guild_id: interaction.guild.id,
        case_type: 'BAN',
        user_id: user.id,
        user_tag: user.tag,
        moderator_id: interaction.user.id,
        moderator_tag: interaction.user.tag,
        reason
      });

      logCommandAudit(interaction, 'BAN', {
        targetId: user.id,
        deleteDays,
        reason
      });

      return interaction.reply({
        content: `🔨 **${user.tag}** has been permanently banned from the server. Reason: *${reason}*`
      });
    }
  }
};
