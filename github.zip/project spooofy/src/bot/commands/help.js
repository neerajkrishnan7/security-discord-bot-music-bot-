import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { guardCommand } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const helpCommand = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('SPOOFY feature guide, command manual, and security documentation'),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, { cooldownSeconds: 2 });
    if (!passed) return;

    const embed = new EmbedBuilder()
      .setTitle(`🛡️ ${config.branding.name} — Powerful Enterprise Security Suite`)
      .setColor(config.branding.colorInt)
      .setDescription(
        `**${config.branding.name}** is an enterprise-grade Discord security & anti-nuke suite engineered to protect communities from rogue administrators, raid floods, malicious links, and catastrophic deletions.\n\n` +
        `🌐 **Live Dashboard**: [Access Dashboard](${config.dashboardUrl})`
      )
      .addFields(
        {
          name: '🚨 Emergency & Rapid Containment',
          value:
            '`/panic engage|lift` — Red Alert: freeze all channels, pause invites, maximize shields\n' +
            '`/lockdown [minutes] [reason]` — Instantly freeze entire server channels\n' +
            '`/unlockdown` — Safely restore server-wide permissions\n' +
            '`/lock [channel] [reason]` — Lock a specific text or voice channel\n' +
            '`/unlock [channel]` — Unlock a specific channel\n' +
            '`/quarantine add|remove|config` — Isolate compromised accounts & strip privileges'
        },
        {
          name: '🛡️ SPOOFY Shield & Anti-Nuke',
          value:
            '`/shield status` — View active defensive modules and threat status\n' +
            '`/shield toggle <module> <true|false>` — Toggle anti-nuke, anti-raid, etc.\n' +
            '`/shield threshold <action> <limit> <window> <punish>` — Set rate limits\n' +
            '`/whitelist list|add|remove` — Manage trusted admins exempt from limits (Owner only)\n' +
            '`/antiraid status|mode|minage|action` — Rapid join raid defense controls\n' +
            '`/antialt status|toggle|config` — Alt account and fake profile interception'
        },
        {
          name: '🤖 AutoMod & Conversational Defense',
          value:
            '`/automod status` — Live status of token leak, phishing, invite & ghost ping shields\n' +
            '`/automod toggle <filter> <true|false>` — Toggle individual chat protection filters'
        },
        {
          name: '🧹 Security Sweeper & Role Hygiene',
          value:
            '`/sweeper webhooks [clean]` — Scan all channels & delete unauthorized rogue webhooks\n' +
            '`/sweeper roles` — Audit dangerous permissions, admin sprawl, and empty roles'
        },
        {
          name: '⚙️ Server Configuration & Logging',
          value:
            '`/config view` — Inspect assigned security log channels and defaults\n' +
            '`/config logging <type> <channel>` — Assign security, mod, or member log channels\n' +
            '`/config punishment <action>` — Set automated punishment default'
        },
        {
          name: '🔍 Security Audit & Scanner',
          value:
            '`/scanner` — Audit server for dangerous permissions, bot risks, and hierarchy bugs\n' +
            '`/sentinel alerts [limit]` — View live security incidents & threats\n' +
            '`/sentinel audit [limit]` — Correlated audit log stream with actor tracking'
        },
        {
          name: '📦 Disaster Recovery & Snapshots',
          value:
            '`/backup create [name]` — Snapshot channels, roles, overwrites & settings\n' +
            '`/backup list` — List saved snapshots\n' +
            '`/backup restore <id>` — Safely reconstruct server state (Owner only)'
        },
        {
          name: '⚔️ Moderation Suite',
          value:
            '`/mod warn <user> <reason>` — Issue warning with auto-escalation\n' +
            '`/mod timeout <user> <min>` — Mute/timeout member\n' +
            '`/mod kick <user> [reason]` — Kick member\n' +
            '`/mod ban <user> [reason]` — Ban member with message purge\n' +
            '`/mod unban <user_id> [reason]` — Unban member by ID\n' +
            '`/mod history <user>` — View complete infraction case history\n' +
            '`/mod purge <count> [user]` — Bulk delete spam messages\n' +
            '`/mod slowmode <seconds>` — Control chat velocity'
        },
        {
          name: '🎶 Music & High-Fidelity Audio',
          value:
            '`/music play <query>` — Play audio stream or add to queue\n' +
            '`/music pause|resume|skip|stop` — Playback controls (voice-channel locked)\n' +
            '`/music queue|nowplaying|volume` — Queue inspection & master volume'
        },
        {
          name: '🔧 Utility & Verification',
          value:
            '`/ping` — Check gateway heartbeat, latency, and database health\n' +
            '`/serverinfo` — Server security profile, verification tier, and 2FA\n' +
            '`/userinfo [user]` — Account age, join date, permissions, and risk score\n' +
            '`/verify setup <role>` — Deploy interactive member verification gateway\n' +
            '`/ticket setup` — Deploy private ticket support channels'
        }
      )
      .setFooter({ text: `${config.branding.name} Shield • Enterprise Server Security Suite` })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }
};
