import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig } from '../../database/guildConfig.js';
import { getBotHealth } from '../health.js';
import { guardCommand } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const pingCommand = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check SPOOFY bot latency, gateway ping, and operational health'),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, { cooldownSeconds: 2 });
    if (!passed) return;

    const sent = await interaction.reply({ content: '🏓 Pinging Sentinel nodes...', fetchReply: true });
    const roundTrip = sent.createdTimestamp - interaction.createdTimestamp;
    const wsPing = client.ws.ping;
    const health = getBotHealth(client);

    const embed = new EmbedBuilder()
      .setTitle('🏓 SPOOFY System Latency & Operational Health')
      .setColor(roundTrip < 200 ? config.branding.colorSuccessInt : config.branding.colorMedInt)
      .addFields(
        { name: '🌐 Gateway Heartbeat', value: `\`${wsPing >= 0 ? wsPing : 0}ms\``, inline: true },
        { name: '⚡ Round-Trip Latency', value: `\`${roundTrip}ms\``, inline: true },
        { name: '💾 Database Storage', value: `\`${health.database.status}\` (${health.database.latencyMs}ms)`, inline: true },
        { name: '⏱️ Process Uptime', value: `\`${Math.floor(process.uptime() / 60)} minutes\``, inline: true },
        { name: '🛡️ Shield Engine', value: '`ONLINE (100% operational)`', inline: true }
      )
      .setTimestamp();

    return interaction.editReply({ content: null, embeds: [embed] });
  }
};

export const serverinfoCommand = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Inspect server creation date, security settings, and member breakdown'),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, { cooldownSeconds: 3 });
    if (!passed) return;

    const guild = interaction.guild;
    const cfg = getGuildConfig(guild.id);
    const members = guild.members.cache;
    const botCount = members.filter(m => m.user.bot).size;
    const humanCount = guild.memberCount - botCount;

    const embed = new EmbedBuilder()
      .setTitle(`🏰 ${guild.name} — Security Profile`)
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .setColor(config.branding.colorInt)
      .addFields(
        { name: '👑 Server Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: '📅 Created On', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D> (<t:${Math.floor(guild.createdTimestamp / 1000)}:R>)`, inline: true },
        { name: '🆔 Server ID', value: `\`${guild.id}\``, inline: true },
        { name: '👥 Members', value: `Total: \`${guild.memberCount}\`\nHumans: \`${humanCount}\` | Bots: \`${botCount}\``, inline: true },
        { name: '📁 Channels & Roles', value: `Channels: \`${guild.channels.cache.size}\`\nRoles: \`${guild.roles.cache.size}\``, inline: true },
        { name: '🔒 Discord Security', value: `Verification: \`Level ${guild.verificationLevel}\`\n2FA Mod Req: \`${guild.mfaLevel === 1 ? 'Enabled' : 'Disabled'}\``, inline: true },
        { name: '🛡️ SPOOFY Shield Status', value: `Shield: ${cfg.shield_enabled ? '🟢 `ACTIVE`' : '🔴 `DISABLED`'}\nAnti-Nuke: ${cfg.anti_nuke_enabled ? '🟢 `ON`' : '🔴 `OFF`'}\nLockdown: ${cfg.lockdown_active ? '🔴 `ENGAGED`' : '⚪ `OFF`'}`, inline: false }
      )
      .setFooter({ text: 'SPOOFY Server Intelligence' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }
};

export const userinfoCommand = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Deep security profile of a member (Account age, join date, permissions, risk flags)')
    .addUserOption(opt => opt.setName('user').setDescription('Target user to inspect').setRequired(false)),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, { cooldownSeconds: 3 });
    if (!passed) return;

    const user = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    const now = Date.now();
    const createdAgeDays = Math.floor((now - user.createdTimestamp) / (1000 * 60 * 60 * 24));
    const isNewAccount = createdAgeDays < 7;
    const isUnderageRisk = createdAgeDays < 3;

    const embed = new EmbedBuilder()
      .setTitle(`👤 ${user.tag} — Security Dossier`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setColor(isUnderageRisk ? config.branding.colorCritInt : isNewAccount ? config.branding.colorMedInt : config.branding.colorInt)
      .addFields(
        { name: '🆔 User ID', value: `\`${user.id}\``, inline: true },
        { name: '🤖 Bot Account', value: user.bot ? '⚠️ `Yes`' : '`No`', inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D> (\`${createdAgeDays}d ago\`)`, inline: true }
      );

    if (member) {
      const joinedAgeDays = member.joinedTimestamp ? Math.floor((now - member.joinedTimestamp) / (1000 * 60 * 60 * 24)) : 0;
      const keyPerms = [];
      if (member.permissions.has(PermissionFlagsBits.Administrator)) keyPerms.push('Administrator');
      if (member.permissions.has(PermissionFlagsBits.ManageGuild)) keyPerms.push('Manage Server');
      if (member.permissions.has(PermissionFlagsBits.ManageRoles)) keyPerms.push('Manage Roles');
      if (member.permissions.has(PermissionFlagsBits.ManageChannels)) keyPerms.push('Manage Channels');
      if (member.permissions.has(PermissionFlagsBits.BanMembers)) keyPerms.push('Ban Members');
      if (member.permissions.has(PermissionFlagsBits.KickMembers)) keyPerms.push('Kick Members');

      const roles = member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => `<@&${r.id}>`);

      embed.addFields(
        { name: '📥 Joined Server', value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:D> (\`${joinedAgeDays}d ago\`)` : 'Unknown', inline: true },
        { name: '👑 Highest Role', value: `${member.roles.highest ? `<@&${member.roles.highest.id}>` : 'None'}`, inline: true },
        { name: '🛡️ Elevated Permissions', value: keyPerms.length > 0 ? keyPerms.map(p => `\`${p}\``).join(', ') : '`Standard Member`', inline: false },
        { name: `👑 Roles (${roles.length})`, value: roles.length > 0 ? roles.slice(0, 10).join(', ') + (roles.length > 10 ? ` ...and ${roles.length - 10} more` : '') : '`None`', inline: false }
      );
    }

    const riskFlags = [];
    if (isUnderageRisk) riskFlags.push('🚨 High Risk: Account is less than 3 days old');
    else if (isNewAccount) riskFlags.push('⚠️ Moderate Risk: Account is less than 7 days old');
    if (user.bot) riskFlags.push('🤖 Automated Bot User');
    if (!member) riskFlags.push('❌ User is not currently in this server');

    embed.addFields({
      name: '🔍 Threat & Risk Flags',
      value: riskFlags.length > 0 ? riskFlags.join('\n') : '✅ No security risk indicators detected',
      inline: false
    });

    embed.setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }
};
