import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { enableEmergencyLockdown, disableEmergencyLockdown } from '../recovery/lockdown.js';
import { guardCommand, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const lockdownCommand = {
  data: new SlashCommandBuilder()
    .setName('lockdown')
    .setDescription('Emergency server lockdown to instantly neutralize raids')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addIntegerOption(opt =>
      opt.setName('duration')
        .setDescription('Duration in minutes before automatic unlock (default 15, 0 = indefinite)')
        .setMinValue(0)
        .setMaxValue(1440)
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt.setName('reason')
        .setDescription('Reason for lockdown')
        .setRequired(false)
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      botPermissions: [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageRoles],
      cooldownSeconds: 5
    });
    if (!passed) return;

    const duration = interaction.options.getInteger('duration') ?? 15;
    const reason = interaction.options.getString('reason') || 'Emergency administrative lockdown';
    const guild = interaction.guild;

    await interaction.deferReply();

    try {
      const result = await enableEmergencyLockdown(guild, client, {
        durationMinutes: duration,
        reason: `${reason} (Authorized by ${interaction.user.tag})`
      });

      logCommandAudit(interaction, 'LOCKDOWN_ENABLE', {
        duration,
        reason,
        lockedChannelsCount: result.lockedChannelsCount
      });

      const embed = new EmbedBuilder()
        .setTitle('🚨 SERVER LOCKDOWN ENGAGED')
        .setColor(config.branding.colorCritInt)
        .setDescription(`**${guild.name}** has been placed under emergency lockdown by <@${interaction.user.id}>.`)
        .addFields(
          { name: '🔒 Channels Locked', value: `\`${result.lockedChannelsCount}\` channels`, inline: true },
          { name: '⏱️ Duration', value: duration > 0 ? `\`${duration} minutes\` (Auto-Unlock)` : '`Indefinite`', inline: true },
          { name: '📝 Reason', value: reason, inline: false }
        )
        .setFooter({ text: 'Admins and Incident Responders retain access • Use /unlockdown to lift' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `❌ Failed to engage lockdown: ${err.message}` });
    }
  }
};

export const unlockdownCommand = {
  data: new SlashCommandBuilder()
    .setName('unlockdown')
    .setDescription('Lift emergency server lockdown and restore channel permissions')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption(opt =>
      opt.setName('reason')
        .setDescription('Reason for lifting lockdown')
        .setRequired(false)
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageGuild],
      botPermissions: [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageRoles],
      cooldownSeconds: 5
    });
    if (!passed) return;

    const reason = interaction.options.getString('reason') || 'Lockdown lifted by administrator';
    const guild = interaction.guild;

    await interaction.deferReply();

    try {
      const result = await disableEmergencyLockdown(guild, client, {
        reason: `${reason} (Authorized by ${interaction.user.tag})`
      });

      logCommandAudit(interaction, 'LOCKDOWN_DISABLE', {
        reason,
        unlockedChannelsCount: result.unlockedChannelsCount
      });

      const embed = new EmbedBuilder()
        .setTitle('🟢 SERVER LOCKDOWN LIFTED')
        .setColor(config.branding.colorSuccessInt)
        .setDescription(`Normal permissions have been restored across **${result.unlockedChannelsCount}** channels.`)
        .addFields({ name: '👤 Lifted By', value: `<@${interaction.user.id}>`, inline: true })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `❌ Failed to lift lockdown: ${err.message}` });
    }
  }
};
