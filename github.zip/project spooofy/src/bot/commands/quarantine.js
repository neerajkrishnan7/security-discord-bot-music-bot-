import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';
import { addModerationCase } from '../../database/moderation.js';
import { executePunishment } from '../shield/antiNuke.js';
import { guardCommand, checkTargetHierarchy, logCommandAudit } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const quarantineCommand = {
  data: new SlashCommandBuilder()
    .setName('quarantine')
    .setDescription('Instantly isolate, restrict, and neutralize compromised accounts or rogue staff')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Quarantine a member: strips dangerous roles and restricts channel access')
        .addUserOption(opt => opt.setName('user').setDescription('Target member to quarantine').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for quarantine').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Release a member from quarantine')
        .addUserOption(opt => opt.setName('user').setDescription('Target member to release').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for release').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('config')
        .setDescription('Set or update the designated quarantine role for this server')
        .addRoleOption(opt => opt.setName('role').setDescription('Role with zero permissions for quarantined members').setRequired(true))
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ManageRoles],
      botPermissions: [PermissionFlagsBits.ManageRoles, PermissionFlagsBits.ModerateMembers],
      cooldownSeconds: 3
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'config') {
      const role = interaction.options.getRole('role');
      const me = guild.members.me;

      if (role.position >= me.roles.highest.position) {
        return interaction.reply({
          content: `❌ The quarantine role <@&${role.id}> is higher than or equal to SPOOFY's highest role. Please place the bot role above it.`,
          ephemeral: true
        });
      }

      updateGuildConfig(guild.id, { quarantine_role_id: role.id });

      logCommandAudit(interaction, 'QUARANTINE_CONFIG', {
        roleId: role.id,
        roleName: role.name
      });

      return interaction.reply({
        content: `✅ Designated quarantine role set to <@&${role.id}>. Quarantined members will now receive this role and have their other roles stripped.`,
        ephemeral: false
      });
    }

    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || `Quarantine action by ${interaction.user.tag}`;
    const member = await guild.members.fetch(user.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: '❌ Target member not found in this server.', ephemeral: true });
    }

    const hierarchy = checkTargetHierarchy(interaction, member, 'member');
    if (!hierarchy.allowed) {
      return interaction.reply({ content: hierarchy.reason, ephemeral: true });
    }

    await interaction.deferReply();

    if (sub === 'add') {
      try {
        const actionTaken = await executePunishment(guild, member, 'quarantine', reason);

        addModerationCase({
          guild_id: guild.id,
          case_type: 'QUARANTINE',
          user_id: user.id,
          user_tag: user.tag,
          moderator_id: interaction.user.id,
          moderator_tag: interaction.user.tag,
          reason,
          duration_seconds: 28 * 86400
        });

        logCommandAudit(interaction, 'QUARANTINE_ADD', {
          targetId: user.id,
          targetTag: user.tag,
          actionTaken,
          reason
        });

        const embed = new EmbedBuilder()
          .setTitle('☣️ Member Quarantined')
          .setColor(config.branding.colorCritInt)
          .setDescription(`<@${user.id}> (${user.tag}) has been quarantined and isolated from the server.`)
          .addFields(
            { name: '⚡ Action Result', value: actionTaken, inline: true },
            { name: '👤 Moderator', value: `<@${interaction.user.id}>`, inline: true },
            { name: '📝 Reason', value: reason, inline: false }
          )
          .setFooter({ text: 'SPOOFY Isolation Cell • All dangerous privileges revoked' })
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Failed to quarantine member: ${err.message}` });
      }
    }

    if (sub === 'remove') {
      try {
        const guildConfig = getGuildConfig(guild.id);
        const quarantineRoleId = guildConfig.quarantine_role_id;

        if (member.isCommunicationDisabled()) {
          await member.timeout(null, `Quarantine lifted by ${interaction.user.tag}`);
        }

        if (quarantineRoleId && member.roles.cache.has(quarantineRoleId)) {
          await member.roles.remove(quarantineRoleId, `Quarantine lifted by ${interaction.user.tag}`);
        }

        addModerationCase({
          guild_id: guild.id,
          case_type: 'UNQUARANTINE',
          user_id: user.id,
          user_tag: user.tag,
          moderator_id: interaction.user.id,
          moderator_tag: interaction.user.tag,
          reason
        });

        logCommandAudit(interaction, 'QUARANTINE_REMOVE', {
          targetId: user.id,
          targetTag: user.tag,
          reason
        });

        const embed = new EmbedBuilder()
          .setTitle('🟢 Member Released from Quarantine')
          .setColor(config.branding.colorSuccessInt)
          .setDescription(`<@${user.id}> (${user.tag}) has been released from quarantine.`)
          .addFields(
            { name: '👤 Released By', value: `<@${interaction.user.id}>`, inline: true },
            { name: '📝 Reason', value: reason, inline: true }
          )
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ content: `❌ Failed to remove quarantine: ${err.message}` });
      }
    }
  }
};
