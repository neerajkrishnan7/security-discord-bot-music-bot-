import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getAlerts, getAlertStats } from '../../database/alerts.js';
import { getAuditLogs } from '../../database/moderation.js';
import { guardCommand } from '../shield/commandGuard.js';
import { config } from '../../config.js';

export const sentinelCommand = {
  data: new SlashCommandBuilder()
    .setName('sentinel')
    .setDescription('SPOOFY Sentinel security audit and alerts monitor')
    .setDefaultMemberPermissions(PermissionFlagsBits.ViewAuditLog)
    .addSubcommand(sub =>
      sub.setName('alerts')
        .setDescription('View recent security alerts detected by SPOOFY Sentinel')
        .addIntegerOption(opt => opt.setName('limit').setDescription('Number of alerts (default 5)').setMinValue(1).setMaxValue(15))
    )
    .addSubcommand(sub =>
      sub.setName('audit')
        .setDescription('View recent security-relevant audit logs')
        .addIntegerOption(opt => opt.setName('limit').setDescription('Number of entries (default 5)').setMinValue(1).setMaxValue(15))
    ),

  async execute(interaction, client) {
    const passed = await guardCommand(interaction, {
      staffOnly: true,
      requiredPermissions: [PermissionFlagsBits.ViewAuditLog],
      cooldownSeconds: 3
    });
    if (!passed) return;

    const sub = interaction.options.getSubcommand();
    const limit = interaction.options.getInteger('limit') || 5;
    const guildId = interaction.guild.id;

    if (sub === 'alerts') {
      const alerts = getAlerts(guildId, limit);
      const stats = getAlertStats(guildId);

      if (alerts.length === 0) {
        return interaction.reply({
          content: '🛡️ **SPOOFY Sentinel**: No active security threats or incidents recorded for this server.',
          ephemeral: true
        });
      }

      const embed = new EmbedBuilder()
        .setTitle(`🛡️ ${config.branding.sentinel} — Incident Log`)
        .setColor(config.branding.colorInt)
        .setDescription(`Showing latest **${alerts.length}** alerts.\n**Total**: ${stats.total} | 🚨 **Critical**: ${stats.critical} | ⚠️ **High**: ${stats.high}`)
        .setTimestamp();

      for (const a of alerts) {
        embed.addFields({
          name: `${a.severity === 'CRITICAL' ? '🚨' : a.severity === 'HIGH' ? '⚠️' : 'ℹ️'} [${a.severity}] ${a.title}`,
          value: `• **Actor**: <@${a.actor_id || 'N/A'}> (${a.actor_tag || 'N/A'})\n• **Response**: \`${a.action_taken || 'Logged'}\`\n• **Status**: \`${a.status}\` • <t:${a.created_at}:R>`
        });
      }

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'audit') {
      const logs = getAuditLogs(guildId, limit);
      if (logs.length === 0) {
        return interaction.reply({ content: 'ℹ️ No audit events logged yet.', ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setTitle(`📜 ${config.branding.sentinel} — Audit Log Stream`)
        .setColor(config.branding.colorInt)
        .setDescription(logs.map(l => `• \`${l.event_type}\` by <@${l.actor_id || 'N/A'}> on **${l.target_name || 'N/A'}** (<t:${l.created_at}:R>)\n  *Reason: ${l.reason || 'None'}*`).join('\n\n'))
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  }
};
