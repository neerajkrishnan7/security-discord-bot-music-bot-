import { getDb } from '../database/db.js';

let startTime = Date.now();

export function getBotHealth(client) {
  const uptimeMs = Date.now() - startTime;
  const memory = process.memoryUsage();

  // Test DB connection
  let dbStatus = 'HEALTHY';
  let dbLatencyMs = 0;
  try {
    const t0 = performance.now();
    const db = getDb();
    db.prepare('SELECT 1').get();
    dbLatencyMs = Math.round((performance.now() - t0) * 100) / 100;
  } catch (err) {
    dbStatus = 'ERROR: ' + err.message;
  }

  const isClientReady = Boolean(client && client.isReady());
  const wsPing = isClientReady && client.ws ? (client.ws.ping ?? -1) : -1;
  const guildCount = isClientReady && client.guilds?.cache ? client.guilds.cache.size : 0;
  const userCount = isClientReady && client.users?.cache ? client.users.cache.size : 0;

  let overallStatus = 'HEALTHY';
  if (!isClientReady) overallStatus = 'OFFLINE_OR_CONNECTING';
  else if (wsPing > 300) overallStatus = 'HIGH_LATENCY';
  else if (dbStatus !== 'HEALTHY') overallStatus = 'DEGRADED';

  return {
    status: overallStatus,
    timestamp: Date.now(),
    gateway: {
      isReady: isClientReady,
      pingMs: wsPing,
      guildCount,
      userCount,
      shardId: client?.shard?.ids?.[0] ?? 0
    },
    database: {
      status: dbStatus,
      latencyMs: dbLatencyMs,
      type: 'SQLite (WAL Mode)'
    },
    system: {
      uptimeSeconds: Math.floor(uptimeMs / 1000),
      memoryRssMb: Math.round(memory.rss / (1024 * 1024)),
      memoryHeapMb: Math.round(memory.heapUsed / (1024 * 1024)),
      nodeVersion: process.version,
      platform: process.platform
    }
  };
}
