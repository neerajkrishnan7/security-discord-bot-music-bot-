import { PermissionFlagsBits } from 'discord.js';

export async function scanServerPermissions(guild) {
  if (!guild) throw new Error('Guild not resolved');

  const findings = [];
  let riskScore = 0; // 0 = Clean, 100 = Maximum vulnerability

  const everyoneRole = guild.roles.everyone;
  const me = guild.members.me;

  // 1. Check @everyone dangerous permissions
  const dangerousEveryonePerms = [
    { flag: PermissionFlagsBits.Administrator, name: 'Administrator', risk: 40 },
    { flag: PermissionFlagsBits.ManageGuild, name: 'Manage Server', risk: 25 },
    { flag: PermissionFlagsBits.ManageRoles, name: 'Manage Roles', risk: 25 },
    { flag: PermissionFlagsBits.ManageChannels, name: 'Manage Channels', risk: 20 },
    { flag: PermissionFlagsBits.BanMembers, name: 'Ban Members', risk: 20 },
    { flag: PermissionFlagsBits.KickMembers, name: 'Kick Members', risk: 15 },
    { flag: PermissionFlagsBits.MentionEveryone, name: 'Mention Everyone', risk: 15 },
    { flag: PermissionFlagsBits.ManageWebhooks, name: 'Manage Webhooks', risk: 15 }
  ];

  for (const p of dangerousEveryonePerms) {
    if (everyoneRole.permissions.has(p.flag)) {
      findings.push({
        severity: 'CRITICAL',
        target: '@everyone Role',
        title: `@everyone has "${p.name}" Permission`,
        description: `All users and raid bots entering the server immediately inherit "${p.name}".`,
        recommendation: `Revoke "${p.name}" on @everyone in Server Settings -> Roles.`
      });
      riskScore += p.risk;
    }
  }

  // 2. Roles with Administrator
  const adminRoles = guild.roles.cache.filter(r => !r.managed && r.id !== guild.id && r.permissions.has(PermissionFlagsBits.Administrator));
  if (adminRoles.size > 3) {
    findings.push({
      severity: 'HIGH',
      target: 'Server Roles',
      title: `Excessive Administrator Roles (${adminRoles.size} roles)`,
      description: `Multiple distinct roles have Administrator privileges: ${adminRoles.map(r => r.name).join(', ')}.`,
      recommendation: 'Consolidate Administrator permissions to a single executive staff role.'
    });
    riskScore += 15;
  }

  // 3. Bot Role Hierarchy Check
  if (me) {
    const higherRoles = guild.roles.cache.filter(r => r.position > me.roles.highest.position && !r.managed);
    if (higherRoles.size > 0) {
      findings.push({
        severity: 'MEDIUM',
        target: 'Role Hierarchy',
        title: `SPOOFY is positioned below ${higherRoles.size} roles`,
        description: `Roles [${higherRoles.map(r => r.name).join(', ')}] are positioned above SPOOFY. SPOOFY cannot moderate members with these roles.`,
        recommendation: 'Move the SPOOFY bot role to the top of the role list in Server Settings.'
      });
      riskScore += 10;
    }
  }

  // 4. Verification Level Check
  if (guild.verificationLevel === 0) {
    findings.push({
      severity: 'MEDIUM',
      target: 'Guild Settings',
      title: 'Verification Level is "None"',
      description: 'Anyone can join and post without email verification or account age limits.',
      recommendation: 'Increase server verification level to Low or Medium in Server Settings.'
    });
    riskScore += 10;
  }

  // 5. 2FA Server Moderation Check
  if (guild.mfaLevel === 0) {
    findings.push({
      severity: 'LOW',
      target: 'Guild Settings',
      title: '2FA Requirement for Moderation is Disabled',
      description: 'Moderators can perform actions without Two-Factor Authentication enabled.',
      recommendation: 'Enable 2FA Requirement for Moderation in Server Settings -> Safety Setup.'
    });
    riskScore += 5;
  }

  // 6. Bot permissions audit
  const bots = guild.members.cache.filter(m => m.user.bot);
  const botsWithAdmin = bots.filter(b => b.permissions.has(PermissionFlagsBits.Administrator) && b.id !== me?.id);
  if (botsWithAdmin.size > 2) {
    findings.push({
      severity: 'MEDIUM',
      target: 'Integrations / Bots',
      title: `${botsWithAdmin.size} Third-Party Bots have Administrator`,
      description: `Bots [${botsWithAdmin.map(b => b.user.tag).join(', ')}] have full Administrator privileges. If compromised, they can wipe the server.`,
      recommendation: 'Restrict third-party bots to least-privilege roles without Administrator.'
    });
    riskScore += 10;
  }

  const securityScore = Math.max(0, 100 - riskScore);
  let statusRating = 'EXCELLENT';
  if (securityScore < 50) statusRating = 'CRITICAL';
  else if (securityScore < 75) statusRating = 'WARNING';
  else if (securityScore < 90) statusRating = 'GOOD';

  return {
    guildId: guild.id,
    guildName: guild.name,
    scannedAt: Math.floor(Date.now() / 1000),
    securityScore,
    statusRating,
    findingsCount: findings.length,
    findings
  };
}
