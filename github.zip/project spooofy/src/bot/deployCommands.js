import { REST, Routes } from 'discord.js';
import { config } from '../config.js';

export async function deploySlashCommands(commandList) {
  if (!config.token || !config.clientId) {
    console.log('[Discord] Skipping Slash command deployment: DISCORD_TOKEN or CLIENT_ID not set in .env');
    return;
  }

  const commandsPayload = commandList.map(c => c.data.toJSON());
  const rest = new REST({ version: '10' }).setToken(config.token);

  try {
    console.log(`[Discord] Deploying ${commandsPayload.length} application (/) commands...`);

    if (config.guildId) {
      await rest.put(
        Routes.applicationGuildCommands(config.clientId, config.guildId),
        { body: commandsPayload }
      );
      console.log(`[Discord] Successfully registered guild slash commands for guild ${config.guildId}!`);
    } else {
      await rest.put(
        Routes.applicationCommands(config.clientId),
        { body: commandsPayload }
      );
      console.log('[Discord] Successfully registered global slash commands!');
    }
  } catch (error) {
    console.error('[Discord] Error deploying slash commands:', error.message);
  }
}
