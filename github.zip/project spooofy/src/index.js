import { config } from './config.js';
import { getDb } from './database/db.js';
import { createBotClient, startBot } from './bot/client.js';
import { createServer } from './server/app.js';
import { getGuildConfig } from './database/guildConfig.js';
import { createAlert } from './database/alerts.js';
import { logAuditEvent, addModerationCase } from './database/moderation.js';
import { captureGuildSnapshot } from './bot/recovery/snapshot.js';

async function bootstrap() {
  console.log('====================================================');
  console.log(`🛡️  ${config.branding.name} — Advanced Security & Anti-Nuke`);
  console.log('   Engine: ' + config.branding.shield);
  console.log('   Sentinel: ' + config.branding.sentinel);
  console.log('   Recovery: ' + config.branding.recovery);
  console.log('====================================================');

  // 1. Initialize SQLite Database
  const db = getDb();
  console.log('[Database] Connected to SQLite database:', config.databasePath);

  // 2. Seed initial demo data for default guild if database is empty
  seedInitialData();

  // 3. Create Discord Bot Client
  const { client, commandList } = createBotClient();

  // 4. Create Web & API Server
  const { server } = createServer(client);

  server.listen(config.port, () => {
    console.log(`[API Server] SPOOFY Security API listening on port ${config.port}`);
    console.log(`[Dashboard] Access Dashboard at ${config.dashboardUrl} (or http://localhost:${config.port})`);
  });

  // 5. Connect to Discord Gateway
  await startBot(client, commandList);

  // Handle process shutdown
  process.on('SIGINT', () => gracefulExit(client, server, db));
  process.on('SIGTERM', () => gracefulExit(client, server, db));
}

function seedInitialData() {
  const defaultGuildId = config.guildId || 'spoofy-main-server';
  const cfg = getGuildConfig(defaultGuildId);

  const db = getDb();
  const alertCount = db.prepare('SELECT COUNT(*) as count FROM security_alerts WHERE guild_id = ?').get(defaultGuildId)?.count;

  if (alertCount === 0) {
    console.log('[Database] Initializing baseline security records for', defaultGuildId);

    // Initial alert
    createAlert({
      guild_id: defaultGuildId,
      severity: 'LOW',
      category: 'INITIALIZATION',
      title: 'SPOOFY Shield Active Defense Initialized',
      description: 'Master anti-nuke, anti-raid, and audit monitoring engines are running at full vigilance.',
      actor_id: 'SYSTEM',
      actor_tag: 'SPOOFY Shield Core',
      action_taken: 'Continuous Audit Log & Gateway Sentinel Monitoring Enabled'
    });

    // Baseline audit log
    logAuditEvent({
      guild_id: defaultGuildId,
      event_type: 'SYSTEM_STARTUP',
      actor_id: 'SYSTEM',
      actor_tag: 'SPOOFY Core',
      target_name: 'Guild Security Core',
      reason: 'Automated shield initialization'
    });

    // Seed baseline owner staff record
    db.prepare(`
      INSERT OR IGNORE INTO staff_members (id, user_id, discord_id, username, avatar, role, status, created_by, created_at, notes)
      VALUES ('stf_owner', 'usr_owner', '999999999999999999', 'SPOOFY Project Owner', 'https://cdn.discordapp.com/embed/avatars/0.png', 'OWNER', 'ACTIVE', 'system', strftime('%s', 'now'), 'Chief Security Architect')
    `).run();

    // Seed baseline senior staff record
    db.prepare(`
      INSERT OR IGNORE INTO staff_members (id, user_id, discord_id, username, avatar, role, status, created_by, created_at, notes)
      VALUES ('stf_guardian', 'usr_guardian', '888777666555444333', 'SeniorStaffGuardian', 'https://cdn.discordapp.com/embed/avatars/1.png', 'SENIOR_STAFF', 'ACTIVE', 'system', strftime('%s', 'now'), 'Incident Response Team Lead')
    `).run();

    // Seed sample internal announcement
    db.prepare(`
      INSERT OR IGNORE INTO internal_announcements (id, title, content, target_roles, author_id, author_tag, created_at)
      VALUES ('ann_welcome', 'Welcome to SPOOFY Operations Portal', 'All staff members must adhere to least-privilege principles and verify audit logs before taking manual moderation interventions.', 'ALL', '999999999999999999', 'SPOOFY Project Owner', strftime('%s', 'now'))
    `).run();

    // Seed sample incident record
    db.prepare(`
      INSERT OR IGNORE INTO internal_incidents (id, title, description, severity, status, affected_services, assigned_staff_id, assigned_staff_tag, investigation_notes, created_at, updated_at)
      VALUES ('inc_gateway_audit', 'Discord API Rate-Limit Mitigation', 'Discord Audit Log ingestion latency increased by 400ms during peak hours. Exponential backoff retry handler activated.', 'LOW', 'MONITORING', 'Discord Gateway, Audit Ingestion', '888777666555444333', 'SeniorStaffGuardian', 'Jittered polling interval increased from 500ms to 750ms. Latency normalized.', strftime('%s', 'now'), strftime('%s', 'now'))
    `).run();
  }
}

function gracefulExit(client, server, db) {
  console.log('\n[SPOOFY] Gracefully shutting down...');
  if (client) client.destroy();
  if (server) server.close();
  if (db) db.close();
  process.exit(0);
}

bootstrap().catch((err) => {
  console.error('[Fatal Error] Bootstrap failure:', err);
  process.exit(1);
});
