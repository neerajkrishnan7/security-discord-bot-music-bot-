import crypto from 'crypto';
import { config } from '../config.js';
import { upsertUser, createSession, getSession, deleteSession } from '../database/users.js';
import { getStaffMember, STAFF_ROLE_RANKS } from '../database/staff.js';

// In-memory OAuth2 state store for CSRF protection
const oauthStates = new Map();

export function parseCookies(req) {
  const list = {};
  const rc = req.headers.cookie;
  if (rc) {
    rc.split(';').forEach(cookie => {
      const parts = cookie.split('=');
      if (parts.length >= 2) {
        list[parts.shift().trim()] = decodeURIComponent(parts.join('='));
      }
    });
  }
  return list;
}

/**
 * Authentication Middleware: Resolves session token and attaches req.user & req.staffMember
 */
export function authenticateUser(req, res, next) {
  const cookies = parseCookies(req);
  const authHeader = req.headers.authorization;
  const token = cookies.spoofy_session || (authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null);

  if (!token) {
    req.user = null;
    req.staffMember = null;
    req.isSystemAdmin = false;
    return next();
  }

  const session = getSession(token);
  if (!session) {
    req.user = null;
    req.staffMember = null;
    req.isSystemAdmin = false;
    return next();
  }

  req.user = {
    id: session.user_id,
    discord_id: session.discord_id,
    username: session.username,
    avatar: session.avatar,
    email: session.email,
    is_system_admin: Boolean(session.is_system_admin)
  };

  // Check if user is also internal staff member
  const staff = getStaffMember(session.discord_id);
  req.staffMember = staff || null;

  // Check if system administrator (Bot owner or internal OWNER role)
  req.isSystemAdmin = Boolean(
    req.user.is_system_admin ||
    (config.botOwnerId && req.user.discord_id === config.botOwnerId) ||
    staff?.role === 'OWNER'
  );

  next();
}

/**
 * Guard: Require authenticated user
 */
export function requireAuth(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized: Session required. Please log in with Discord.' });
  }
  next();
}

/**
 * Guard: Cross-Guild Isolation & Authorization
 * Strictly validates that user has management permissions for the requested guildId.
 */
export function requireGuildPermission(client, requiredPermission = 'ManageGuild') {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized: Please log in.' });
    }

    const guildId = req.params.guildId;
    if (!guildId) {
      return res.status(400).json({ error: 'guildId parameter is required' });
    }

    // Global Project Owner bypasses for platform support/maintenance
    if (req.isSystemAdmin) {
      return next();
    }

    // If bot client is connected and guild is in cache, verify real Discord permissions
    if (client && client.isReady() && client.guilds.cache.has(guildId)) {
      const guild = client.guilds.cache.get(guildId);

      // Check if user is the actual guild owner
      if (guild.ownerId === req.user.discord_id) {
        return next();
      }

      try {
        const member = await guild.members.fetch(req.user.discord_id).catch(() => null);
        if (member && (member.permissions.has('Administrator') || member.permissions.has(requiredPermission))) {
          return next();
        }
      } catch (e) {
        // Fall through to unauthorized
      }
      return res.status(403).json({ error: 'Forbidden: You do not have permission to manage this Discord server.' });
    }

    // Fallback in Local / Simulator mode
    // Only allow if user is matching the mock owner id or system admin
    if (req.user.discord_id === '999999999999999999' || req.user.is_system_admin) {
      return next();
    }

    // Prevent cross-guild leakage
    return res.status(403).json({ error: 'Forbidden: Guild isolation enforced. You are not authorized for this guild.' });
  };
}

/**
 * Guard: Strictly require Server Owner privileges for high-consequence operations
 * (Restoring backups, modifying trusted admin whitelist)
 */
export function requireGuildOwner(client) {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized: Please log in.' });
    }

    const guildId = req.params.guildId;
    if (!guildId) {
      return res.status(400).json({ error: 'guildId parameter is required' });
    }

    // Global System Admin bypass
    if (req.isSystemAdmin) {
      return next();
    }

    if (client && client.isReady() && client.guilds.cache.has(guildId)) {
      const guild = client.guilds.cache.get(guildId);
      if (guild.ownerId === req.user.discord_id) {
        return next();
      }
      return res.status(403).json({ error: 'Forbidden: Owner Protection. This operation requires Server Owner privileges.' });
    }

    // Local simulator fallback
    if (req.user.discord_id === '999999999999999999') {
      return next();
    }

    return res.status(403).json({ error: 'Forbidden: This action is strictly restricted to the Server Owner.' });
  };
}

/**
 * Guard: Require internal staff role
 */
export function requireStaff(minRole = 'SUPPORT_AGENT') {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized: Please log in.' });
    }

    // Project Owner bypass
    if (req.isSystemAdmin) {
      return next();
    }

    if (!req.staffMember || req.staffMember.status !== 'ACTIVE') {
      return res.status(403).json({ error: 'Access Denied: This portal requires authorized SPOOFY staff credentials.' });
    }

    const userRank = STAFF_ROLE_RANKS[req.staffMember.role] || 0;
    const requiredRank = STAFF_ROLE_RANKS[minRole] || 0;

    if (userRank < requiredRank) {
      return res.status(403).json({ error: `Access Denied: Requires staff role ${minRole} or higher.` });
    }

    next();
  };
}

/**
 * Guard: Require global project owner / system admin
 */
export function requireSystemAdmin(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized: Please log in.' });
  }

  if (!req.isSystemAdmin) {
    return res.status(403).json({ error: 'Access Denied: Restricted to SPOOFY Project Owner.' });
  }

  next();
}

/**
 * Generate Discord OAuth2 Authorization URL
 */
export function getDiscordOAuthUrl() {
  const state = crypto.randomBytes(16).toString('hex');
  oauthStates.set(state, Date.now() + 10 * 60 * 1000); // 10 min expiry

  const redirectUri = encodeURIComponent(`${config.dashboardUrl}/api/auth/discord/callback`);
  const clientId = config.clientId || '123456789012345678';
  const scopes = encodeURIComponent('identify guilds email');

  return `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scopes}&state=${state}`;
}

/**
 * Exchange OAuth2 Code for User Profile
 */
export async function exchangeOAuthCode(code, state) {
  if (!oauthStates.has(state) || Date.now() > oauthStates.get(state)) {
    throw new Error('Invalid or expired OAuth state (CSRF Protection)');
  }
  oauthStates.delete(state);

  // If running with mock/placeholder credentials, return mock user
  if (!config.token || !process.env.CLIENT_SECRET) {
    return {
      discord_id: '999999999999999999',
      username: 'SPOOFY Operative',
      discriminator: '0001',
      avatar: 'spoofy_mascot.jpg',
      email: 'admin@spoofy.security',
      is_system_admin: 1
    };
  }

  const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    body: new URLSearchParams({
      client_id: config.clientId,
      client_secret: process.env.CLIENT_SECRET,
      grant_type: 'authorization_code',
      code,
      redirect_uri: `${config.dashboardUrl}/api/auth/discord/callback`
    }),
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });

  if (!tokenResponse.ok) {
    throw new Error('Failed to exchange authorization code with Discord');
  }

  const tokenData = await tokenResponse.json();
  const userResponse = await fetch('https://discord.com/api/users/@me', {
    headers: { Authorization: `Bearer ${tokenData.access_token}` }
  });

  if (!userResponse.ok) {
    throw new Error('Failed to fetch user profile from Discord');
  }

  const userData = await userResponse.json();
  const isSysAdmin = config.botOwnerId && userData.id === config.botOwnerId;

  return {
    discord_id: userData.id,
    username: userData.username,
    discriminator: userData.discriminator,
    avatar: userData.avatar,
    email: userData.email,
    is_system_admin: isSysAdmin ? 1 : 0
  };
}
