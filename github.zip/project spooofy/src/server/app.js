import express from 'express';
import cors from 'cors';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { createApiRouter } from './routes/api.js';
import { authRouter } from './routes/authRoutes.js';
import { createAdminRouter } from './routes/adminRoutes.js';
import { createStaffRouter } from './routes/staffRoutes.js';
import { publicRouter } from './routes/publicRoutes.js';
import { authenticateUser } from './auth.js';
import { initWebSocketServer } from './ws.js';
import { config } from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createServer(client) {
  const app = express();
  const server = http.createServer(app);

  // Initialize WebSockets
  initWebSocketServer(server);

  const allowedOrigins = [
    config.dashboardUrl,
    'http://localhost:5173',
    'http://localhost:4000',
    'http://127.0.0.1:5173',
    'http://127.0.0.1:4000'
  ];

  app.use(cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      if (config.env !== 'production' || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(new Error('CORS blocked: Origin not authorized'));
    },
    credentials: true
  }));

  app.use(express.json());

  // Global Session Authentication Middleware
  app.use(authenticateUser);

  // Static assets (Mascot image, branding)
  app.use('/assets', express.static(path.join(__dirname, '../../assets')));

  // Mount API Routers
  app.use('/api/auth', authRouter);
  app.use('/api/public', publicRouter);
  app.use('/api/admin', createAdminRouter(client));
  app.use('/api/staff', createStaffRouter());
  app.use('/api', createApiRouter(client));

  // Serve Dashboard build in production if available
  const dashboardDist = path.join(__dirname, '../../dashboard/dist');
  app.use(express.static(dashboardDist));

  // Fallback route for SPA dashboard (Express 5 compatible)
  app.use((req, res, next) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/ws') || req.path.startsWith('/assets')) {
      return next();
    }
    const indexPath = path.join(dashboardDist, 'index.html');
    res.sendFile(indexPath, (err) => {
      if (err) {
        res.json({
          status: 'online',
          bot: config.branding.name,
          dashboardNote: 'Dashboard development server running at ' + config.dashboardUrl,
          apiDocumentation: '/api/health'
        });
      }
    });
  });

  return { app, server };
}
