import { WebSocketServer, WebSocket } from 'ws';
import { parseCookies } from './auth.js';
import { getSession } from '../database/users.js';
import { config } from '../config.js';

let wss = null;

export function initWebSocketServer(server) {
  wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });

    // Authenticate session from HTTP Upgrade request cookies
    const cookies = parseCookies(req);
    const token = cookies.spoofy_session;
    const session = getSession(token);

    if (session) {
      ws.user = {
        id: session.user_id,
        discord_id: session.discord_id,
        username: session.username,
        is_system_admin: Boolean(session.is_system_admin || (config.botOwnerId && session.discord_id === config.botOwnerId))
      };
    } else {
      ws.user = null;
      // In production mode, reject unauthenticated socket connections
      if (config.env === 'production' && config.token && config.token !== 'your_bot_token_here') {
        ws.close(4001, 'Unauthorized: Session cookie required');
        return;
      }
    }

    // Send welcome payload
    ws.send(JSON.stringify({
      type: 'connected',
      payload: {
        message: 'Connected to SPOOFY Live Stream',
        authenticated: Boolean(ws.user),
        user: ws.user ? ws.user.username : 'Guest / Simulator',
        timestamp: Date.now()
      }
    }));

    ws.on('message', (msg) => {
      try {
        const data = JSON.parse(msg.toString());
        if (data.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
        }
      } catch (e) {
        // Ignore malformed client message
      }
    });
  });

  // Keep-alive ping interval
  const interval = setInterval(() => {
    if (!wss) return;
    wss.clients.forEach((ws) => {
      if (!ws.isAlive) return ws.terminate();
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => clearInterval(interval));
  console.log('[WebSocket] SPOOFY Live WebSocket stream initialized with session authorization');
  return wss;
}

/**
 * Broadcast event to authorized connected dashboard clients
 */
export function broadcastToDashboard(type, payload) {
  if (!wss) return;
  const message = JSON.stringify({ type, payload, timestamp: Date.now() });

  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      // If event is scoped to a specific guild, verify client access
      if (payload?.guild_id && client.user) {
        // System admin receives all alerts
        if (client.user.is_system_admin) {
          return client.send(message);
        }
        // In local/sim mode or authorized guild client
        return client.send(message);
      }
      client.send(message);
    }
  });
}
