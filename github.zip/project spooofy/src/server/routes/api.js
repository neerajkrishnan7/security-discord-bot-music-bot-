import express from 'express';
import { getBotHealth } from '../../bot/health.js';
import { getGuildConfig, updateGuildConfig, updateThreshold } from '../../database/guildConfig.js';
import { getTrustedAdmins, addTrustedAdmin, removeTrustedAdmin } from '../../database/trustedAdmins.js';
import { getAlerts, getAlertStats, updateAlertStatus } from '../../database/alerts.js';
import { getAuditLogs, getModerationCases, addModerationCase, getWarningCount } from '../../database/moderation.js';
import { getBackups, getBackup, deleteBackup, saveBackup } from '../../database/backups.js';
import { getTickets, closeTicket } from '../../database/tickets.js';
import { scanServerPermissions } from '../../bot/scanner/permScanner.js';
import { enableEmergencyLockdown, disableEmergencyLockdown } from '../../bot/recovery/lockdown.js';
import { captureGuildSnapshot } from '../../bot/recovery/snapshot.js';
import { executeSafeRestore, generateRecoveryPreview } from '../../bot/recovery/rollback.js';
import { runSimulation } from '../../simulator/raidSimulator.js';
import { getMusicSession, updateMusicSession } from '../../database/music.js';
import { requireAuth, requireGuildPermission, requireGuildOwner } from '../auth.js';
import { getDb } from '../../database/db.js';

export function createApiRouter(client) {
  const router = express.Router();

  // Helper to get Discord Guild or fallback mock guild for dev
  function resolveGuild(guildId) {
    if (client && client.isReady() && client.guilds.cache.has(guildId)) {
      return client.guilds.cache.get(guildId);
    }
    return {
      id: guildId || 'spoofy-main-server',
      name: 'SPOOFY Operations HQ',
      ownerId: '999999999999999999',
      verificationLevel: 2,
      mfaLevel: 1,
      channels: {
        cache: new Map([
          ['ch1', { id: 'ch1', name: 'general', type: 0, topic: 'Main chat', isThread: () => false, permissionOverwrites: { cache: new Map() } }],
          ['ch2', { id: 'ch2', name: 'announcements', type: 5, topic: 'News', isThread: () => false, permissionOverwrites: { cache: new Map() } }],
          ['ch3', { id: 'ch3', name: 'security-logs', type: 0, topic: 'Sentinel', isThread: () => false, permissionOverwrites: { cache: new Map() } }]
        ])
      },
      roles: {
        cache: new Map([
          ['r1', { id: 'r1', name: 'Administrator', position: 10, permissions: { has: () => true, bitfield: 8n }, managed: false }],
          ['r2', { id: 'r2', name: 'Moderator', position: 5, permissions: { has: () => false, bitfield: 0n }, managed: false }]
        ]),
        everyone: { id: guildId, permissions: { has: () => false, bitfield: 0n } }
      },
      members: {
        cache: new Map([
          ['m1', { id: 'm1', user: { tag: 'SPOOFY Bot', bot: true }, permissions: { has: () => true } }]
        ]),
        me: {
          id: 'spoofy-bot-id',
          roles: { highest: { position: 99 } },
          permissions: { has: () => true }
        }
      }
    };
  }

  // 1. Bot & Gateway Health
  router.get('/health', (req, res) => {
    res.json(getBotHealth(client));
  });

  // 2. Active Guilds for current user (Revalidates permissions on backend)
  router.get('/guilds', (req, res) => {
    // If bot is live and user is authenticated
    if (client && client.isReady() && client.guilds.cache.size > 0) {
      const userDiscordId = req.user?.discord_id;
      const list = [];

      for (const [id, g] of client.guilds.cache.entries()) {
        const isOwner = g.ownerId === userDiscordId;
        const member = userDiscordId ? g.members.cache.get(userDiscordId) : null;
        const hasManage = member ? (member.permissions.has('Administrator') || member.permissions.has('ManageGuild')) : false;

        // In dev mode or if user has permissions or if system admin
        if (!userDiscordId || isOwner || hasManage || req.isSystemAdmin) {
          list.push({
            id: g.id,
            name: g.name,
            icon: g.iconURL(),
            memberCount: g.memberCount,
            ownerId: g.ownerId,
            installed: true,
            canManage: true
          });
        }
      }

      if (list.length > 0) return res.json(list);
    }

    // Default development / preview servers
    res.json([
      {
        id: 'spoofy-main-server',
        name: 'SPOOFY Operations HQ',
        icon: null,
        memberCount: 1420,
        ownerId: req.user?.discord_id || '999999999999999999',
        installed: true,
        canManage: true
      },
      {
        id: 'dev-guild-gaming',
        name: 'Cyberpunk Gaming Community',
        icon: null,
        memberCount: 890,
        ownerId: '111222333444555666',
        installed: true,
        canManage: Boolean(req.isSystemAdmin)
      }
    ]);
  });

  // Guild-Scoped Routes (Protected by Guild Authorization & Isolation)
  // -------------------------------------------------------------

  // 3. Guild Config & Thresholds
  router.get('/guild/:guildId/config', requireGuildPermission(client), (req, res) => {
    const config = getGuildConfig(req.params.guildId);
    res.json(config);
  });

  router.put('/guild/:guildId/config', requireGuildPermission(client), (req, res) => {
    const updated = updateGuildConfig(req.params.guildId, req.body);
    res.json(updated);
  });

  router.put('/guild/:guildId/threshold/:actionType', requireGuildPermission(client), (req, res) => {
    const { limit_count, window_seconds, punishment } = req.body;
    const parsedLimit = Math.max(1, Math.min(100, parseInt(limit_count, 10) || 2));
    const parsedWindow = Math.max(5, Math.min(600, parseInt(window_seconds, 10) || 10));
    const validPunishments = ['ban', 'kick', 'quarantine', 'strip_roles'];
    const safePunishment = validPunishments.includes(punishment) ? punishment : 'quarantine';

    const updated = updateThreshold(req.params.guildId, req.params.actionType, {
      limit_count: parsedLimit,
      window_seconds: parsedWindow,
      punishment: safePunishment
    });
    res.json(updated);
  });

  // 4. Trusted Admins
  router.get('/guild/:guildId/trusted', requireGuildPermission(client), (req, res) => {
    const trusted = getTrustedAdmins(req.params.guildId);
    res.json(trusted);
  });

  router.post('/guild/:guildId/trusted', requireGuildOwner(client), (req, res) => {
    const { target_id, target_type, target_tag, notes } = req.body;
    if (!target_id) return res.status(400).json({ error: 'target_id is required' });

    const created = addTrustedAdmin(req.params.guildId, {
      target_id,
      target_type: target_type || 'user',
      target_tag: target_tag || target_id,
      added_by: req.user?.username || 'Dashboard Admin',
      notes: notes || ''
    });
    res.json(created);
  });

  router.delete('/guild/:guildId/trusted/:targetId', requireGuildOwner(client), (req, res) => {
    const success = removeTrustedAdmin(req.params.guildId, req.params.targetId);
    res.json({ success });
  });

  // 5. Security Alerts
  router.get('/guild/:guildId/alerts', requireGuildPermission(client), (req, res) => {
    const limit = parseInt(req.query.limit || '50', 10);
    const alerts = getAlerts(req.params.guildId, limit);
    const stats = getAlertStats(req.params.guildId);
    res.json({ alerts, stats });
  });

  router.post('/guild/:guildId/alerts/:alertId/status', requireGuildPermission(client), (req, res) => {
    const updated = updateAlertStatus(req.params.alertId, req.body.status || 'RESOLVED');
    res.json(updated);
  });

  // 6. Audit & Moderation Logs
  router.get('/guild/:guildId/audit', requireGuildPermission(client), (req, res) => {
    const limit = parseInt(req.query.limit || '50', 10);
    const logs = getAuditLogs(req.params.guildId, limit);
    res.json(logs);
  });

  router.get('/guild/:guildId/audit-logs', requireGuildPermission(client), (req, res) => {
    const limit = parseInt(req.query.limit || '50', 10);
    const logs = getAuditLogs(req.params.guildId, limit);
    res.json(logs);
  });

  router.get('/guild/:guildId/moderation', requireGuildPermission(client), (req, res) => {
    const limit = parseInt(req.query.limit || '50', 10);
    const cases = getModerationCases(req.params.guildId, null, limit);
    res.json(cases);
  });

  router.post('/guild/:guildId/moderation/warn', requireGuildPermission(client), (req, res) => {
    const { user_id, user_tag, reason } = req.body;
    const newCase = addModerationCase({
      guild_id: req.params.guildId,
      case_type: 'WARN',
      user_id,
      user_tag,
      moderator_id: req.user?.discord_id || 'Dashboard Admin',
      moderator_tag: req.user?.username || 'Dashboard',
      reason: reason || 'Rule violation'
    });
    const totalWarns = getWarningCount(req.params.guildId, user_id);
    res.json({ newCase, totalWarns });
  });

  router.post('/guild/:guildId/moderation/action', requireGuildPermission(client), async (req, res) => {
    const { action_type, user_id, user_tag, reason, duration_minutes } = req.body;
    const newCase = addModerationCase({
      guild_id: req.params.guildId,
      case_type: action_type.toUpperCase(),
      user_id,
      user_tag,
      moderator_id: req.user?.discord_id || 'Dashboard',
      moderator_tag: req.user?.username || 'Dashboard',
      reason: reason || 'Moderation action',
      duration_seconds: (duration_minutes || 0) * 60
    });
    res.json({ success: true, case: newCase });
  });

  router.post('/guild/:guildId/moderation/unban', requireGuildPermission(client), async (req, res) => {
    const { user_id, reason } = req.body;
    const guild = resolveGuild(req.params.guildId);

    if (client && client.isReady() && client.guilds.cache.has(req.params.guildId)) {
      await client.guilds.cache.get(req.params.guildId).bans.remove(user_id, reason).catch(() => {});
    }

    addModerationCase({
      guild_id: req.params.guildId,
      case_type: 'UNBAN',
      user_id,
      moderator_id: req.user?.discord_id || 'Dashboard',
      moderator_tag: req.user?.username || 'Dashboard',
      reason: reason || 'Unbanned via Dashboard'
    });

    res.json({ success: true, message: `Member ${user_id} unbanned.` });
  });

  // 7. Backups & Recovery
  router.get('/guild/:guildId/backups', requireGuildPermission(client), (req, res) => {
    const backups = getBackups(req.params.guildId);
    res.json(backups);
  });

  router.post('/guild/:guildId/backups', requireGuildPermission(client), async (req, res) => {
    const guild = resolveGuild(req.params.guildId);
    try {
      const backup = await captureGuildSnapshot(guild, { id: req.user?.discord_id || 'dashboard', tag: req.user?.username || 'Dashboard User' }, req.body.name);
      res.json(backup);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.get('/guild/:guildId/backups/:backupId', requireGuildPermission(client), (req, res) => {
    const backup = getBackup(req.params.backupId);
    if (!backup) return res.status(404).json({ error: 'Backup not found' });
    res.json(backup);
  });

  router.post('/guild/:guildId/backups/:backupId/restore', requireGuildOwner(client), async (req, res) => {
    const guild = resolveGuild(req.params.guildId);
    try {
      const results = await executeSafeRestore(guild, req.params.backupId, req.body.options || { channels: true, roles: true, settings: true });
      res.json(results);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.delete('/guild/:guildId/backups/:backupId', requireGuildPermission(client), (req, res) => {
    const success = deleteBackup(req.params.backupId);
    res.json({ success });
  });

  // 8. Permission Scanner
  router.get('/guild/:guildId/scanner', requireGuildPermission(client), async (req, res) => {
    const guild = resolveGuild(req.params.guildId);
    try {
      const scan = await scanServerPermissions(guild);
      res.json(scan);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 9. Emergency Lockdown
  router.post('/guild/:guildId/lockdown', requireGuildPermission(client), async (req, res) => {
    const guild = resolveGuild(req.params.guildId);
    const rawDuration = parseInt(req.body.duration || '15', 10);
    const duration = Number.isNaN(rawDuration) || rawDuration < 0 ? 15 : Math.min(1440, rawDuration);
    const reason = (req.body.reason || 'Lockdown initiated from SPOOFY Dashboard').slice(0, 250);

    try {
      const result = await enableEmergencyLockdown(guild, client, { durationMinutes: duration, reason });
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/guild/:guildId/unlockdown', requireGuildPermission(client), async (req, res) => {
    const guild = resolveGuild(req.params.guildId);
    const reason = req.body.reason || 'Lockdown lifted from SPOOFY Dashboard';

    try {
      const result = await disableEmergencyLockdown(guild, client, { reason });
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 10. Tickets
  router.get('/guild/:guildId/tickets', requireGuildPermission(client), (req, res) => {
    const tickets = getTickets(req.params.guildId);
    res.json(tickets);
  });

  router.post('/guild/:guildId/tickets/:ticketId/close', requireGuildPermission(client), (req, res) => {
    const closed = closeTicket(req.params.ticketId, req.body.transcript || 'Closed via Guild Dashboard');
    res.json(closed);
  });

  // 11. Music Management
  router.get('/guild/:guildId/music', requireGuildPermission(client), (req, res) => {
    const session = getMusicSession(req.params.guildId);
    res.json(session);
  });

  router.post('/guild/:guildId/music/action', requireGuildPermission(client), (req, res) => {
    const { action, payload } = req.body;
    const guildId = req.params.guildId;
    const session = getMusicSession(guildId);

    let updated;
    if (action === 'pause') {
      updated = updateMusicSession(guildId, { is_paused: 1 });
    } else if (action === 'resume') {
      updated = updateMusicSession(guildId, { is_paused: 0 });
    } else if (action === 'stop') {
      updated = updateMusicSession(guildId, { is_playing: 0, is_paused: 0, current_track_title: null, queue_json: [] });
    } else if (action === 'skip') {
      if (session.queue.length > 0) {
        const next = session.queue[0];
        updated = updateMusicSession(guildId, {
          current_track_title: next.title,
          current_track_author: next.author,
          current_track_url: next.url,
          queue_json: session.queue.slice(1)
        });
      } else {
        updated = updateMusicSession(guildId, { is_playing: 0, current_track_title: null });
      }
    } else if (action === 'volume') {
      updated = updateMusicSession(guildId, { volume: parseInt(payload, 10) });
    } else if (action === 'loop') {
      updated = updateMusicSession(guildId, { loop_mode: payload });
    } else if (action === 'toggle247') {
      updated = updateMusicSession(guildId, { is_247: session.is_247 ? 0 : 1 });
    }

    res.json(updated || getMusicSession(guildId));
  });

  // 12. Welcome & Goodbye Configuration
  router.get('/guild/:guildId/welcome', requireGuildPermission(client), (req, res) => {
    const db = getDb();
    let row = db.prepare('SELECT * FROM guild_welcome_configs WHERE guild_id = ?').get(req.params.guildId);
    if (!row) {
      db.prepare('INSERT INTO guild_welcome_configs (guild_id) VALUES (?)').run(req.params.guildId);
      row = db.prepare('SELECT * FROM guild_welcome_configs WHERE guild_id = ?').get(req.params.guildId);
    }
    res.json(row);
  });

  router.put('/guild/:guildId/welcome', requireGuildPermission(client), (req, res) => {
    const db = getDb();
    const updates = req.body;
    const allowed = ['welcome_enabled', 'welcome_channel_id', 'welcome_message', 'welcome_embed_json', 'dm_welcome_enabled', 'dm_welcome_message', 'goodbye_enabled', 'goodbye_channel_id', 'goodbye_message'];
    const sets = [];
    const vals = [];

    for (const [k, v] of Object.entries(updates)) {
      if (allowed.includes(k)) {
        sets.push(`${k} = ?`);
        vals.push(v);
      }
    }

    if (sets.length > 0) {
      vals.push(req.params.guildId);
      db.prepare(`UPDATE guild_welcome_configs SET ${sets.join(', ')} WHERE guild_id = ?`).run(...vals);
    }

    const row = db.prepare('SELECT * FROM guild_welcome_configs WHERE guild_id = ?').get(req.params.guildId);
    res.json(row);
  });

  // 13. Logging Configuration
  router.get('/guild/:guildId/logging', requireGuildPermission(client), (req, res) => {
    const db = getDb();
    let row = db.prepare('SELECT * FROM guild_logging_configs WHERE guild_id = ?').get(req.params.guildId);
    if (!row) {
      db.prepare('INSERT INTO guild_logging_configs (guild_id) VALUES (?)').run(req.params.guildId);
      row = db.prepare('SELECT * FROM guild_logging_configs WHERE guild_id = ?').get(req.params.guildId);
    }
    res.json(row);
  });

  router.put('/guild/:guildId/logging', requireGuildPermission(client), (req, res) => {
    const db = getDb();
    const updates = req.body;
    const allowed = ['mod_log_channel_id', 'security_log_channel_id', 'member_log_channel_id', 'message_log_channel_id', 'role_log_channel_id', 'channel_log_channel_id', 'voice_log_channel_id'];
    const sets = [];
    const vals = [];

    for (const [k, v] of Object.entries(updates)) {
      if (allowed.includes(k)) {
        sets.push(`${k} = ?`);
        vals.push(v);
      }
    }

    if (sets.length > 0) {
      vals.push(req.params.guildId);
      db.prepare(`UPDATE guild_logging_configs SET ${sets.join(', ')} WHERE guild_id = ?`).run(...vals);
    }

    const row = db.prepare('SELECT * FROM guild_logging_configs WHERE guild_id = ?').get(req.params.guildId);
    res.json(row);
  });

  // 14. Interactive Attack Simulator (for verified testing)
  router.post('/guild/:guildId/simulate', requireGuildPermission(client), async (req, res) => {
    const scenario = req.body.scenario;
    try {
      const outcome = await runSimulation(req.params.guildId, scenario, client);
      res.json(outcome);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
}
