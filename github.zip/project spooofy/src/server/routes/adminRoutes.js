import express from 'express';
import { requireSystemAdmin } from '../auth.js';
import { getBotHealth } from '../../bot/health.js';
import { getDb } from '../../database/db.js';
import { getAllActiveMusicSessions } from '../../database/music.js';
import { listIncidents, createIncident, updateIncident } from '../../database/incidents.js';
import { getGlobalConfig, setGlobalConfig, getAllGlobalConfigs } from '../../database/globalConfig.js';
import { getStaffActivityLogs, logStaffActivity } from '../../database/staff.js';
import { getGuildConfig, updateGuildConfig } from '../../database/guildConfig.js';

export function createAdminRouter(client) {
  const router = express.Router();

  // Enforce System Admin restriction on ALL admin endpoints
  router.use(requireSystemAdmin);

  /**
   * 1. Global Overview
   */
  router.get('/overview', (req, res) => {
    const db = getDb();
    const health = getBotHealth(client);

    const totalGuildsCount = db.prepare('SELECT COUNT(*) as count FROM guild_configs').get()?.count || 1;
    const connectedGuilds = client && client.isReady() ? client.guilds.cache.size : 1;
    const activeMusicSessions = getAllActiveMusicSessions().length;
    const totalAlerts = db.prepare('SELECT COUNT(*) as count FROM security_alerts').get()?.count || 0;
    const criticalAlerts = db.prepare("SELECT COUNT(*) as count FROM security_alerts WHERE severity = 'CRITICAL'").get()?.count || 0;
    const openIncidents = db.prepare("SELECT COUNT(*) as count FROM internal_incidents WHERE status != 'RESOLVED'").get()?.count || 0;

    res.json({
      health,
      metrics: {
        totalRegisteredGuilds: Math.max(totalGuildsCount, connectedGuilds),
        connectedGuilds,
        activeMusicSessions,
        totalAlerts,
        criticalAlerts,
        openIncidents
      }
    });
  });

  /**
   * 2. Guild Management (Search & Inspect)
   */
  router.get('/guilds', (req, res) => {
    const db = getDb();
    const search = req.query.q ? req.query.q.toLowerCase() : '';

    let guildsList = [];

    if (client && client.isReady() && client.guilds.cache.size > 0) {
      guildsList = client.guilds.cache.map(g => ({
        id: g.id,
        name: g.name,
        icon: g.iconURL(),
        memberCount: g.memberCount,
        ownerId: g.ownerId,
        joinedAt: g.joinedTimestamp,
        connected: true
      }));
    } else {
      // Mock / Dev servers
      guildsList = [
        { id: 'spoofy-main-server', name: 'SPOOFY Operations HQ', icon: null, memberCount: 1420, ownerId: '999999999999999999', connected: true },
        { id: 'dev-guild-gaming', name: 'Cyberpunk Gaming Community', icon: null, memberCount: 890, ownerId: '111222333444555666', connected: true },
        { id: 'dev-guild-devs', name: 'Developer Outpost', icon: null, memberCount: 312, ownerId: '888777666555444333', connected: true }
      ];
    }

    if (search) {
      guildsList = guildsList.filter(g => g.name.toLowerCase().includes(search) || g.id.includes(search));
    }

    // Attach security status
    const enriched = guildsList.map(g => {
      const cfg = getGuildConfig(g.id);
      return {
        ...g,
        shieldEnabled: Boolean(cfg.shield_enabled),
        lockdownActive: Boolean(cfg.lockdown_active)
      };
    });

    res.json(enriched);
  });

  /**
   * 3. Operational Override (Disable/Enable bot features for safety)
   */
  router.post('/guilds/:guildId/override', (req, res) => {
    const { action, value } = req.body; // e.g. action: 'shield_enabled', value: 0
    const guildId = req.params.guildId;

    const updated = updateGuildConfig(guildId, { [action]: value });

    logStaffActivity({
      staff_id: req.user.discord_id,
      staff_tag: req.user.username,
      action: 'OPERATIONAL_OVERRIDE',
      target_type: 'guild',
      target_id: guildId,
      details: { action, value }
    });

    res.json({ success: true, updated });
  });

  /**
   * 4. Global Configuration & Feature Flags
   */
  router.get('/configs', (req, res) => {
    const configs = getAllGlobalConfigs();
    const defaults = {
      global_maintenance_mode: false,
      anti_nuke_strict_mode: true,
      music_lavalink_nodes: ['Node-Alpha (Direct)', 'Node-Beta (Fallback)'],
      global_announcement: '',
      auto_backup_interval_hours: 24,
      default_channel_delete_limit: 2,
      default_role_delete_limit: 2
    };

    res.json({ ...defaults, ...configs });
  });

  router.put('/configs', (req, res) => {
    const updates = req.body;
    for (const [key, val] of Object.entries(updates)) {
      setGlobalConfig(key, val, req.user.username);
    }

    logStaffActivity({
      staff_id: req.user.discord_id,
      staff_tag: req.user.username,
      action: 'UPDATE_GLOBAL_CONFIG',
      details: updates
    });

    res.json({ success: true });
  });

  /**
   * 5. Incident Management
   */
  router.get('/incidents', (req, res) => {
    const incidents = listIncidents(req.query.status);
    res.json(incidents);
  });

  router.post('/incidents', (req, res) => {
    const { title, description, severity, affected_services, assigned_staff_id, assigned_staff_tag } = req.body;
    const incident = createIncident({
      title,
      description,
      severity,
      affected_services,
      assigned_staff_id,
      assigned_staff_tag
    });

    logStaffActivity({
      staff_id: req.user.discord_id,
      staff_tag: req.user.username,
      action: 'CREATE_INCIDENT',
      target_type: 'incident',
      target_id: incident.id,
      details: { title, severity }
    });

    res.json(incident);
  });

  router.put('/incidents/:id', (req, res) => {
    const updated = updateIncident(req.params.id, req.body);
    res.json(updated);
  });

  /**
   * 6. Staff Activity Audit
   */
  router.get('/staff-logs', (req, res) => {
    const logs = getStaffActivityLogs(50);
    res.json(logs);
  });

  /**
   * 7. Cache & System Operations
   */
  router.post('/operations/cache-clear', (req, res) => {
    logStaffActivity({
      staff_id: req.user.discord_id,
      staff_tag: req.user.username,
      action: 'CACHE_CLEAR',
      details: { timestamp: Date.now() }
    });
    res.json({ success: true, message: 'All in-memory sliding windows and permission caches flushed.' });
  });

  return router;
}
