import express from 'express';
import { getDiscordOAuthUrl, exchangeOAuthCode } from '../auth.js';
import { upsertUser, createSession, deleteSession } from '../../database/users.js';
import { addStaffMember, getStaffMember } from '../../database/staff.js';
import { parseCookies } from '../auth.js';
import { config } from '../../config.js';

export const authRouter = express.Router();

/**
 * Initiate Discord OAuth2 login
 */
authRouter.get('/discord/login', (req, res) => {
  const url = getDiscordOAuthUrl();
  res.redirect(url);
});

/**
 * Discord OAuth2 callback
 */
authRouter.get('/discord/callback', async (req, res) => {
  const { code, state } = req.query;

  try {
    const profile = await exchangeOAuthCode(code, state);
    const user = upsertUser(profile);
    const session = createSession(user.id, req.headers['user-agent'], req.ip);

    // Set secure HttpOnly session cookie
    res.cookie('spoofy_session', session.sessionToken, {
      httpOnly: true,
      secure: config.env === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    });

    res.redirect('/dashboard');
  } catch (err) {
    console.error('[OAuth2] Authentication error:', err.message);
    res.redirect(`/login?error=${encodeURIComponent(err.message)}`);
  }
});

/**
 * Get current authenticated user profile & staff status
 */
authRouter.get('/me', (req, res) => {
  if (!req.user) {
    return res.json({ authenticated: false, user: null, staff: null, isSystemAdmin: false, isStaff: false });
  }

  res.json({
    authenticated: true,
    user: req.user,
    staff: req.staffMember,
    isSystemAdmin: req.isSystemAdmin,
    isStaff: Boolean((req.staffMember && req.staffMember.status === 'ACTIVE') || req.isSystemAdmin)
  });
});

/**
 * Logout
 */
authRouter.post('/logout', (req, res) => {
  const cookies = parseCookies(req);
  if (cookies.spoofy_session) {
    deleteSession(cookies.spoofy_session);
  }
  res.clearCookie('spoofy_session');
  res.json({ success: true });
});

/**
 * Dev / Simulator Quick-Login Switcher
 * Enables testing the website, guild dashboard, staff portal, and owner admin panel
 * without requiring live Discord OAuth credentials in local dev!
 */
authRouter.post('/dev-login', (req, res) => {
  if (config.env === 'production' && process.env.ALLOW_DEV_LOGIN !== 'true') {
    return res.status(403).json({ error: 'Forbidden: Developer persona login is strictly disabled in production.' });
  }
  const { persona } = req.body; // 'owner', 'staff', 'moderator'

  let profile;
  if (persona === 'owner') {
    profile = {
      discord_id: config.botOwnerId || '999999999999999999',
      username: 'SPOOFY Project Owner',
      discriminator: '0001',
      avatar: 'https://cdn.discordapp.com/embed/avatars/0.png',
      email: 'owner@spoofy.security',
      is_system_admin: 1
    };
  } else if (persona === 'staff') {
    profile = {
      discord_id: '888777666555444333',
      username: 'SeniorStaffGuardian',
      discriminator: '1337',
      avatar: 'https://cdn.discordapp.com/embed/avatars/1.png',
      email: 'staff@spoofy.security',
      is_system_admin: 0
    };
  } else {
    profile = {
      discord_id: '111222333444555666',
      username: 'ServerModerator',
      discriminator: '2026',
      avatar: 'https://cdn.discordapp.com/embed/avatars/2.png',
      email: 'mod@server.com',
      is_system_admin: 0
    };
  }

  const user = upsertUser(profile);

  // If staff persona, ensure in staff table
  if (persona === 'staff' || persona === 'owner') {
    addStaffMember({
      user_id: user.id,
      discord_id: user.discord_id,
      username: user.username,
      avatar: user.avatar,
      role: persona === 'owner' ? 'OWNER' : 'SENIOR_STAFF',
      created_by: 'system',
      notes: 'Dev test staff profile'
    });
  }

  const session = createSession(user.id, req.headers['user-agent'], req.ip);

  res.cookie('spoofy_session', session.sessionToken, {
    httpOnly: true,
    secure: config.env === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000
  });

  res.json({
    success: true,
    persona,
    user,
    token: session.sessionToken
  });
});
