import express from 'express';
import { requireStaff, requireSystemAdmin } from '../auth.js';
import { getDb } from '../../database/db.js';
import { listIncidents, updateIncident } from '../../database/incidents.js';
import { listAnnouncements, createAnnouncement } from '../../database/announcements.js';
import { 
  listStaffMembers, 
  addStaffMember, 
  updateStaffRole, 
  updateStaffStatus, 
  getStaffActivityLogs, 
  logStaffActivity,
  STAFF_ROLE_RANKS 
} from '../../database/staff.js';

export function createStaffRouter() {
  const router = express.Router();

  // All endpoints require verified internal staff membership
  router.use(requireStaff('SUPPORT_AGENT'));

  /**
   * 1. Staff Dashboard Overview
   */
  router.get('/overview', (req, res) => {
    const db = getDb();
    const openTickets = db.prepare("SELECT COUNT(*) as count FROM tickets WHERE status = 'OPEN'").get()?.count || 0;
    const assignedTickets = db.prepare("SELECT COUNT(*) as count FROM tickets WHERE assigned_staff_id = ? AND status != 'CLOSED'").get(req.user.discord_id)?.count || 0;
    const openIncidents = db.prepare("SELECT COUNT(*) as count FROM internal_incidents WHERE status != 'RESOLVED'").get()?.count || 0;
    const staffCount = db.prepare("SELECT COUNT(*) as count FROM staff_members WHERE status = 'ACTIVE'").get()?.count || 0;
    const announcements = listAnnouncements(3);

    res.json({
      metrics: {
        openTickets,
        assignedTickets,
        openIncidents,
        staffCount
      },
      announcements,
      currentStaff: req.staffMember
    });
  });

  /**
   * 2. Tickets Queue Management
   */
  router.get('/tickets', (req, res) => {
    const db = getDb();
    const status = req.query.status;

    let query = 'SELECT * FROM tickets';
    const params = [];
    if (status && status !== 'ALL') {
      query += ' WHERE status = ?';
      params.push(status);
    }
    query += ' ORDER BY created_at DESC LIMIT 50';

    const tickets = db.prepare(query).all(...params);
    res.json(tickets);
  });

  router.put('/tickets/:id', (req, res) => {
    const db = getDb();
    const { status, priority, assigned_staff_id, internal_notes } = req.body;
    const ticketId = req.params.id;

    const current = db.prepare('SELECT * FROM tickets WHERE id = ?').get(ticketId);
    if (!current) return res.status(404).json({ error: 'Ticket not found' });

    const newStatus = status || current.status;
    const newPriority = priority || current.priority || 'MEDIUM';
    const newAssignee = assigned_staff_id !== undefined ? assigned_staff_id : current.assigned_staff_id;
    const newNotes = internal_notes !== undefined ? internal_notes : current.internal_notes;

    db.prepare(`
      UPDATE tickets SET status = ?, priority = ?, assigned_staff_id = ?, internal_notes = ?
      WHERE id = ?
    `).run(newStatus, newPriority, newAssignee, newNotes, ticketId);

    logStaffActivity({
      staff_id: req.user.discord_id,
      staff_tag: req.user.username,
      action: 'UPDATE_TICKET',
      target_type: 'ticket',
      target_id: ticketId,
      details: { status: newStatus, priority: newPriority, assigned_to: newAssignee }
    });

    const updated = db.prepare('SELECT * FROM tickets WHERE id = ?').get(ticketId);
    res.json(updated);
  });

  /**
   * 3. Incidents Review & Investigation Notes
   */
  router.get('/incidents', (req, res) => {
    const incidents = listIncidents(req.query.status);
    res.json(incidents);
  });

  router.put('/incidents/:id/notes', (req, res) => {
    const { investigation_notes, status } = req.body;
    const updated = updateIncident(req.params.id, { investigation_notes, status });
    res.json(updated);
  });

  /**
   * 4. Internal Team Announcements
   */
  router.get('/announcements', (req, res) => {
    const list = listAnnouncements(20);
    res.json(list);
  });

  router.post('/announcements', (req, res) => {
    const userRank = STAFF_ROLE_RANKS[req.staffMember?.role] || 0;
    if (userRank < STAFF_ROLE_RANKS['SENIOR_STAFF'] && !req.isSystemAdmin) {
      return res.status(403).json({ error: 'Requires Senior Staff role or higher to publish announcements.' });
    }

    const { title, content, target_roles } = req.body;
    const ann = createAnnouncement({
      title,
      content,
      target_roles: target_roles || 'ALL',
      author_id: req.user.discord_id,
      author_tag: req.user.username
    });

    res.json(ann);
  });

  /**
   * 5. Staff Management (Admin Only)
   */
  router.get('/members', (req, res) => {
    const members = listStaffMembers();
    res.json(members);
  });

  router.post('/members', (req, res) => {
    const userRank = STAFF_ROLE_RANKS[req.staffMember?.role] || 0;
    if (userRank < STAFF_ROLE_RANKS['ADMINISTRATOR'] && !req.isSystemAdmin) {
      return res.status(403).json({ error: 'Requires Administrator role to onboard staff.' });
    }

    const { user_id, discord_id, username, avatar, role, notes } = req.body;
    const created = addStaffMember({
      user_id: user_id || 'usr_' + discord_id,
      discord_id,
      username,
      avatar,
      role: role || 'SUPPORT_AGENT',
      created_by: req.user.discord_id,
      notes: notes || ''
    });

    res.json(created);
  });

  router.put('/members/:id/role', (req, res) => {
    const userRank = STAFF_ROLE_RANKS[req.staffMember?.role] || 0;
    if (userRank < STAFF_ROLE_RANKS['ADMINISTRATOR'] && !req.isSystemAdmin) {
      return res.status(403).json({ error: 'Requires Administrator role to modify staff permissions.' });
    }

    const updated = updateStaffRole(req.params.id, req.body.role, req.user.discord_id);
    res.json(updated);
  });

  router.put('/members/:id/status', (req, res) => {
    const userRank = STAFF_ROLE_RANKS[req.staffMember?.role] || 0;
    if (userRank < STAFF_ROLE_RANKS['ADMINISTRATOR'] && !req.isSystemAdmin) {
      return res.status(403).json({ error: 'Requires Administrator role to suspend or activate staff.' });
    }

    const updated = updateStaffStatus(req.params.id, req.body.status, req.user.discord_id);
    res.json(updated);
  });

  return router;
}
