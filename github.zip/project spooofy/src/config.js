import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '../.env') });

export const config = {
  token: process.env.DISCORD_TOKEN || '',
  clientId: process.env.CLIENT_ID || process.env.DISCORD_CLIENT_ID || '',
  clientSecret: process.env.CLIENT_SECRET || process.env.DISCORD_CLIENT_SECRET || '',
  guildId: process.env.GUILD_ID || '',
  port: parseInt(process.env.PORT || '4000', 10),
  dashboardUrl: process.env.DASHBOARD_URL || 'http://localhost:5173',
  apiSecret: process.env.API_SECRET || 'spoofy_default_secret_dev_key',
  botOwnerId: process.env.BOT_OWNER_ID || '',
  env: process.env.NODE_ENV || 'development',
  enableSimulator: process.env.ENABLE_SIMULATOR !== 'false',
  databasePath: path.join(__dirname, '../spoofy.sqlite'),
  branding: {
    name: 'SPOOFY',
    shield: 'SPOOFY Shield',
    sentinel: 'SPOOFY Sentinel',
    recovery: 'SPOOFY Recovery',
    dashboard: 'SPOOFY Security Dashboard',
    colorHex: '#8b5cf6', // Neon Violet
    colorInt: 0x8b5cf6,
    colorCritInt: 0xef4444, // Red
    colorHighInt: 0xf97316, // Orange
    colorMedInt: 0xeab308, // Yellow
    colorSuccessInt: 0x10b981 // Emerald
  }
};
