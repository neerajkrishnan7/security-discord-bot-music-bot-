import test, { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'http';
import { getDb } from '../src/database/db.js';
import { createServer } from '../src/server/app.js';
import { addStaffMember, getStaffMember, updateStaffStatus } from '../src/database/staff.js';
import { getGuildConfig, updateGuildConfig, updateThreshold } from '../src/database/guildConfig.js';
import { logAuditEvent, getAuditLogs } from '../src/database/moderation.js';
import { upsertUser, createSession } from '../src/database/users.js';

describe('SPOOFY Security, Authorization & Multi-Tenant Isolation Suite', () => {
  let server;
  let baseUrl;
  let testPort;

  // Mock Discord Client with two isolated guilds
  const mockClient = {
    isReady: () => true,
    user: { id: 'bot_spoofy_123', tag: 'SPOOFY#0001' },
    guilds: {
      cache: new Map([
        [
          'guild_alpha_111',
          {
            id: 'guild_alpha_111',
            name: 'Alpha Server',
            memberCount: 150,
            ownerId: 'owner_alpha_id',
            members: {
              fetch: async (userId) => {
                if (userId === 'discord_mod_alpha') {
                  return {
                    id: 'discord_mod_alpha',
                    permissions: { has: (perm) => perm === 'ManageGuild' || perm === 'Administrator' }
                  };
                }
                if (userId === 'discord_regular_user') {
                  return {
                    id: 'discord_regular_user',
                    permissions: { has: () => false }
                  };
                }
                throw new Error('Unknown member in Alpha');
              }
            }
          }
        ],
        [
          'guild_beta_222',
          {
            id: 'guild_beta_222',
            name: 'Beta Server',
            memberCount: 300,
            ownerId: 'owner_beta_id',
            members: {
              fetch: async (userId) => {
                if (userId === 'discord_mod_beta') {
                  return {
                    id: 'discord_mod_beta',
                    permissions: { has: (perm) => perm === 'ManageGuild' }
                  };
                }
                throw new Error('Unknown member in Beta');
              }
            }
          }
        ]
      ])
    }
  };

  // Helper to make HTTP requests
  async function makeRequest(path, options = {}) {
    return new Promise((resolve, reject) => {
      const url = new URL(path, baseUrl);
      const reqOptions = {
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(options.headers || {})
        }
      };

      const req = http.request(url, reqOptions, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          let body = data;
          try {
            body = JSON.parse(data);
          } catch {}
          resolve({ status: res.statusCode, headers: res.headers, body });
        });
      });

      req.on('error', reject);
      if (options.body) {
        req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
      }
      req.end();
    });
  }

  // Active test session tokens
  let alphaModToken;
  let betaModToken;
  let staffModToken;
  let sysAdminToken;
  let unauthUserToken;

  before(async () => {
    // 1. Alpha Mod User
    const userAlpha = upsertUser({ discord_id: 'discord_mod_alpha', username: 'AlphaModerator' });
    alphaModToken = createSession(userAlpha.id).sessionToken;

    // 2. Beta Mod User
    const userBeta = upsertUser({ discord_id: 'discord_mod_beta', username: 'BetaModerator' });
    betaModToken = createSession(userBeta.id).sessionToken;

    // 3. Regular Unprivileged User
    const userRegular = upsertUser({ discord_id: 'discord_regular_user', username: 'OrdinaryUser' });
    unauthUserToken = createSession(userRegular.id).sessionToken;

    // 4. Internal Staff User (MODERATOR role)
    const userStaff = upsertUser({ discord_id: 'discord_staff_mod', username: 'InternalStaffMod' });
    staffModToken = createSession(userStaff.id).sessionToken;
    const staffRec = addStaffMember({ user_id: userStaff.id, discord_id: 'discord_staff_mod', username: 'InternalStaffMod', role: 'MODERATOR', created_by: 'system' });

    // 5. System Administrator User
    const userAdmin = upsertUser({ discord_id: 'discord_sys_admin', username: 'SPOOFYSystemAdmin', is_system_admin: 1 });
    sysAdminToken = createSession(userAdmin.id).sessionToken;
    addStaffMember({ user_id: userAdmin.id, discord_id: 'discord_sys_admin', username: 'SPOOFYSystemAdmin', role: 'OWNER', created_by: 'system' });

    // Seed guild configurations
    updateGuildConfig('guild_alpha_111', { shield_enabled: 1 });
    updateGuildConfig('guild_beta_222', { shield_enabled: 1 });

    // Start test server on random high port
    const { server: srv } = createServer(mockClient);
    server = srv;
    await new Promise((resolve) => {
      server.listen(0, '127.0.0.1', () => {
        testPort = server.address().port;
        baseUrl = `http://127.0.0.1:${testPort}`;
        resolve();
      });
    });
  });

  after(async () => {
    if (server) {
      await new Promise(resolve => server.close(resolve));
    }
  });

  // ============================================================================
  // TEST SUITE 1: Cross-Guild Multi-Tenant Isolation
  // ============================================================================
  describe('1. Cross-Guild Data & Permission Isolation', () => {
    it('Should allow Alpha moderator to access Guild Alpha configuration', async () => {
      const res = await makeRequest('/api/guild/guild_alpha_111/config', {
        headers: { Cookie: `spoofy_session=${alphaModToken}` }
      });
      assert.equal(res.status, 200);
      assert.equal(res.body.guild_id, 'guild_alpha_111');
      assert.equal(res.body.shield_enabled, 1);
    });

    it('Should REJECT Alpha moderator attempting to view Beta server configuration (403 Forbidden)', async () => {
      const res = await makeRequest('/api/guild/guild_beta_222/config', {
        headers: { Cookie: `spoofy_session=${alphaModToken}` }
      });
      assert.equal(res.status, 403);
      assert.match(res.body.error, /Forbidden/i);
    });

    it('Should REJECT Alpha moderator attempting to alter Beta server shield thresholds (403 Forbidden)', async () => {
      const res = await makeRequest('/api/guild/guild_beta_222/threshold/channel_delete', {
        method: 'PUT',
        headers: { Cookie: `spoofy_session=${alphaModToken}` },
        body: { limit_count: 1, window_seconds: 5, punishment: 'ban' }
      });
      assert.equal(res.status, 403);
      assert.match(res.body.error, /Forbidden/i);
    });

    it('Should REJECT non-member user attempting to read Guild Alpha audit logs (403 Forbidden)', async () => {
      const res = await makeRequest('/api/guild/guild_alpha_111/audit-logs', {
        headers: { Cookie: `spoofy_session=${unauthUserToken}` }
      });
      assert.equal(res.status, 403);
    });

    it('Should ensure Guild Alpha data does not leak into Beta server queries', async () => {
      const resAlpha = await makeRequest('/api/guild/guild_alpha_111/config', {
        headers: { Cookie: `spoofy_session=${alphaModToken}` }
      });
      const resBeta = await makeRequest('/api/guild/guild_beta_222/config', {
        headers: { Cookie: `spoofy_session=${betaModToken}` }
      });
      assert.notEqual(resAlpha.body.guild_id, resBeta.body.guild_id);
      assert.equal(resAlpha.body.guild_id, 'guild_alpha_111');
      assert.equal(resBeta.body.guild_id, 'guild_beta_222');
    });
  });

  // ============================================================================
  // TEST SUITE 2: Staff Portal Role Hierarchy & Privilege Escalation Prevention
  // ============================================================================
  describe('2. Staff Portal Authorization & Escalation Protection', () => {
    it('Should BLOCK ordinary server admin from entering private staff portal (403 Forbidden)', async () => {
      const res = await makeRequest('/api/staff/overview', {
        headers: { Cookie: `spoofy_session=${alphaModToken}` }
      });
      assert.equal(res.status, 403);
      assert.match(res.body.error, /authorized SPOOFY staff credentials/i);
    });

    it('Should BLOCK unauthenticated user from staff endpoints (401 Unauthorized)', async () => {
      const res = await makeRequest('/api/staff/overview');
      assert.equal(res.status, 401);
    });

    it('Should ALLOW authorized staff member to access staff overview and tickets', async () => {
      const res = await makeRequest('/api/staff/overview', {
        headers: { Cookie: `spoofy_session=${staffModToken}` }
      });
      assert.equal(res.status, 200);
      assert.equal(res.body.currentStaff.role, 'MODERATOR');
      assert.ok(res.body.metrics);
    });

    it('Should BLOCK staff MODERATOR from accessing SPOOFY Owner Admin Panel (403 Forbidden)', async () => {
      const res = await makeRequest('/api/admin/overview', {
        headers: { Cookie: `spoofy_session=${staffModToken}` }
      });
      assert.equal(res.status, 403);
      assert.match(res.body.error, /Restricted to SPOOFY Project Owner/i);
    });

    it('Should ALLOW Global Project Owner / System Admin to access owner admin panel', async () => {
      const res = await makeRequest('/api/admin/overview', {
        headers: { Cookie: `spoofy_session=${sysAdminToken}` }
      });
      assert.equal(res.status, 200);
      assert.ok(res.body.health);
      assert.ok(typeof res.body.metrics.connectedGuilds === 'number');
    });

    it('Should IMMEDIATELY enforce revoked or suspended staff access', async () => {
      // 1. Verify access works initially
      const preCheck = await makeRequest('/api/staff/overview', {
        headers: { Cookie: `spoofy_session=${staffModToken}` }
      });
      assert.equal(preCheck.status, 200);

      // 2. Suspend staff member in database
      updateStaffStatus('discord_staff_mod', 'SUSPENDED');

      // 3. Subsequent request must be rejected immediately without caching bypass
      const postCheck = await makeRequest('/api/staff/overview', {
        headers: { Cookie: `spoofy_session=${staffModToken}` }
      });
      assert.equal(postCheck.status, 403);
      assert.match(postCheck.body.error, /authorized SPOOFY staff credentials/i);

      // Restore status for cleanup
      updateStaffStatus('discord_staff_mod', 'ACTIVE');
    });
  });

  // ============================================================================
  // TEST SUITE 3: Dashboard Controls Actually Update Real Backend & Bot State
  // ============================================================================
  describe('3. Working Dashboard Mutations & Audit Trail Verification', () => {
    it('Should successfully update guild shield settings via Dashboard API', async () => {
      const updateRes = await makeRequest('/api/guild/guild_alpha_111/config', {
        method: 'PUT',
        headers: { Cookie: `spoofy_session=${alphaModToken}` },
        body: {
          anti_webhook_enabled: 1,
          anti_raid_enabled: 1,
          anti_everyone_enabled: 1,
          sentinel_log_channel_id: 'channel_sec_logs_777'
        }
      });
      assert.equal(updateRes.status, 200);
      assert.equal(updateRes.body.anti_webhook_enabled, 1);
      assert.equal(updateRes.body.anti_raid_enabled, 1);
      assert.equal(updateRes.body.sentinel_log_channel_id, 'channel_sec_logs_777');

      // Verify persisted directly in database
      const dbConfig = getGuildConfig('guild_alpha_111');
      assert.equal(dbConfig.anti_webhook_enabled, 1);
      assert.equal(dbConfig.sentinel_log_channel_id, 'channel_sec_logs_777');
    });

    it('Should update action threshold in database and reflect in threshold queries', async () => {
      const threshRes = await makeRequest('/api/guild/guild_alpha_111/threshold/role_delete', {
        method: 'PUT',
        headers: { Cookie: `spoofy_session=${alphaModToken}` },
        body: { limit_count: 2, window_seconds: 15, punishment: 'strip_roles' }
      });
      assert.equal(threshRes.status, 200);
      assert.equal(threshRes.body.limit_count, 2);
      assert.equal(threshRes.body.window_seconds, 15);
      assert.equal(threshRes.body.punishment, 'strip_roles');

      // Re-fetch config to verify threshold updated
      const updatedConfig = await makeRequest('/api/guild/guild_alpha_111/config', {
        headers: { Cookie: `spoofy_session=${alphaModToken}` }
      });
      const roleDelThresh = updatedConfig.body.thresholds.find(t => t.action_type === 'role_delete');
      assert.ok(roleDelThresh);
      assert.equal(roleDelThresh.limit_count, 2);
      assert.equal(roleDelThresh.window_seconds, 15);
      assert.equal(roleDelThresh.punishment, 'strip_roles');
    });

    it('Should record and retrieve audit logs when actions are executed', async () => {
      logAuditEvent({
        guild_id: 'guild_alpha_111',
        event_type: 'THRESHOLD_UPDATE',
        actor_id: 'discord_mod_alpha',
        actor_tag: 'AlphaModerator',
        target_id: 'role_delete',
        reason: 'Adjusted rate limit via dashboard'
      });

      const auditRes = await makeRequest('/api/guild/guild_alpha_111/audit-logs', {
        headers: { Cookie: `spoofy_session=${alphaModToken}` }
      });
      assert.equal(auditRes.status, 200);
      assert.ok(Array.isArray(auditRes.body));
      const log = auditRes.body.find(l => l.event_type === 'THRESHOLD_UPDATE');
      assert.ok(log);
      assert.equal(log.actor_id, 'discord_mod_alpha');
    });
  });

  // ============================================================================
  // TEST SUITE 4: Public Endpoints & Unauthenticated Integrity
  // ============================================================================
  describe('4. Public Web Service Endpoints', () => {
    it('Should return real system and gateway status at /api/public/status', async () => {
      const res = await makeRequest('/api/public/status');
      assert.equal(res.status, 200);
      assert.equal(res.body.bot, 'SPOOFY');
      assert.ok(Array.isArray(res.body.services));
    });

    it('Should return command list with anti-nuke, moderation, and music at /api/public/commands', async () => {
      const res = await makeRequest('/api/public/commands');
      assert.equal(res.status, 200);
      assert.ok(Array.isArray(res.body));
      const musicCmd = res.body.find(c => c.name.includes('music'));
      const shieldCmd = res.body.find(c => c.name.includes('shield'));
      assert.ok(musicCmd, 'Music command registered in directory');
      assert.ok(shieldCmd, 'Shield command registered in directory');
    });
  });
});
